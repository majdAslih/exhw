# FitWell JAR File Usage Instructions

## Overview
This JAR file contains the FitWell Gym Management System with automatic database detection. It will automatically find and read the Access database file when they're in the same folder.

## Files Required
1. **FitWell.jar** - The main application
2. **FitWell.accdb** - The Access database file
3. **run_fitwell.bat** - Optional batch file to run the JAR (Windows)

## How to Use

### Option 1: Using the Batch File (Windows)
1. Put all three files in the same folder
2. Double-click `run_fitwell.bat`
3. The system will automatically detect the database and start

### Option 2: Using Command Line
1. Put `FitWell.jar` and `FitWell.accdb` in the same folder
2. Open command prompt/terminal in that folder
3. Run: `java -jar FitWell.jar`

## What Happens
1. The JAR file automatically detects its own location
2. It looks for `FitWell.accdb` in the same folder
3. If found, it connects to the database and shows the report menu
4. If not found, it shows an error message

## Available Reports
1. Unregistered Class Report
2. Equipment Inventory Report  
3. Fitness Recommendation Report
4. View All Reports (generates all three)

## Requirements
- Java 8 or higher installed
- The Access database file must be named exactly `FitWell.accdb`
- Both files must be in the same folder

## Troubleshooting
- **"Could not find FitWell.accdb"**: Make sure the database file is in the same folder as the JAR
- **"Java not found"**: Install Java from https://java.com/
- **Database connection errors**: Ensure the Access file is not corrupted and is accessible

## Distribution
To use this on another computer:
1. Copy `FitWell.jar` to the target computer
2. Copy `FitWell.accdb` to the same folder
3. Run the JAR file
4. No installation required - it's completely portable!
