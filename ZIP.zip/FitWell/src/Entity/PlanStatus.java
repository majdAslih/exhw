package Entity;

public enum PlanStatus 
{
	active, paused, completed,  cancelled
}
