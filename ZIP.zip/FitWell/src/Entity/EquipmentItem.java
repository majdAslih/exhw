package Entity;

public class EquipmentItem {

    private String serialNumber;
    private String catalogueNumber;
    private Catagory category;
    private String location; // textual location
    private int quantity;
    private int timesUsedCurrentYear;

    public EquipmentItem(String serialNumber, String catalogueNumber, Catagory category, 
                         String location, int quantity, int timesUsedCurrentYear) {
        this.serialNumber = serialNumber;
        this.catalogueNumber = catalogueNumber;
        this.category = category;
        this.location = location;
        this.quantity = quantity;
        this.timesUsedCurrentYear = timesUsedCurrentYear;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public String getCatalogueNumber() {
        return catalogueNumber;
    }

    public Catagory getCategory() {
        return category;
    }

    public String getLocation() {
        return location;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getTimesUsedCurrentYear() {
        return timesUsedCurrentYear;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public void setCatalogueNumber(String catalogueNumber) {
        this.catalogueNumber = catalogueNumber;
    }

    public void setCategory(Catagory category) {
        this.category = category;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setTimesUsedCurrentYear(int timesUsedCurrentYear) {
        this.timesUsedCurrentYear = timesUsedCurrentYear;
    }
}

