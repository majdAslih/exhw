package Entity;

import java.util.List;

public class Manager extends SeniorConsultant 
{
	private String password;

	public Manager(String name, String phoneNumber, String fitnessGoal, String email, String name2, String phoneNumber2,
			String email2, List<Plan> assignedPlans, String password) {
		super(name, phoneNumber, fitnessGoal, email, name2, phoneNumber2, email2, assignedPlans);
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
