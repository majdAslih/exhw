package Entity;

import java.util.List;

public class SeniorConsultant extends Consultant {

   
	
	public SeniorConsultant(String name, String phoneNumber, String fitnessGoal, String email, String name2,
			String phoneNumber2, String email2, List<Plan> assignedPlans) {
		super(name, phoneNumber, fitnessGoal, email, name2, phoneNumber2, email2, assignedPlans);
	}

	

    public void recommendEquipment(Equipment equipment) {
        System.out.println("Recommended Equipment: " + equipment.getName()
            + " (" + equipment.getDescription() + ")");
    }
}

