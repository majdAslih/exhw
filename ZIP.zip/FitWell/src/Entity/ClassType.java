package Entity;

public enum ClassType 
{
	namely, yoga, TRX, core, Pilates, strengthtraining, cardio,flexibility
}
