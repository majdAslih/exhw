package Entity;

public class Equipment {

    private String name;
    private String description;
    private EquipmentType type;
    private int maintenanceFrequencyMonths; // e.g., every 6 months

    public Equipment(String name, String description, EquipmentType type, int maintenanceFrequencyMonths) {
        this.name = name;
        this.description = description;
        this.type = type;
        this.maintenanceFrequencyMonths = maintenanceFrequencyMonths;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public EquipmentType getType() {
        return type;
    }

    public int getMaintenanceFrequencyMonths() {
        return maintenanceFrequencyMonths;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setType(EquipmentType type) {
        this.type = type;
    }

    public void setMaintenanceFrequencyMonths(int maintenanceFrequencyMonths) {
        this.maintenanceFrequencyMonths = maintenanceFrequencyMonths;
    }
}
