package Entity;

import java.util.ArrayList;

public class Class 
{ 
	private ParticipationDetails pd;
	private String name;
	private String StartDate;
	private String endDate;
	private ArrayList<String> tips=new ArrayList<String>(5);
	private Consultant instrucor;
	private ArrayList<Costumer> costumers=new ArrayList<Costumer>();

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStartDate() {
		return StartDate;
	}
	public void setStartDate(String startDate) {
		StartDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Consultant getInstrucor() {
		return instrucor;
	}
	public void setInstrucor(Consultant instrucor) {
		this.instrucor = instrucor;
	}
	
	public ParticipationDetails getPd() {
		return pd;
	}
	public void setPd(ParticipationDetails pd) {
		this.pd = pd;
	}
	
	public Class(ParticipationDetails pd, String name, String startDate, String endDate, ArrayList<String> tips,
			Consultant instrucor, ArrayList<Costumer> costumers) {
		super();
		this.pd = pd;
		this.name = name;
		StartDate = startDate;
		this.endDate = endDate;
		this.tips = tips;
		this.instrucor = instrucor;
		this.costumers = costumers;
	}

	
	public ArrayList<Costumer> getCostumers() {
		return costumers;
	}
	public void setCostumers(ArrayList<Costumer> costumers) {
		this.costumers = costumers;
	}
	public ArrayList<String> getTips() {
		return tips;
	}
	public void setTips(ArrayList<String> tips) {
		this.tips = tips;
	}
	

}
