package Entity;

public class Plan 
{
private String Id ;
private String duration;
private String startTime;
private PlanStatus currentStatus;
private Consultant responseableConsultant;
public Plan(String Id,String duration,String startTime,PlanStatus currentStatus,Consultant responseableConsultant)
{
	this.Id=Id;
	this.currentStatus=currentStatus;
	this.duration=duration;
	this.startTime=startTime;
	this.responseableConsultant=responseableConsultant;
}
public String getId() {
	return Id;
}
public void setId(String id) {
	Id = id;
}
public String getDuration() {
	return duration;
}
public void setDuration(String duration) {
	this.duration = duration;
}
public String getStartTime() {
	return startTime;
}
public void setStartTime(String startTime) {
	this.startTime = startTime;
}
public PlanStatus getCurrentStatus() {
	return currentStatus;
}
public void setCurrentStatus(PlanStatus currentStatus) {
	this.currentStatus = currentStatus;
}
public Consultant getResponseableConsultant() {
	return responseableConsultant;
}
public void setResponseableConsultant(Consultant responseableConsultant) {
	this.responseableConsultant = responseableConsultant;
}

}
