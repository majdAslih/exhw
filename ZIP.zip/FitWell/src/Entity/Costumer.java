package Entity;

import java.util.ArrayList;
import java.util.List;

public class Costumer  {
	private String name;
	private String phoneNumber;
	private String fitnessGoal;
	private String email;
	private List<Plan> privPlans=new ArrayList<Plan>();
	//we add an arraylist to the priv plans but we dont add it to the const because maybe he is a new costumer
	public Costumer(String name, String phoneNumber, String fitnessGoal, String email)
	{
		super();
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.fitnessGoal = fitnessGoal;
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getFitnessGoal() {
		return fitnessGoal;
	}
	public void setFitnessGoal(String fitnessGoal) {
		this.fitnessGoal = fitnessGoal;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<Plan> getPrivPlans() {
		return privPlans;
	}
	public void setPrivPlans(List<Plan> privPlans) {
		this.privPlans = privPlans;
	}
	public void addToPlans(Plan p)
	{
		this.privPlans.add(p);
	}
	
	

}
