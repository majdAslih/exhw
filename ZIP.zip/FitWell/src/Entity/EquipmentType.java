package Entity;

public enum EquipmentType {
    TREADMILL,
    RESISTANCE_BANDS,
    OTHER
}
