package Entity;

import java.util.ArrayList;

public class ParticipationDetails {
	private int fromAge;
	private int toAge;
	private String generalGuidance;
	private ClassType prefferedClassType;
	
	
	public ParticipationDetails(int fromAge, int toAge, String generalGuidance, ClassType prefferedClassType) {
		super();
		this.fromAge = fromAge;
		this.toAge = toAge;
		this.generalGuidance = generalGuidance;
		this.prefferedClassType = prefferedClassType;
		
	}
	public int getFromAge() {
		return fromAge;
	}
	public void setFromAge(int fromAge) {
		this.fromAge = fromAge;
	}
	public int getToAge() {
		return toAge;
	}
	public void setToAge(int toAge) {
		this.toAge = toAge;
	}
	public String getGeneralGuidance() {
		return generalGuidance;
	}
	public void setGeneralGuidance(String generalGuidance) {
		this.generalGuidance = generalGuidance;
	}
	public ClassType getPrefferedClassType() {
		return prefferedClassType;
	}
	public void setPrefferedClassType(ClassType prefferedClassType) {
		this.prefferedClassType = prefferedClassType;
	}
	

}
