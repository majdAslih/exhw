package Entity;

public class PersonalPlan extends Plan 
{
	private String restrictions;

	public PersonalPlan(String Id, String duration, String startTime, PlanStatus currentStatus,
			Consultant responseableConsultant, String restrictions) {
		super(Id, duration, startTime, currentStatus, responseableConsultant);
		this.restrictions = restrictions;
	}

	public String getRestrictions() {
		return restrictions;
	}

	public void setRestrictions(String restrictions) {
		this.restrictions = restrictions;
	}
	

}
