package Entity;

public class GroupPlan extends Plan
{
	private String sharedObjectives;
	private Costumer representative ;
	public GroupPlan(String Id, String duration, String startTime, PlanStatus currentStatus,
			Consultant responseableConsultant, String sharedObjectives, Costumer representative) {
		super(Id, duration, startTime, currentStatus, responseableConsultant);
		this.sharedObjectives = sharedObjectives;
		this.representative = representative;
	}
	public String getSharedObjectives() {
		return sharedObjectives;
	}
	public void setSharedObjectives(String sharedObjectives) {
		this.sharedObjectives = sharedObjectives;
	}
	public Costumer getRepresentative() {
		return representative;
	}
	public void setRepresentative(Costumer representative) {
		this.representative = representative;
	}
	

}
