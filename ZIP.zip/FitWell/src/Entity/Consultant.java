package Entity;

import java.util.ArrayList;
import java.util.List;

public class Consultant extends Costumer {

    private String name;
    private String phoneNumber;
    private String email;
    private List<Plan> assignedPlans;

    /*public Consultant(String name, String phoneNumber, String email) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.assignedPlans = new ArrayList<>();
    }*/

    public void createFitnessPlan(Plan plan) {
        assignedPlans.add(plan);
        System.out.println(name + " created a fitness plan with ID: " + plan.getId());
    }

    public Consultant(String name, String phoneNumber, String fitnessGoal, String email, String name2,
			String phoneNumber2, String email2, List<Plan> assignedPlans) {
		super(name, phoneNumber, fitnessGoal, email);
		name = name2;
		phoneNumber = phoneNumber2;
		email = email2;
		this.assignedPlans = assignedPlans;
	}

	public void leadClass(Class trainingClass) {
        System.out.println(name + " is leading the class: " + trainingClass.getName());
    }

    public void reserveEquipment(Equipment equipment) {
        System.out.println(name + " reserved equipment: " + equipment.getName());
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public List<Plan> getAssignedPlans() {
        return assignedPlans;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
