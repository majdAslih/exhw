package Entity;

public enum Catagory {
	eg, Weights, bar, tension, etc
}
