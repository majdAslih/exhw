package boundary;

import control.ClassAttendanceReportControl;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ClassAttendanceReportGUI extends JPanel {

    private DefaultTableModel tableModel;
    private JTable table;
    private ClassAttendanceReportControl control;

    private JTextField startDateField;
    private JTextField endDateField;

    public ClassAttendanceReportGUI() {
        control = new ClassAttendanceReportControl(this);

        setLayout(new BorderLayout(10, 10));

        // Initialize table with proper columns for Unregistered Class Report
        tableModel = new DefaultTableModel(
                new Object[]{"Customer ID", "First Name", "Last Name", "Phone", "Email", "Classes Attended", "Registration Date"}, 0
        );
        table = new JTable(tableModel);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.getColumnModel().getColumn(0).setPreferredWidth(80);  // Customer ID
        table.getColumnModel().getColumn(1).setPreferredWidth(100); // First Name
        table.getColumnModel().getColumn(2).setPreferredWidth(100); // Last Name
        table.getColumnModel().getColumn(3).setPreferredWidth(100); // Phone
        table.getColumnModel().getColumn(4).setPreferredWidth(150); // Email
        table.getColumnModel().getColumn(5).setPreferredWidth(100); // Classes Attended
        table.getColumnModel().getColumn(6).setPreferredWidth(120); // Registration Date

        // Date input panel
        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        datePanel.setBorder(BorderFactory.createTitledBorder("Report Parameters"));
        
        datePanel.add(new JLabel("Start Date (YYYY-MM-DD):"));
        startDateField = new JTextField(12);
        startDateField.setText("2024-01-01");
        datePanel.add(startDateField);

        datePanel.add(new JLabel("End Date (YYYY-MM-DD):"));
        endDateField = new JTextField(12);
        endDateField.setText("2024-01-31");
        datePanel.add(endDateField);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setBorder(BorderFactory.createTitledBorder("Actions"));

        JButton addButton = new JButton("Add Attendance Record");
        addButton.addActionListener(e -> control.addAttendance());

        JButton showButton = new JButton("Show All Attendance Data");
        showButton.addActionListener(e -> control.loadAttendanceFromDB());

        JButton generateReportButton = new JButton("Generate Unregistered Class Report");
        generateReportButton.addActionListener(e -> generateUnregisteredClassReport());

        JButton jasperReportButton = new JButton("Generate PDF Report");
        jasperReportButton.addActionListener(e -> generateJasperReport());

        buttonPanel.add(addButton);
        buttonPanel.add(showButton);
        buttonPanel.add(generateReportButton);
        buttonPanel.add(jasperReportButton);

        // Layout
        add(datePanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    // Generate Unregistered Class Report with validation
    private void generateUnregisteredClassReport() {
        String startDate = startDateField.getText().trim();
        String endDate = endDateField.getText().trim();

        // Validate dates
        if (!isValidDate(startDate) || !isValidDate(endDate)) {
            JOptionPane.showMessageDialog(this, 
                "Please enter valid dates in YYYY-MM-DD format.", 
                "Invalid Date Format", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (startDate.compareTo(endDate) > 0) {
            JOptionPane.showMessageDialog(this, 
                "Start date must be before or equal to end date.", 
                "Invalid Date Range", JOptionPane.ERROR_MESSAGE);
            return;
        }

        control.generateUnregisteredClassReport(startDate, endDate);
    }

    // Generate JasperReport
    private void generateJasperReport() {
        String startDate = startDateField.getText().trim();
        String endDate = endDateField.getText().trim();

        if (!isValidDate(startDate) || !isValidDate(endDate)) {
            JOptionPane.showMessageDialog(this, 
                "Please enter valid dates in YYYY-MM-DD format.", 
                "Invalid Date Format", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (startDate.compareTo(endDate) > 0) {
            JOptionPane.showMessageDialog(this, 
                "Start date must be before or equal to end date.", 
                "Invalid Date Range", JOptionPane.ERROR_MESSAGE);
            return;
        }

        control.generateUnregisteredClassJasperReport(startDate, endDate);
    }

    // Validate date format
    private boolean isValidDate(String dateStr) {
        try {
            LocalDate.parse(dateStr, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // Add row with all required fields for Unregistered Class Report
    public void addRow(String customerId, String firstName, String lastName, String phone, String email, int classesAttended, String registrationDate) {
        tableModel.addRow(new Object[]{customerId, firstName, lastName, phone, email, classesAttended, registrationDate});
    }

    // Legacy method for backward compatibility
    public void addRow(String customerId, String firstName, String lastName, String phone, String email, int totalClasses) {
        addRow(customerId, firstName, lastName, phone, email, totalClasses, "");
    }

    public void clearTable() {
        tableModel.setRowCount(0);
    }
}
