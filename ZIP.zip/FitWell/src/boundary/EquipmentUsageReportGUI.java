package boundary;

import control.EquipmentUsageReportControl;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class EquipmentUsageReportGUI extends JPanel {

    private DefaultTableModel tableModel;
    private JTable table;
    private EquipmentUsageReportControl control;

    // Input fields
    private JTextField equipmentIDField;
    private JTextField equipmentNameField;
    private JTextField usageDateField;
    private JTextField hoursUsedField;

    public EquipmentUsageReportGUI() {
        control = new EquipmentUsageReportControl(this);

        setLayout(new BorderLayout(10, 10));

        // ==== Input Form Panel ====
        JPanel inputPanel = new JPanel(new GridLayout(2, 4, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Add Equipment Usage Record"));

        equipmentIDField = new JTextField();
        equipmentNameField = new JTextField();
        usageDateField = new JTextField();
        usageDateField.setText("2024-01-15");
        hoursUsedField = new JTextField();

        inputPanel.add(new JLabel("Equipment ID:"));
        inputPanel.add(equipmentIDField);
        inputPanel.add(new JLabel("Equipment Name:"));
        inputPanel.add(equipmentNameField);
        inputPanel.add(new JLabel("Usage Date (YYYY-MM-DD):"));
        inputPanel.add(usageDateField);
        inputPanel.add(new JLabel("Hours Used:"));
        inputPanel.add(hoursUsedField);

        // ==== Table with Equipment Inventory Report columns ====
        tableModel = new DefaultTableModel(
                new Object[]{"Equipment ID", "Equipment Name", "Condition", "Purchase Date", "Times Used (Current Year)"}, 0);
        table = new JTable(tableModel);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        
        // Set column widths
        table.getColumnModel().getColumn(0).setPreferredWidth(80);   // Equipment ID
        table.getColumnModel().getColumn(1).setPreferredWidth(150);  // Equipment Name
        table.getColumnModel().getColumn(2).setPreferredWidth(100);  // Condition
        table.getColumnModel().getColumn(3).setPreferredWidth(120);  // Purchase Date
        table.getColumnModel().getColumn(4).setPreferredWidth(150);  // Times Used

        // ==== Buttons Panel ====
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setBorder(BorderFactory.createTitledBorder("Actions"));

        JButton addButton = new JButton("Add Usage Record");
        addButton.addActionListener(e -> control.addUsage());

        JButton showUsageButton = new JButton("Show Usage Data");
        showUsageButton.addActionListener(e -> control.loadUsageFromDB());

        JButton generateInventoryReportButton = new JButton("Generate Equipment Inventory Report");
        generateInventoryReportButton.addActionListener(e -> control.generateEquipmentInventoryReport());

        JButton generateJasperReportButton = new JButton("Generate PDF Report");
        generateJasperReportButton.addActionListener(e -> control.generateEquipmentInventoryJasperReport());

        buttonPanel.add(addButton);
        buttonPanel.add(showUsageButton);
        buttonPanel.add(generateInventoryReportButton);
        buttonPanel.add(generateJasperReportButton);

        // ==== Layout ====
        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    // === Methods used by Control ===

    // Add row for Equipment Inventory Report
    public void addRow(String equipmentID, String equipmentName, String condition, String purchaseDate, int timesUsed) {
        tableModel.addRow(new Object[]{equipmentID, equipmentName, condition, purchaseDate, timesUsed});
    }

    // Legacy method for usage data - kept for backward compatibility
    public void addRow(String equipmentID, String equipmentName, String usageDate, double hoursUsed) {
        // This method is used when showing usage data, not inventory report
        // We need to handle this differently since the table structure changed
        // For now, we'll add a temporary row or switch table model
        tableModel.addRow(new Object[]{equipmentID, equipmentName, "N/A", "N/A", "N/A"});
    }

    public void clearTable() {
        tableModel.setRowCount(0);
    }

    // === Getters for input fields ===
    public String getEquipmentID() {
        return equipmentIDField.getText().trim();
    }

    public String getEquipmentName() {
        return equipmentNameField.getText().trim();
    }

    public String getUsageDate() {
        return usageDateField.getText().trim();
    }

    public double getHoursUsed() {
        try {
            return Double.parseDouble(hoursUsedField.getText().trim());
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    // Optional main method for quick test
    public static void main(String[] args) {
        JFrame frame = new JFrame("FitWell Equipment Usage");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 600);
        frame.add(new EquipmentUsageReportGUI());
        frame.setVisible(true);
    }
}
