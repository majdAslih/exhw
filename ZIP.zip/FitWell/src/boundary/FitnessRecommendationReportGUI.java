package boundary;

import control.FitnessRecommendationReportControl;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class FitnessRecommendationReportGUI extends JPanel {

    private JComboBox<String> classTypeCombo;
    private JTable table;
    private DefaultTableModel tableModel;
    private FitnessRecommendationReportControl control;

    public FitnessRecommendationReportGUI() {
        control = new FitnessRecommendationReportControl(this);

        setLayout(new BorderLayout(10, 10));

        // Top panel for input
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Fitness Recommendation Report Parameters"));
        
        inputPanel.add(new JLabel("Select Class Type:"));
        classTypeCombo = new JComboBox<>(control.getAvailableClassTypes());
        classTypeCombo.setSelectedIndex(0); // Default to first option
        inputPanel.add(classTypeCombo);

        JButton generateReportButton = new JButton("Generate Report");
        generateReportButton.addActionListener(e -> generateFitnessRecommendationReport());

        JButton jasperReportButton = new JButton("Generate PDF Report");
        jasperReportButton.addActionListener(e -> generateJasperReport());

        inputPanel.add(generateReportButton);
        inputPanel.add(jasperReportButton);

        add(inputPanel, BorderLayout.NORTH);

        // Table setup with proper columns for Fitness Recommendation Report
        tableModel = new DefaultTableModel(
                new Object[]{
                        "Class ID", "Class Name", "Schedule Date", "Class Type", 
                        "Age From", "Age To", "Guidance", "Plan Start Time", 
                        "Duration", "Status", "Plan ID", "Instructor First Name", 
                        "Instructor Last Name", "Phone", "Email", "Specialization"
                }, 0
        );
        table = new JTable(tableModel);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        
        // Set column widths
        table.getColumnModel().getColumn(0).setPreferredWidth(60);   // Class ID
        table.getColumnModel().getColumn(1).setPreferredWidth(120);  // Class Name
        table.getColumnModel().getColumn(2).setPreferredWidth(100);  // Schedule Date
        table.getColumnModel().getColumn(3).setPreferredWidth(80);   // Class Type
        table.getColumnModel().getColumn(4).setPreferredWidth(60);   // Age From
        table.getColumnModel().getColumn(5).setPreferredWidth(60);   // Age To
        table.getColumnModel().getColumn(6).setPreferredWidth(120);  // Guidance
        table.getColumnModel().getColumn(7).setPreferredWidth(80);   // Plan Start Time
        table.getColumnModel().getColumn(8).setPreferredWidth(60);   // Duration
        table.getColumnModel().getColumn(9).setPreferredWidth(80);   // Status
        table.getColumnModel().getColumn(10).setPreferredWidth(60);  // Plan ID
        table.getColumnModel().getColumn(11).setPreferredWidth(100); // Instructor First Name
        table.getColumnModel().getColumn(12).setPreferredWidth(100); // Instructor Last Name
        table.getColumnModel().getColumn(13).setPreferredWidth(100); // Phone
        table.getColumnModel().getColumn(14).setPreferredWidth(150); // Email
        table.getColumnModel().getColumn(15).setPreferredWidth(120); // Specialization

        add(new JScrollPane(table), BorderLayout.CENTER);

        // Add info panel
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        infoPanel.setBorder(BorderFactory.createTitledBorder("Report Information"));
        JLabel infoLabel = new JLabel("This report shows classes of the selected type planned for next week across all plans.");
        infoPanel.add(infoLabel);
        add(infoPanel, BorderLayout.SOUTH);
    }

    // Generate Fitness Recommendation Report
    private void generateFitnessRecommendationReport() {
        String selectedClassType = (String) classTypeCombo.getSelectedItem();
        if (selectedClassType != null && !selectedClassType.trim().isEmpty()) {
            control.generateFitnessRecommendationReport(selectedClassType);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a class type.", "No Class Type Selected", JOptionPane.WARNING_MESSAGE);
        }
    }

    // Generate JasperReport
    private void generateJasperReport() {
        String selectedClassType = (String) classTypeCombo.getSelectedItem();
        if (selectedClassType != null && !selectedClassType.trim().isEmpty()) {
            control.generateFitnessRecommendationJasperReport(selectedClassType);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a class type.", "No Class Type Selected", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void clearTable() {
        tableModel.setRowCount(0);
    }

    // Add row with all required fields for Fitness Recommendation Report
    public void addRow(int classId, String className, String scheduleDate, String classType, 
                      int ageFrom, int ageTo, String guidance, java.sql.Time startTime, 
                      int duration, String status, int planId, String firstName, 
                      String lastName, String phone, String email, String specialization) {
        tableModel.addRow(new Object[]{
            classId, className, scheduleDate, classType, ageFrom, ageTo, guidance,
            startTime, duration, status, planId, firstName, lastName, phone, email, specialization
        });
    }

    // Legacy method for backward compatibility
    public void addRow(Object... rowData) {
        tableModel.addRow(rowData);
    }
}
