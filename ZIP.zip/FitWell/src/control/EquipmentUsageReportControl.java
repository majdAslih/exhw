package control;

import boundary.EquipmentUsageReportGUI;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.swing.JRViewer;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;

public class EquipmentUsageReportControl {

    private EquipmentUsageReportGUI boundary;
    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public EquipmentUsageReportControl(EquipmentUsageReportGUI boundary) {
        this.boundary = boundary;
    }

    // Generate Equipment Inventory Report - overview of all equipment with usage counts
    public void generateEquipmentInventoryReport() {
        try {
            // SQL query to get equipment inventory with usage counts for current year
            String reportSQL = 
                "SELECT e.EquipmentID, e.EquipmentName, e.Condition, e.PurchaseDate, " +
                "COUNT(u.EquipmentID) AS TimesUsed " +
                "FROM [Equipment Table] e " +
                "LEFT JOIN [EquipmentUsageReport Table] u ON e.EquipmentID = u.EquipmentID " +
                "AND YEAR(u.UsageDate) = YEAR(DATE()) " + // Current year only
                "GROUP BY e.EquipmentID, e.EquipmentName, e.Condition, e.PurchaseDate " +
                "ORDER BY e.EquipmentName";

            try (Connection conn = DriverManager.getConnection(DB_URL);
                 PreparedStatement stmt = conn.prepareStatement(reportSQL);
                 ResultSet rs = stmt.executeQuery()) {

                boundary.clearTable();

                int reportCount = 0;
                while (rs.next()) {
                    String equipmentID = rs.getString("EquipmentID");
                    String equipmentName = rs.getString("EquipmentName");
                    String condition = rs.getString("Condition");
                    String purchaseDate = rs.getString("PurchaseDate");
                    int timesUsed = rs.getInt("TimesUsed");

                    boundary.addRow(equipmentID, equipmentName, condition, purchaseDate, timesUsed);
                    reportCount++;
                }

                if (reportCount == 0) {
                    JOptionPane.showMessageDialog(null, 
                        "No equipment found in the inventory.",
                        "Report Results", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, 
                        "Equipment Inventory Report generated successfully!\n" +
                        "Found " + reportCount + " equipment items with current year usage statistics.",
                        "Report Generated", JOptionPane.INFORMATION_MESSAGE);
                }

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error generating Equipment Inventory Report: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Generate JasperReport for Equipment Inventory Report
    public JFrame generateEquipmentInventoryJasperReport() {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                // Create parameters for the report
                HashMap<String, Object> parameters = new HashMap<>();
                parameters.put("reportTitle", "Equipment Inventory Report");
                parameters.put("currentYear", String.valueOf(java.time.Year.now().getValue()));
                parameters.put("generatedDate", java.time.LocalDate.now().toString());

                // Compile .jrxml to JasperReport
                String templatePath = "equipment_inventory_report.jrxml";
                JasperReport report = JasperCompileManager.compileReport(templatePath);

                // Fill report
                JasperPrint print = JasperFillManager.fillReport(report, parameters, conn);

                // Display in JFrame with JRViewer
                JFrame frame = new JFrame("Equipment Inventory Report");
                frame.getContentPane().add(new JRViewer(print));
                frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
                frame.pack();
                frame.setVisible(true);

                return frame;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error generating JasperReport: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    // Add usage record (GUI + DB)
    public void addUsage() {
        try {
            String equipmentID = boundary.getEquipmentID();
            String equipmentName = boundary.getEquipmentName();
            String usageDate = boundary.getUsageDate();
            double hours = boundary.getHoursUsed();

            // Validate input
            if (equipmentID.trim().isEmpty() || equipmentName.trim().isEmpty() || 
                usageDate.trim().isEmpty() || hours <= 0) {
                JOptionPane.showMessageDialog(null, "Please fill all fields with valid data.");
                return;
            }

            boundary.addRow(equipmentID, equipmentName, usageDate, hours);
            saveUsageToDB(equipmentID, equipmentName, usageDate, hours);

            JOptionPane.showMessageDialog(null, "✅ Usage record saved successfully.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error adding usage record: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Save usage record to database
    private void saveUsageToDB(String equipmentID, String equipmentName,
                               String usageDate, double hoursUsed) {
        String insertSQL =
                "INSERT INTO [EquipmentUsageReport Table] (EquipmentID, EquipmentName, UsageDate, HoursUsed) " +
                        "VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement stmt = conn.prepareStatement(insertSQL)) {

            stmt.setString(1, equipmentID);
            stmt.setString(2, equipmentName);
            stmt.setString(3, usageDate);
            stmt.setDouble(4, hoursUsed);
            stmt.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Failed to save usage record to database", e);
        }
    }

    // Load usage data from database for general viewing
    public void loadUsageFromDB() {
        String selectSQL = 
            "SELECT EquipmentID, EquipmentName, UsageDate, HoursUsed " +
            "FROM [EquipmentUsageReport Table] " +
            "ORDER BY UsageDate DESC, EquipmentName";

        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement stmt = conn.prepareStatement(selectSQL);
             ResultSet rs = stmt.executeQuery()) {

            boundary.clearTable();

            while (rs.next()) {
                String equipmentID = rs.getString("EquipmentID");
                String equipmentName = rs.getString("EquipmentName");
                String usageDate = rs.getString("UsageDate");
                double hoursUsed = rs.getDouble("HoursUsed");
                boundary.addRow(equipmentID, equipmentName, usageDate, hoursUsed);
            }

            JOptionPane.showMessageDialog(null, "✅ Equipment usage data loaded successfully.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading usage data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Legacy method - kept for backward compatibility
    public JFrame showReport() {
        return generateEquipmentInventoryJasperReport();
    }
}
