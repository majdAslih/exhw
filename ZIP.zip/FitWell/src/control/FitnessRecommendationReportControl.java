package control;

import boundary.FitnessRecommendationReportGUI;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.swing.JRViewer;

import javax.swing.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

public class FitnessRecommendationReportControl {

    private FitnessRecommendationReportGUI gui;
    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public FitnessRecommendationReportControl(FitnessRecommendationReportGUI gui) {
        this.gui = gui;
    }

    // Generate Fitness Recommendation Report - classes of specific type for next week
    public void generateFitnessRecommendationReport(String classType) {
        try {
            // Calculate date range for next week (use a fixed reference date for demo)
            // In production, this would be LocalDate.now().plusDays(7)
            LocalDate referenceDate = LocalDate.of(2024, 1, 15); // Use our sample data date
            LocalDate nextWeekStart = referenceDate.plusDays(7); // 2024-01-22
            LocalDate nextWeekEnd = nextWeekStart.plusDays(6);   // 2024-01-28
            
            String startDate = nextWeekStart.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            String endDate = nextWeekEnd.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

            // SQL query to find classes of specific type planned for next week
            String reportSQL = 
                "SELECT C.ClassID, C.className, C.instructorName, C.scedualDate, " +
                "C.startDate, C.endDate, C.maxnumber, " +
                "PD.classtype, PD.fromage, PD.toage, PD.guidence, " +
                "P.StartTime, P.duration, P.currentStatus, P.PlanID, " +
                "I.FirstName, I.LastName, I.Phone, I.Email, I.Specialization " +
                "FROM ClassTable C " +
                "INNER JOIN PDTable PD ON C.pdID = PD.pdID " +
                "INNER JOIN ClassesInPlan CP ON C.ClassID = CP.ClassID " +
                "INNER JOIN PlanTable P ON CP.PlanID = P.PlanID " +
                "INNER JOIN [Instructor Table] I ON P.InstructorID = I.InstructorID " +
                "WHERE PD.classtype = ? " +
                "AND C.scedualDate BETWEEN ? AND ? " +
                "ORDER BY P.StartTime, C.scedualDate";

            try (Connection conn = DriverManager.getConnection(DB_URL);
                 PreparedStatement ps = conn.prepareStatement(reportSQL)) {

                ps.setString(1, classType);
                ps.setString(2, startDate);
                ps.setString(3, endDate);

                ResultSet rs = ps.executeQuery();
                gui.clearTable();

                int reportCount = 0;
                while (rs.next()) {
                    gui.addRow(
                        rs.getInt("ClassID"),
                        rs.getString("className"),
                        rs.getString("scedualDate"),
                        rs.getString("classtype"),
                        rs.getInt("fromage"),
                        rs.getInt("toage"),
                        rs.getString("guidence"),
                        rs.getTime("StartTime"),
                        rs.getInt("duration"),
                        rs.getString("currentStatus"),
                        rs.getInt("PlanID"),
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("Phone"),
                        rs.getString("Email"),
                        rs.getString("Specialization")
                    );
                    reportCount++;
                }

                if (reportCount == 0) {
                    JOptionPane.showMessageDialog(null, 
                        "No " + classType + " classes found for next week (" + startDate + " to " + endDate + ").",
                        "Report Results", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, 
                        "Fitness Recommendation Report generated successfully!\n" +
                        "Found " + reportCount + " " + classType + " classes for next week.",
                        "Report Generated", JOptionPane.INFORMATION_MESSAGE);
                }

            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error generating Fitness Recommendation Report: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Generate JasperReport for Fitness Recommendation Report
    public JFrame generateFitnessRecommendationJasperReport(String classType) {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                // Calculate date range for next week (use a fixed reference date for demo)
                // In production, this would be LocalDate.now().plusDays(7)
                LocalDate referenceDate = LocalDate.of(2024, 1, 15); // Use our sample data date
                LocalDate nextWeekStart = referenceDate.plusDays(7); // 2024-01-22
                LocalDate nextWeekEnd = nextWeekStart.plusDays(6);   // 2024-01-28
                
                String startDate = nextWeekStart.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                String endDate = nextWeekEnd.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

                // Create parameters for the report
                HashMap<String, Object> parameters = new HashMap<>();
                parameters.put("classType", classType);
                parameters.put("startDate", startDate);
                parameters.put("endDate", endDate);
                parameters.put("reportTitle", "Fitness Recommendation Report - " + classType);
                parameters.put("period", "Next Week: " + startDate + " to " + endDate);

                // Compile .jrxml to JasperReport
                String templatePath = "fitness_recommendation_report.jrxml";
                JasperReport report = JasperCompileManager.compileReport(templatePath);

                // Fill report
                JasperPrint print = JasperFillManager.fillReport(report, parameters, conn);

                // Display in JFrame with JRViewer
                JFrame frame = new JFrame("Fitness Recommendation Report - " + classType);
                frame.getContentPane().add(new JRViewer(print));
                frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
                frame.pack();
                frame.setVisible(true);

                return frame;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error generating JasperReport: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    // Legacy method - kept for backward compatibility
    public void loadReport(String classType) {
        generateFitnessRecommendationReport(classType);
    }

    // Get available class types for the dropdown
    public String[] getAvailableClassTypes() {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement ps = conn.prepareStatement("SELECT DISTINCT classtype FROM PDTable ORDER BY classtype");
             ResultSet rs = ps.executeQuery()) {

            java.util.List<String> classTypes = new java.util.ArrayList<>();
            while (rs.next()) {
                classTypes.add(rs.getString("classtype"));
            }
            
            return classTypes.toArray(new String[0]);
        } catch (SQLException e) {
            e.printStackTrace();
            return new String[]{"Yoga", "Cardio", "Strength Training", "Pilates"}; // Fallback
        }
    }
}
