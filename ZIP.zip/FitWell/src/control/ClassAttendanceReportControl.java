package control;

import boundary.ClassAttendanceReportGUI;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.swing.JRViewer;

import javax.swing.*;
import java.sql.*;
import java.util.HashMap;

public class ClassAttendanceReportControl {

    private ClassAttendanceReportGUI boundary;
    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public ClassAttendanceReportControl(ClassAttendanceReportGUI boundary) {
        this.boundary = boundary;
    }

    // Generate Unregistered Class Report - customers registered to plans but attended < 5 classes
    public void generateUnregisteredClassReport(String startDate, String endDate) {
        try {
            // SQL query to find customers registered to plans but attended fewer than 5 classes
            String reportSQL = 
                "SELECT c.CustomerID, c.CustomerFirstName, c.CustomerLastName, c.phone, c.Email, " +
                "cp.RegistrationDate, " +
                "COUNT(a.CustomerID) AS ClassesAttended " +
                "FROM CustomerTable c " +
                "INNER JOIN CustomerPlans cp ON c.CustomerID = cp.CustomerID " +
                "LEFT JOIN [CustomerAttendance Table] a ON c.CustomerID = a.CustomerID " +
                "AND a.AttendanceDate BETWEEN ? AND ? " +
                "WHERE cp.RegistrationDate <= ? " + // Registered before or during the period
                "GROUP BY c.CustomerID, c.CustomerFirstName, c.CustomerLastName, c.phone, c.Email, cp.RegistrationDate " +
                "HAVING COUNT(a.CustomerID) < 5 " +
                "ORDER BY c.CustomerFirstName, c.CustomerLastName";

            try (Connection conn = DriverManager.getConnection(DB_URL);
                 PreparedStatement stmt = conn.prepareStatement(reportSQL)) {

                stmt.setString(1, startDate);
                stmt.setString(2, endDate);
                stmt.setString(3, endDate); // Registration date filter

                ResultSet rs = stmt.executeQuery();
                boundary.clearTable();

                int reportCount = 0;
                while (rs.next()) {
                    String customerId = rs.getString("CustomerID");
                    String firstName = rs.getString("CustomerFirstName");
                    String lastName = rs.getString("CustomerLastName");
                    String phone = rs.getString("phone");
                    String email = rs.getString("Email");
                    int classesAttended = rs.getInt("ClassesAttended");
                    String registrationDate = rs.getString("RegistrationDate");

                    boundary.addRow(customerId, firstName, lastName, phone, email, classesAttended, registrationDate);
                    reportCount++;
                }

                if (reportCount == 0) {
                    JOptionPane.showMessageDialog(null, 
                        "No customers found with fewer than 5 class attendances in the specified period.",
                        "Report Results", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, 
                        "Unregistered Class Report generated successfully!\n" +
                        "Found " + reportCount + " customers with fewer than 5 class attendances.",
                        "Report Generated", JOptionPane.INFORMATION_MESSAGE);
                }

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error generating Unregistered Class Report: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Generate JasperReport for Unregistered Class Report
    public JFrame generateUnregisteredClassJasperReport(String startDate, String endDate) {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                // Create parameters for the report
                HashMap<String, Object> parameters = new HashMap<>();
                parameters.put("startDate", startDate);
                parameters.put("endDate", endDate);
                parameters.put("reportTitle", "Unregistered Class Report");
                parameters.put("period", startDate + " to " + endDate);

                // Compile .jrxml to JasperReport
                String templatePath = "unregistered_class_report.jrxml";
                JasperReport report = JasperCompileManager.compileReport(templatePath);

                // Fill report
                JasperPrint print = JasperFillManager.fillReport(report, parameters, conn);

                // Display in JFrame with JRViewer
                JFrame frame = new JFrame("Unregistered Class Report - " + startDate + " to " + endDate);
                frame.getContentPane().add(new JRViewer(print));
                frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
                frame.pack();
                frame.setVisible(true);

                return frame;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error generating JasperReport: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    // Add a new attendance record
    public void addAttendance() {
        String customerId = JOptionPane.showInputDialog("Enter Customer ID:");
        if (customerId == null || customerId.trim().isEmpty()) return;

        String classId = JOptionPane.showInputDialog("Enter Class ID:");
        if (classId == null || classId.trim().isEmpty()) return;

        String attendanceDate = JOptionPane.showInputDialog("Enter Attendance Date (YYYY-MM-DD):");
        if (attendanceDate == null || attendanceDate.trim().isEmpty()) return;

        String endTime = JOptionPane.showInputDialog("Enter End Time (HH:MM):");
        if (endTime == null || endTime.trim().isEmpty()) return;

        try {
            saveAttendanceToDB(customerId, classId, attendanceDate, endTime);
            JOptionPane.showMessageDialog(null, "Attendance record added successfully!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error adding attendance: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Save attendance record to database
    private void saveAttendanceToDB(String customerId, String classId, String attendanceDate, String endTime) {
        String insertSQL = "INSERT INTO [CustomerAttendance Table] (CustomerID, ClassID, AttendanceDate, EndTime) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement stmt = conn.prepareStatement(insertSQL)) {

            stmt.setString(1, customerId);
            stmt.setString(2, classId);
            stmt.setString(3, attendanceDate);
            stmt.setString(4, endTime);

            stmt.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Failed to save attendance to database", e);
        }
    }

    // Load all attendance data for general viewing
    public void loadAttendanceFromDB() {
        String selectSQL = "SELECT c.CustomerID, c.CustomerFirstName, c.CustomerLastName, c.phone, c.Email, " +
                           "COUNT(a.CustomerID) AS TotalClasses " +
                           "FROM CustomerTable c " +
                           "LEFT JOIN [CustomerAttendance Table] a ON c.CustomerID = a.CustomerID " +
                           "GROUP BY c.CustomerID, c.CustomerFirstName, c.CustomerLastName, c.phone, c.Email " +
                           "ORDER BY c.CustomerFirstName, c.CustomerLastName";

        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement stmt = conn.prepareStatement(selectSQL);
             ResultSet rs = stmt.executeQuery()) {

            boundary.clearTable();

            while (rs.next()) {
                String customerId = rs.getString("CustomerID");
                String firstName = rs.getString("CustomerFirstName");
                String lastName = rs.getString("CustomerLastName");
                String phone = rs.getString("phone");
                String email = rs.getString("Email");
                int totalClasses = rs.getInt("TotalClasses");

                boundary.addRow(customerId, firstName, lastName, phone, email, totalClasses, "");
            }

            JOptionPane.showMessageDialog(null, "Attendance data loaded successfully.");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading attendance data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Legacy method - kept for backward compatibility
    public void showCustomersWithLessThanClasses(String startDate, String endDate, int maxClasses) {
        generateUnregisteredClassReport(startDate, endDate);
    }
}
