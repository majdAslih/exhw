package main;

import java.sql.*;

public class AddClassData {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Add class data for the Fitness Recommendation Report
                System.out.println("📊 Adding class data...");
                addClassData(conn);

                // Test the Fitness Recommendation Report query
                System.out.println("\n🔍 Testing Fitness Recommendation Report query...");
                testFitnessRecommendationQuery(conn);

                System.out.println("✅ Class data added successfully!");

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void addClassData(Connection conn) throws SQLException {
        // First, let's check what's already in the ClassTable
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as TotalClasses FROM ClassTable")) {
            
            if (rs.next()) {
                int totalClasses = rs.getInt("TotalClasses");
                System.out.println("  📊 Current classes in ClassTable: " + totalClasses);
            }
        }

        // Add classes for next week (2024-01-22 to 2024-01-28)
        // We'll add Yoga, Pilates, and Cardio classes
        String insertClassSQL = "INSERT INTO ClassTable (ClassID, ClassName, ScheduleDate, ClassType, AgeFrom, AgeTo, Guidance, PlanStartTime, Duration, StartTime, EndTime, InstructorID, PlanID) VALUES " +
                // Monday - Yoga classes
                "(101, 'Morning Yoga', #2024-01-22 07:00:00#, 'Yoga', 18, 65, 'Beginner friendly', #2024-01-22 07:00:00#, 60, #2024-01-22 07:00:00#, #2024-01-22 08:00:00#, 1, 1), " +
                "(102, 'Evening Yoga', #2024-01-22 18:00:00#, 'Yoga', 18, 65, 'All levels', #2024-01-22 18:00:00#, 60, #2024-01-22 18:00:00#, #2024-01-22 19:00:00#, 1, 1), " +
                // Tuesday - Pilates and Cardio
                "(103, 'Pilates Core', #2024-01-23 09:00:00#, 'Pilates', 18, 70, 'Intermediate', #2024-01-23 09:00:00#, 45, #2024-01-23 09:00:00#, #2024-01-23 09:45:00#, 2, 2), " +
                "(104, 'Cardio Blast', #2024-01-23 17:00:00#, 'Cardio', 16, 60, 'High intensity', #2024-01-23 17:00:00#, 45, #2024-01-23 17:00:00#, #2024-01-23 17:45:00#, 3, 3), " +
                // Wednesday - More Yoga
                "(105, 'Power Yoga', #2024-01-24 08:00:00#, 'Yoga', 18, 65, 'Advanced', #2024-01-24 08:00:00#, 75, #2024-01-24 08:00:00#, #2024-01-24 09:15:00#, 1, 1), " +
                "(106, 'Gentle Yoga', #2024-01-24 19:00:00#, 'Yoga', 18, 75, 'Senior friendly', #2024-01-24 19:00:00#, 60, #2024-01-24 19:00:00#, #2024-01-24 20:00:00#, 2, 2), " +
                // Thursday - Mixed classes
                "(107, 'Yoga Flow', #2024-01-25 07:30:00#, 'Yoga', 18, 65, 'Vinyasa style', #2024-01-25 07:30:00#, 60, #2024-01-25 07:30:00#, #2024-01-25 08:30:00#, 1, 1), " +
                "(108, 'Pilates Mat', #2024-01-25 16:00:00#, 'Pilates', 18, 70, 'All levels', #2024-01-25 16:00:00#, 45, #2024-01-25 16:00:00#, #2024-01-25 16:45:00#, 2, 2), " +
                // Friday - Weekend prep
                "(109, 'Friday Yoga', #2024-01-26 18:30:00#, 'Yoga', 18, 65, 'Weekend relaxation', #2024-01-26 18:30:00#, 60, #2024-01-26 18:30:00#, #2024-01-26 19:30:00#, 1, 1), " +
                // Saturday - Weekend classes
                "(110, 'Weekend Pilates', #2024-01-27 10:00:00#, 'Pilates', 18, 70, 'Weekend special', #2024-01-27 10:00:00#, 60, #2024-01-27 10:00:00#, #2024-01-27 11:00:00#, 2, 2), " +
                "(111, 'Saturday Cardio', #2024-01-27 14:00:00#, 'Cardio', 16, 60, 'Weekend workout', #2024-01-27 14:00:00#, 45, #2024-01-27 14:00:00#, #2024-01-27 14:45:00#, 3, 3), " +
                // Sunday - Relaxation
                "(112, 'Sunday Yoga', #2024-01-28 09:00:00#, 'Yoga', 18, 75, 'Sunday morning peace', #2024-01-28 09:00:00#, 60, #2024-01-28 09:00:00#, #2024-01-28 10:00:00#, 1, 1)";

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(insertClassSQL);
            System.out.println("  ✅ Added 12 classes for next week");
        }

        // Show what we added
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT ClassID, ClassName, ScheduleDate, ClassType, StartTime, EndTime, InstructorID, PlanID FROM ClassTable WHERE ScheduleDate BETWEEN #2024-01-22 00:00:00# AND #2024-01-28 23:59:59# ORDER BY ScheduleDate, StartTime")) {
            
            System.out.println("  📊 Classes added for next week:");
            while (rs.next()) {
                int classId = rs.getInt("ClassID");
                String className = rs.getString("ClassName");
                String scheduleDate = rs.getString("ScheduleDate");
                String classType = rs.getString("ClassType");
                String startTime = rs.getString("StartTime");
                String endTime = rs.getString("EndTime");
                int instructorId = rs.getInt("InstructorID");
                int planId = rs.getInt("PlanID");
                System.out.println("    " + classId + " | " + className + " | " + classType + " | " + scheduleDate + " | " + startTime + " - " + endTime + " | Instructor: " + instructorId + " | Plan: " + planId);
            }
        }
    }

    private static void testFitnessRecommendationQuery(Connection conn) throws SQLException {
        try {
            // Test the query that the Fitness Recommendation Report uses
            String query = 
                "SELECT c.ClassID, c.ClassName, c.ScheduleDate, c.ClassType, c.StartTime, c.EndTime, " +
                "p.PlanName, p.PlanDescription, p.PlanPrice, " +
                "i.InstructorFirstName, i.InstructorLastName, i.Specialization " +
                "FROM ClassTable c " +
                "INNER JOIN PlanTable p ON c.PlanID = p.PlanID " +
                "INNER JOIN [Instructor Table] i ON c.InstructorID = i.InstructorID " +
                "WHERE c.ClassType = 'Yoga' " +
                "AND c.ScheduleDate BETWEEN #2024-01-22 00:00:00# AND #2024-01-28 23:59:59# " +
                "ORDER BY c.StartTime";

            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {
                
                int count = 0;
                System.out.println("  📊 Fitness Recommendation Report results for Yoga classes:");
                while (rs.next()) {
                    count++;
                    int classId = rs.getInt("ClassID");
                    String className = rs.getString("ClassName");
                    String scheduleDate = rs.getString("ScheduleDate");
                    String startTime = rs.getString("StartTime");
                    String endTime = rs.getString("EndTime");
                    String planName = rs.getString("PlanName");
                    String planDescription = rs.getString("PlanDescription");
                    String instructorFirstName = rs.getString("InstructorFirstName");
                    String instructorLastName = rs.getString("InstructorLastName");
                    String specialization = rs.getString("Specialization");
                    
                    System.out.println("    " + count + ". " + className + " | " + scheduleDate + " | " + startTime + " - " + endTime);
                    System.out.println("       Plan: " + planName + " (" + planDescription + ")");
                    System.out.println("       Instructor: " + instructorFirstName + " " + instructorLastName + " (" + specialization + ")");
                    System.out.println();
                }
                System.out.println("  📈 Total Yoga classes found: " + count);
                System.out.println("  🎯 Expected: 6 Yoga classes should appear in report");
            }
        } catch (SQLException e) {
            System.out.println("  ❌ Query failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
