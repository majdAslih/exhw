package main;

import java.sql.*;

public class CheckAllTables {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Check all tables in the chain
                System.out.println("🔍 Checking all tables in the Fitness Recommendation Report chain...");
                checkAllTables(conn);

                // Test step by step
                System.out.println("\n🧪 Testing the query step by step...");
                testStepByStep(conn);

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void checkAllTables(Connection conn) throws SQLException {
        // 1. Check ClassTable
        System.out.println("\n📋 1. ClassTable (Yoga classes):");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT ClassID, className, pdID, scedualDate FROM ClassTable WHERE className LIKE '%Yoga%' AND scedualDate BETWEEN '2024-01-22' AND '2024-01-28' ORDER BY ClassID")) {
            
            while (rs.next()) {
                int classId = rs.getInt("ClassID");
                String className = rs.getString("className");
                int pdId = rs.getInt("pdID");
                String scheduleDate = rs.getString("scedualDate");
                System.out.println("    " + classId + " | " + className + " | PD: " + pdId + " | Date: " + scheduleDate);
            }
        }

        // 2. Check PDTable
        System.out.println("\n📋 2. PDTable (class types):");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT pdID, classtype FROM PDTable ORDER BY pdID")) {
            
            while (rs.next()) {
                int pdId = rs.getInt("pdID");
                String classType = rs.getString("classtype");
                System.out.println("    PD " + pdId + ": " + classType);
            }
        }

        // 3. Check ClassesInPlan
        System.out.println("\n📋 3. ClassesInPlan (class-plan links):");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT ClassID, PlanID FROM ClassesInPlan WHERE ClassID IN (101, 102, 105, 106, 107, 109, 112) ORDER BY ClassID")) {
            
            while (rs.next()) {
                int classId = rs.getInt("ClassID");
                int planId = rs.getInt("PlanID");
                System.out.println("    Class " + classId + " → Plan " + planId);
            }
        }

        // 4. Check PlanTable
        System.out.println("\n📋 4. PlanTable (plans):");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT PlanID, PlanName, InstructorID FROM PlanTable ORDER BY PlanID")) {
            
            while (rs.next()) {
                int planId = rs.getInt("PlanID");
                String planName = rs.getString("PlanName");
                int instructorId = rs.getInt("InstructorID");
                System.out.println("    Plan " + planId + ": " + planName + " | Instructor: " + instructorId);
            }
        }

        // 5. Check Instructor Table
        System.out.println("\n📋 5. Instructor Table (instructors):");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT InstructorID, FirstName, LastName, Specialization FROM [Instructor Table] ORDER BY InstructorID")) {
            
            while (rs.next()) {
                int instructorId = rs.getInt("InstructorID");
                String firstName = rs.getString("FirstName");
                String lastName = rs.getString("LastName");
                String specialization = rs.getString("Specialization");
                System.out.println("    Instructor " + instructorId + ": " + firstName + " " + lastName + " (" + specialization + ")");
            }
        }
    }

    private static void testStepByStep(Connection conn) throws SQLException {
        // Test 1: ClassTable + PDTable join
        System.out.println("\n🔍 Test 1: ClassTable + PDTable join:");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                "SELECT C.ClassID, C.className, PD.classtype, C.scedualDate " +
                "FROM ClassTable C " +
                "INNER JOIN PDTable PD ON C.pdID = PD.pdID " +
                "WHERE PD.classtype = 'Yoga' " +
                "AND C.scedualDate BETWEEN '2024-01-22' AND '2024-01-28' " +
                "ORDER BY C.ClassID")) {
            
            int count = 0;
            while (rs.next()) {
                count++;
                int classId = rs.getInt("ClassID");
                String className = rs.getString("className");
                String classType = rs.getString("classtype");
                String scheduleDate = rs.getString("scedualDate");
                System.out.println("    " + count + ". " + className + " | " + classType + " | " + scheduleDate);
            }
            System.out.println("    Total: " + count + " Yoga classes found");
        }

        // Test 2: Add ClassesInPlan join
        System.out.println("\n🔍 Test 2: + ClassesInPlan join:");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                "SELECT C.ClassID, C.className, PD.classtype, C.scedualDate, CP.PlanID " +
                "FROM ClassTable C " +
                "INNER JOIN PDTable PD ON C.pdID = PD.pdID " +
                "INNER JOIN ClassesInPlan CP ON C.ClassID = CP.ClassID " +
                "WHERE PD.classtype = 'Yoga' " +
                "AND C.scedualDate BETWEEN '2024-01-22' AND '2024-01-28' " +
                "ORDER BY C.ClassID")) {
            
            int count = 0;
            while (rs.next()) {
                count++;
                int classId = rs.getInt("ClassID");
                String className = rs.getString("className");
                String classType = rs.getString("classtype");
                String scheduleDate = rs.getString("scedualDate");
                int planId = rs.getInt("PlanID");
                System.out.println("    " + count + ". " + className + " | " + classType + " | " + scheduleDate + " | Plan: " + planId);
            }
            System.out.println("    Total: " + count + " Yoga classes with plan links found");
        }

        // Test 3: Add PlanTable join
        System.out.println("\n🔍 Test 3: + PlanTable join:");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                "SELECT C.ClassID, C.className, PD.classtype, C.scedualDate, CP.PlanID, P.PlanName, P.InstructorID " +
                "FROM ClassTable C " +
                "INNER JOIN PDTable PD ON C.pdID = PD.pdID " +
                "INNER JOIN ClassesInPlan CP ON C.ClassID = CP.ClassID " +
                "INNER JOIN PlanTable P ON CP.PlanID = P.PlanID " +
                "WHERE PD.classtype = 'Yoga' " +
                "AND C.scedualDate BETWEEN '2024-01-22' AND '2024-01-28' " +
                "ORDER BY C.ClassID")) {
            
            int count = 0;
            while (rs.next()) {
                count++;
                int classId = rs.getInt("ClassID");
                String className = rs.getString("className");
                String classType = rs.getString("classtype");
                String scheduleDate = rs.getString("scedualDate");
                int planId = rs.getInt("PlanID");
                String planName = rs.getString("PlanName");
                int instructorId = rs.getInt("InstructorID");
                System.out.println("    " + count + ". " + className + " | " + classType + " | " + scheduleDate + " | Plan: " + planId + " (" + planName + ") | Instructor: " + instructorId);
            }
            System.out.println("    Total: " + count + " Yoga classes with plan details found");
        }
    }
}
