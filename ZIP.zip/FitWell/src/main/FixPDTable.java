package main;

import java.sql.*;

public class FixPDTable {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Check PDTable structure and data
                System.out.println("🔍 Checking PDTable...");
                checkPDTable(conn);

                // Fix PDTable if needed
                System.out.println("\n🔧 Fixing PDTable...");
                fixPDTable(conn);

                // Test the actual Fitness Recommendation Report query
                System.out.println("\n🧪 Testing actual Fitness Recommendation Report query...");
                testActualQuery(conn);

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void checkPDTable(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as TotalRecords FROM PDTable")) {
            
            if (rs.next()) {
                int totalRecords = rs.getInt("TotalRecords");
                System.out.println("  📊 Total records in PDTable: " + totalRecords);
            }
        }

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM PDTable ORDER BY pdID")) {
            
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            
            System.out.println("  📋 PDTable structure and data:");
            while (rs.next()) {
                System.out.print("    Record: ");
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = metaData.getColumnName(i);
                    String value = rs.getString(i);
                    System.out.print(columnName + "=" + value + " | ");
                }
                System.out.println();
            }
        }
    }

    private static void fixPDTable(Connection conn) throws SQLException {
        // Check if PDTable has the right class types
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT DISTINCT classtype FROM PDTable")) {
            
            System.out.println("  📊 Current class types in PDTable:");
            boolean hasYoga = false;
            while (rs.next()) {
                String classType = rs.getString("classtype");
                System.out.println("    " + classType);
                if ("Yoga".equalsIgnoreCase(classType)) {
                    hasYoga = true;
                }
            }

            if (!hasYoga) {
                System.out.println("  ❌ PDTable missing Yoga class type! Adding it...");
                
                // Add Yoga class type to PDTable
                String insertSQL = "INSERT INTO PDTable (pdID, classtype, fromage, toage, guidence) VALUES " +
                        "(4, 'Yoga', 18, 65, 'Mind-body wellness')";

                try (Statement insertStmt = conn.createStatement()) {
                    insertStmt.execute(insertSQL);
                    System.out.println("  ✅ Added Yoga class type to PDTable");
                }
            } else {
                System.out.println("  ✅ PDTable has Yoga class type");
            }
        }
    }

    private static void testActualQuery(Connection conn) throws SQLException {
        try {
            // Test the EXACT query that the Fitness Recommendation Report uses
            String reportSQL = 
                "SELECT C.ClassID, C.className, C.instructorName, C.scedualDate, " +
                "C.startDate, C.endDate, C.maxnumber, " +
                "PD.classtype, PD.fromage, PD.toage, PD.guidence, " +
                "P.StartTime, P.duration, P.currentStatus, P.PlanID, " +
                "I.FirstName, I.LastName, I.Phone, I.Email, I.Specialization " +
                "FROM ClassTable C " +
                "INNER JOIN PDTable PD ON C.pdID = PD.pdID " +
                "INNER JOIN ClassesInPlan CP ON C.ClassID = CP.ClassID " +
                "INNER JOIN PlanTable P ON CP.PlanID = P.PlanID " +
                "INNER JOIN [Instructor Table] I ON P.InstructorID = I.InstructorID " +
                "WHERE PD.classtype = 'Yoga' " +
                "AND C.scedualDate BETWEEN '2024-01-22' AND '2024-01-28' " +
                "ORDER BY P.StartTime, C.scedualDate";

            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(reportSQL)) {
                
                int count = 0;
                System.out.println("  📊 Actual Fitness Recommendation Report query results:");
                while (rs.next()) {
                    count++;
                    int classId = rs.getInt("ClassID");
                    String className = rs.getString("className");
                    String scheduleDate = rs.getString("scedualDate");
                    String classType = rs.getString("classtype");
                    String instructorFirstName = rs.getString("FirstName");
                    String instructorLastName = rs.getString("LastName");
                    String specialization = rs.getString("Specialization");
                    
                    System.out.println("    " + count + ". " + className + " | " + scheduleDate + " | " + classType);
                    System.out.println("       Instructor: " + instructorFirstName + " " + instructorLastName + " (" + specialization + ")");
                    System.out.println();
                }
                System.out.println("  📈 Total Yoga classes found by actual query: " + count);
                System.out.println("  🎯 Expected: Should find Yoga classes if all tables are properly linked");
            }
        } catch (SQLException e) {
            System.out.println("  ❌ Query failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
