package main;

import java.sql.*;

public class FixPlanTable {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Fix PlanTable structure and data
                System.out.println("🔧 Fixing PlanTable...");
                fixPlanTable(conn);

                // Test the actual Fitness Recommendation Report query again
                System.out.println("\n🧪 Testing actual Fitness Recommendation Report query again...");
                testActualQuery(conn);

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void fixPlanTable(Connection conn) throws SQLException {
        // First, let's add the missing columns to PlanTable
        try {
            // Add PlanName column
            try (Statement stmt = conn.createStatement()) {
                stmt.execute("ALTER TABLE PlanTable ADD COLUMN PlanName VARCHAR(100)");
                System.out.println("  ✅ Added PlanName column");
            }
        } catch (SQLException e) {
            System.out.println("  ℹ️ PlanName column might already exist: " + e.getMessage());
        }

        try {
            // Add duration column
            try (Statement stmt = conn.createStatement()) {
                stmt.execute("ALTER TABLE PlanTable ADD COLUMN duration INTEGER");
                System.out.println("  ✅ Added duration column");
            }
        } catch (SQLException e) {
            System.out.println("  ℹ️ duration column might already exist: " + e.getMessage());
        }

        try {
            // Add currentStatus column
            try (Statement stmt = conn.createStatement()) {
                stmt.execute("ALTER TABLE PlanTable ADD COLUMN currentStatus VARCHAR(50)");
                System.out.println("  ✅ Added currentStatus column");
            }
        } catch (SQLException e) {
            System.out.println("  ℹ️ currentStatus column might already exist: " + e.getMessage());
        }

        try {
            // Add InstructorID column
            try (Statement stmt = conn.createStatement()) {
                stmt.execute("ALTER TABLE PlanTable ADD COLUMN InstructorID INTEGER");
                System.out.println("  ✅ Added InstructorID column");
            }
        } catch (SQLException e) {
            System.out.println("  ℹ️ InstructorID column might already exist: " + e.getMessage());
        }

        // Now add plan data
        System.out.println("  📊 Adding plan data...");
        String insertSQL = "INSERT INTO PlanTable (PlanID, PlanName, StartTime, duration, currentStatus, InstructorID) VALUES " +
                "(1, 'Basic Fitness Plan', #2024-01-01 06:00:00#, 60, 'Active', 1), " +
                "(2, 'Intermediate Plan', #2024-01-01 07:00:00#, 45, 'Active', 2), " +
                "(3, 'Advanced Plan', #2024-01-01 08:00:00#, 45, 'Active', 3)";

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(insertSQL);
            System.out.println("  ✅ Added 3 plans to PlanTable");
        }

        // Show what we added
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT PlanID, PlanName, StartTime, duration, currentStatus, InstructorID FROM PlanTable ORDER BY PlanID")) {
            
            System.out.println("  📊 Plans added to PlanTable:");
            while (rs.next()) {
                int planId = rs.getInt("PlanID");
                String planName = rs.getString("PlanName");
                String startTime = rs.getString("StartTime");
                int duration = rs.getInt("duration");
                String currentStatus = rs.getString("currentStatus");
                int instructorId = rs.getInt("InstructorID");
                System.out.println("    Plan " + planId + ": " + planName + " | " + startTime + " | " + duration + "min | " + currentStatus + " | Instructor: " + instructorId);
            }
        }
    }

    private static void testActualQuery(Connection conn) throws SQLException {
        try {
            // Test the EXACT query that the Fitness Recommendation Report uses
            String reportSQL = 
                "SELECT C.ClassID, C.className, C.instructorName, C.scedualDate, " +
                "C.startDate, C.endDate, C.maxnumber, " +
                "PD.classtype, PD.fromage, PD.toage, PD.guidence, " +
                "P.StartTime, P.duration, P.currentStatus, P.PlanID, " +
                "I.FirstName, I.LastName, I.Phone, I.Email, I.Specialization " +
                "FROM ClassTable C " +
                "INNER JOIN PDTable PD ON C.pdID = PD.pdID " +
                "INNER JOIN ClassesInPlan CP ON C.ClassID = CP.ClassID " +
                "INNER JOIN PlanTable P ON CP.PlanID = P.PlanID " +
                "INNER JOIN [Instructor Table] I ON P.InstructorID = I.InstructorID " +
                "WHERE PD.classtype = 'Yoga' " +
                "AND C.scedualDate BETWEEN '2024-01-22' AND '2024-01-28' " +
                "ORDER BY P.StartTime, C.scedualDate";

            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(reportSQL)) {
                
                int count = 0;
                System.out.println("  📊 Actual Fitness Recommendation Report query results:");
                while (rs.next()) {
                    count++;
                    int classId = rs.getInt("ClassID");
                    String className = rs.getString("className");
                    String scheduleDate = rs.getString("scedualDate");
                    String classType = rs.getString("classtype");
                    String instructorFirstName = rs.getString("FirstName");
                    String instructorLastName = rs.getString("LastName");
                    String specialization = rs.getString("Specialization");
                    
                    System.out.println("    " + count + ". " + className + " | " + scheduleDate + " | " + classType);
                    System.out.println("       Instructor: " + instructorFirstName + " " + instructorLastName + " (" + specialization + ")");
                    System.out.println();
                }
                System.out.println("  📈 Total Yoga classes found by actual query: " + count);
                System.out.println("  🎯 Expected: Should now find Yoga classes with complete table chain!");
            }
        } catch (SQLException e) {
            System.out.println("  ❌ Query failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
