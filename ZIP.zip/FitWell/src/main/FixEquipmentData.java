package main;

import java.sql.*;

public class FixEquipmentData {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Populate equipment tables with data matching existing structure
                System.out.println("🔧 Populating equipment tables...");
                populateEquipmentTables(conn);

                // Test the Equipment Inventory Report query
                System.out.println("\n🧪 Testing Equipment Inventory Report query...");
                testEquipmentInventoryQuery(conn);

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void populateEquipmentTables(Connection conn) throws SQLException {
        // Check if Equipment Table has data, if not add sample equipment
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM [Equipment Table]")) {
            
            if (rs.next() && rs.getInt(1) == 0) {
                System.out.println("  📊 Adding sample equipment data...");
                
                // Using the existing table structure: EquipmentID (SMALLINT), EquipmentName, Condition, PurchaseDate
                String insertEquipmentSQL = "INSERT INTO [Equipment Table] (EquipmentID, EquipmentName, Condition, PurchaseDate) VALUES " +
                        "(1, 'Treadmill Pro', 'Excellent', #2023-01-15 00:00:00#), " +
                        "(2, 'Weight Bench', 'Good', #2023-02-20 00:00:00#), " +
                        "(3, 'Exercise Bike', 'Fair', #2022-11-10 00:00:00#), " +
                        "(4, 'Dumbbells Set', 'Excellent', #2023-03-05 00:00:00#), " +
                        "(5, 'Yoga Mats', 'Good', #2023-01-30 00:00:00#), " +
                        "(6, 'Resistance Bands', 'Good', #2023-04-12 00:00:00#), " +
                        "(7, 'Pull-up Bar', 'Excellent', #2023-02-15 00:00:00#), " +
                        "(8, 'Foam Roller', 'Fair', #2022-12-08 00:00:00#)";

                try (Statement insertStmt = conn.createStatement()) {
                    insertStmt.execute(insertEquipmentSQL);
                    System.out.println("  ✅ Added 8 equipment items");
                }
            } else {
                System.out.println("  ✅ [Equipment Table] already has data");
            }
        }

        // Check if EquipmentUsageReport Table has data, if not add sample usage records
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM [EquipmentUsageReport Table]")) {
            
            if (rs.next() && rs.getInt(1) == 0) {
                System.out.println("  📊 Adding sample equipment usage data for 2024...");
                
                // Using the existing table structure: EquipmentID (SMALLINT), EquipmentName, UsageDate, HoursUsed
                String insertUsageSQL = "INSERT INTO [EquipmentUsageReport Table] (EquipmentID, EquipmentName, UsageDate, HoursUsed) VALUES " +
                        // Treadmill usage in 2024
                        "(1, 'Treadmill Pro', #2024-01-15 00:00:00#, 2.5), " +
                        "(1, 'Treadmill Pro', #2024-01-22 00:00:00#, 3.0), " +
                        "(1, 'Treadmill Pro', #2024-02-01 00:00:00#, 2.0), " +
                        "(1, 'Treadmill Pro', #2024-02-08 00:00:00#, 2.5), " +
                        // Weight Bench usage in 2024
                        "(2, 'Weight Bench', #2024-01-16 00:00:00#, 1.5), " +
                        "(2, 'Weight Bench', #2024-01-23 00:00:00#, 1.0), " +
                        "(2, 'Weight Bench', #2024-02-02 00:00:00#, 2.0), " +
                        // Exercise Bike usage in 2024
                        "(3, 'Exercise Bike', #2024-01-17 00:00:00#, 1.0), " +
                        "(3, 'Exercise Bike', #2024-01-24 00:00:00#, 1.5), " +
                        "(3, 'Exercise Bike', #2024-02-03 00:00:00#, 1.0), " +
                        "(3, 'Exercise Bike', #2024-02-10 00:00:00#, 2.0), " +
                        // Dumbbells usage in 2024
                        "(4, 'Dumbbells Set', #2024-01-18 00:00:00#, 0.5), " +
                        "(4, 'Dumbbells Set', #2024-01-25 00:00:00#, 0.5), " +
                        "(4, 'Dumbbells Set', #2024-02-04 00:00:00#, 0.5), " +
                        "(4, 'Dumbbells Set', #2024-02-11 00:00:00#, 0.5), " +
                        // Yoga Mats usage in 2024
                        "(5, 'Yoga Mats', #2024-01-19 00:00:00#, 1.0), " +
                        "(5, 'Yoga Mats', #2024-01-26 00:00:00#, 1.0), " +
                        "(5, 'Yoga Mats', #2024-02-05 00:00:00#, 1.0), " +
                        "(5, 'Yoga Mats', #2024-02-12 00:00:00#, 1.0), " +
                        // Resistance Bands usage in 2024
                        "(6, 'Resistance Bands', #2024-01-20 00:00:00#, 0.5), " +
                        "(6, 'Resistance Bands', #2024-01-27 00:00:00#, 0.5), " +
                        // Pull-up Bar usage in 2024
                        "(7, 'Pull-up Bar', #2024-01-21 00:00:00#, 0.5), " +
                        "(7, 'Pull-up Bar', #2024-01-28 00:00:00#, 0.5), " +
                        "(7, 'Pull-up Bar', #2024-02-06 00:00:00#, 0.5), " +
                        // Foam Roller usage in 2024
                        "(8, 'Foam Roller', #2024-01-29 00:00:00#, 0.25), " +
                        "(8, 'Foam Roller', #2024-02-07 00:00:00#, 0.25), " +
                        "(8, 'Foam Roller', #2024-02-13 00:00:00#, 0.25)";

                try (Statement insertStmt = conn.createStatement()) {
                    insertStmt.execute(insertUsageSQL);
                    System.out.println("  ✅ Added 27 usage records for 2024");
                }
            } else {
                System.out.println("  ✅ [EquipmentUsageReport Table] already has data");
            }
        }

        // Show what we have now
        System.out.println("\n📊 Current equipment data:");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT EquipmentID, EquipmentName, Condition, PurchaseDate FROM [Equipment Table] ORDER BY EquipmentID")) {
            
            while (rs.next()) {
                int equipmentId = rs.getInt("EquipmentID");
                String equipmentName = rs.getString("EquipmentName");
                String condition = rs.getString("Condition");
                String purchaseDate = rs.getString("PurchaseDate");
                System.out.println("    " + equipmentId + " | " + equipmentName + " | " + condition + " | " + purchaseDate);
            }
        }
    }

    private static void testEquipmentInventoryQuery(Connection conn) throws SQLException {
        try {
            // Test the EXACT query that the Equipment Inventory Report uses
            // But adapted to work with the existing table structure
            String reportSQL = 
                "SELECT e.EquipmentID, e.EquipmentName, e.Condition, e.PurchaseDate, " +
                "COUNT(u.EquipmentID) AS TimesUsed " +
                "FROM [Equipment Table] e " +
                "LEFT JOIN [EquipmentUsageReport Table] u ON e.EquipmentID = u.EquipmentID " +
                "AND YEAR(u.UsageDate) = 2024 " + // Current year 2024
                "GROUP BY e.EquipmentID, e.EquipmentName, e.Condition, e.PurchaseDate " +
                "ORDER BY e.EquipmentName";

            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(reportSQL)) {
                
                int count = 0;
                System.out.println("  📊 Equipment Inventory Report results:");
                while (rs.next()) {
                    count++;
                    int equipmentId = rs.getInt("EquipmentID");
                    String equipmentName = rs.getString("EquipmentName");
                    String condition = rs.getString("Condition");
                    String purchaseDate = rs.getString("PurchaseDate");
                    int timesUsed = rs.getInt("TimesUsed");
                    
                    System.out.println("    " + count + ". " + equipmentId + " | " + equipmentName + " | " + condition + " | " + purchaseDate + " | Times Used in 2024: " + timesUsed);
                }
                System.out.println("  📈 Total equipment items found: " + count);
                System.out.println("  🎯 Expected: 8 equipment items with usage counts for 2024");
            }
        } catch (SQLException e) {
            System.out.println("  ❌ Query failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
