package main;

import java.sql.*;

public class CheckAndPopulateEquipment {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Check equipment tables
                System.out.println("🔍 Checking equipment tables...");
                checkEquipmentTables(conn);

                // Populate equipment tables if needed
                System.out.println("\n🔧 Populating equipment tables...");
                populateEquipmentTables(conn);

                // Test the Equipment Inventory Report query
                System.out.println("\n🧪 Testing Equipment Inventory Report query...");
                testEquipmentInventoryQuery(conn);

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void checkEquipmentTables(Connection conn) throws SQLException {
        // Check Equipment Table
        try {
            System.out.println("\n📋 Checking [Equipment Table]...");
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM [Equipment Table]")) {
                
                if (rs.next()) {
                    int totalRecords = rs.getInt(1);
                    System.out.println("  📊 Total records in [Equipment Table]: " + totalRecords);
                }
            }

            // Check structure
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM [Equipment Table] WHERE 1=0")) {
                
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                
                System.out.println("  📋 [Equipment Table] structure:");
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = metaData.getColumnName(i);
                    String columnType = metaData.getColumnTypeName(i);
                    int columnSize = metaData.getColumnDisplaySize(i);
                    System.out.println("    Column " + i + ": " + columnName + " (" + columnType + ", size: " + columnSize + ")");
                }
            }

            // Show sample data if any exists
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT TOP 3 * FROM [Equipment Table]")) {
                
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                
                if (columnCount > 0) {
                    System.out.println("  📋 Sample data (first 3 records):");
                    while (rs.next()) {
                        System.out.print("    Record: ");
                        for (int i = 1; i <= columnCount; i++) {
                            String columnName = metaData.getColumnName(i);
                            String value = rs.getString(i);
                            System.out.print(columnName + "=" + value + " | ");
                        }
                        System.out.println();
                    }
                }
            }
            
        } catch (SQLException e) {
            System.out.println("  ❌ [Equipment Table] does not exist or is not accessible: " + e.getMessage());
        }

        // Check EquipmentUsageReport Table
        try {
            System.out.println("\n📋 Checking [EquipmentUsageReport Table]...");
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM [EquipmentUsageReport Table]")) {
                
                if (rs.next()) {
                    int totalRecords = rs.getInt(1);
                    System.out.println("  📊 Total records in [EquipmentUsageReport Table]: " + totalRecords);
                }
            }

            // Check structure
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM [EquipmentUsageReport Table] WHERE 1=0")) {
                
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                
                System.out.println("  📋 [EquipmentUsageReport Table] structure:");
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = metaData.getColumnName(i);
                    String columnType = metaData.getColumnTypeName(i);
                    int columnSize = metaData.getColumnDisplaySize(i);
                    System.out.println("    Column " + i + ": " + columnName + " (" + columnType + ", size: " + columnSize + ")");
                }
            }
            
        } catch (SQLException e) {
            System.out.println("  ❌ [EquipmentUsageReport Table] does not exist or is not accessible: " + e.getMessage());
        }
    }

    private static void populateEquipmentTables(Connection conn) throws SQLException {
        // First, let's create the Equipment Table if it doesn't exist
        try {
            String createEquipmentTableSQL = 
                "CREATE TABLE [Equipment Table] (" +
                "EquipmentID VARCHAR(10) PRIMARY KEY, " +
                "EquipmentName VARCHAR(100), " +
                "Condition VARCHAR(50), " +
                "PurchaseDate DATE)";
            
            try (Statement stmt = conn.createStatement()) {
                stmt.execute(createEquipmentTableSQL);
                System.out.println("  ✅ Created [Equipment Table]");
            }
        } catch (SQLException e) {
            System.out.println("  ℹ️ [Equipment Table] might already exist: " + e.getMessage());
        }

        // Create EquipmentUsageReport Table if it doesn't exist
        try {
            String createUsageTableSQL = 
                "CREATE TABLE [EquipmentUsageReport Table] (" +
                "UsageID INTEGER PRIMARY KEY, " +
                "EquipmentID VARCHAR(10), " +
                "UsageDate DATE, " +
                "HoursUsed DECIMAL(5,2))";
            
            try (Statement stmt = conn.createStatement()) {
                stmt.execute(createUsageTableSQL);
                System.out.println("  ✅ Created [EquipmentUsageReport Table]");
            }
        } catch (SQLException e) {
            System.out.println("  ℹ️ [EquipmentUsageReport Table] might already exist: " + e.getMessage());
        }

        // Check if Equipment Table has data, if not add sample equipment
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM [Equipment Table]")) {
            
            if (rs.next() && rs.getInt(1) == 0) {
                System.out.println("  📊 Adding sample equipment data...");
                
                String insertEquipmentSQL = "INSERT INTO [Equipment Table] (EquipmentID, EquipmentName, Condition, PurchaseDate) VALUES " +
                        "('EQ001', 'Treadmill Pro', 'Excellent', #2023-01-15#), " +
                        "('EQ002', 'Weight Bench', 'Good', #2023-02-20#), " +
                        "('EQ003', 'Exercise Bike', 'Fair', #2022-11-10#), " +
                        "('EQ004', 'Dumbbells Set', 'Excellent', #2023-03-05#), " +
                        "('EQ005', 'Yoga Mats', 'Good', #2023-01-30#), " +
                        "('EQ006', 'Resistance Bands', 'Good', #2023-04-12#), " +
                        "('EQ007', 'Pull-up Bar', 'Excellent', #2023-02-15#), " +
                        "('EQ008', 'Foam Roller', 'Fair', #2022-12-08#)";

                try (Statement insertStmt = conn.createStatement()) {
                    insertStmt.execute(insertEquipmentSQL);
                    System.out.println("  ✅ Added 8 equipment items");
                }
            } else {
                System.out.println("  ✅ [Equipment Table] already has data");
            }
        }

        // Check if EquipmentUsageReport Table has data, if not add sample usage records
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM [EquipmentUsageReport Table]")) {
            
            if (rs.next() && rs.getInt(1) == 0) {
                System.out.println("  📊 Adding sample equipment usage data for 2024...");
                
                String insertUsageSQL = "INSERT INTO [EquipmentUsageReport Table] (UsageID, EquipmentID, UsageDate, HoursUsed) VALUES " +
                        // Treadmill usage in 2024
                        "(1, 'EQ001', #2024-01-15#, 2.5), " +
                        "(2, 'EQ001', #2024-01-22#, 3.0), " +
                        "(3, 'EQ001', #2024-02-01#, 2.0), " +
                        "(4, 'EQ001', #2024-02-08#, 2.5), " +
                        // Weight Bench usage in 2024
                        "(5, 'EQ002', #2024-01-16#, 1.5), " +
                        "(6, 'EQ002', #2024-01-23#, 1.0), " +
                        "(7, 'EQ002', #2024-02-02#, 2.0), " +
                        // Exercise Bike usage in 2024
                        "(8, 'EQ003', #2024-01-17#, 1.0), " +
                        "(9, 'EQ003', #2024-01-24#, 1.5), " +
                        "(10, 'EQ003', #2024-02-03#, 1.0), " +
                        "(11, 'EQ003', #2024-02-10#, 2.0), " +
                        // Dumbbells usage in 2024
                        "(12, 'EQ004', #2024-01-18#, 0.5), " +
                        "(13, 'EQ004', #2024-01-25#, 0.5), " +
                        "(14, 'EQ004', #2024-02-04#, 0.5), " +
                        "(15, 'EQ004', #2024-02-11#, 0.5), " +
                        // Yoga Mats usage in 2024
                        "(16, 'EQ005', #2024-01-19#, 1.0), " +
                        "(17, 'EQ005', #2024-01-26#, 1.0), " +
                        "(18, 'EQ005', #2024-02-05#, 1.0), " +
                        "(19, 'EQ005', #2024-02-12#, 1.0), " +
                        // Resistance Bands usage in 2024
                        "(20, 'EQ006', #2024-01-20#, 0.5), " +
                        "(21, 'EQ006', #2024-01-27#, 0.5), " +
                        // Pull-up Bar usage in 2024
                        "(22, 'EQ007', #2024-01-21#, 0.5), " +
                        "(23, 'EQ007', #2024-01-28#, 0.5), " +
                        "(24, 'EQ007', #2024-02-06#, 0.5), " +
                        // Foam Roller usage in 2024
                        "(25, 'EQ008', #2024-01-29#, 0.25), " +
                        "(26, 'EQ008', #2024-02-07#, 0.25), " +
                        "(27, 'EQ008', #2024-02-13#, 0.25)";

                try (Statement insertStmt = conn.createStatement()) {
                    insertStmt.execute(insertUsageSQL);
                    System.out.println("  ✅ Added 27 usage records for 2024");
                }
            } else {
                System.out.println("  ✅ [EquipmentUsageReport Table] already has data");
            }
        }

        // Show what we have now
        System.out.println("\n📊 Current equipment data:");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT EquipmentID, EquipmentName, Condition, PurchaseDate FROM [Equipment Table] ORDER BY EquipmentID")) {
            
            while (rs.next()) {
                String equipmentId = rs.getString("EquipmentID");
                String equipmentName = rs.getString("EquipmentName");
                String condition = rs.getString("Condition");
                String purchaseDate = rs.getString("PurchaseDate");
                System.out.println("    " + equipmentId + " | " + equipmentName + " | " + condition + " | " + purchaseDate);
            }
        }
    }

    private static void testEquipmentInventoryQuery(Connection conn) throws SQLException {
        try {
            // Test the EXACT query that the Equipment Inventory Report uses
            String reportSQL = 
                "SELECT e.EquipmentID, e.EquipmentName, e.Condition, e.PurchaseDate, " +
                "COUNT(u.EquipmentID) AS TimesUsed " +
                "FROM [Equipment Table] e " +
                "LEFT JOIN [EquipmentUsageReport Table] u ON e.EquipmentID = u.EquipmentID " +
                "AND YEAR(u.UsageDate) = 2024 " + // Current year 2024
                "GROUP BY e.EquipmentID, e.EquipmentName, e.Condition, e.PurchaseDate " +
                "ORDER BY e.EquipmentName";

            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(reportSQL)) {
                
                int count = 0;
                System.out.println("  📊 Equipment Inventory Report results:");
                while (rs.next()) {
                    count++;
                    String equipmentId = rs.getString("EquipmentID");
                    String equipmentName = rs.getString("EquipmentName");
                    String condition = rs.getString("Condition");
                    String purchaseDate = rs.getString("PurchaseDate");
                    int timesUsed = rs.getInt("TimesUsed");
                    
                    System.out.println("    " + count + ". " + equipmentId + " | " + equipmentName + " | " + condition + " | " + purchaseDate + " | Times Used in 2024: " + timesUsed);
                }
                System.out.println("  📈 Total equipment items found: " + count);
                System.out.println("  🎯 Expected: 8 equipment items with usage counts for 2024");
            }
        } catch (SQLException e) {
            System.out.println("  ❌ Query failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
