import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 * Comprehensive Report Manager for FitWell Gym Management System
 * This class handles ALL reports and provides a unified interface for report generation
 */
public class ComprehensiveReportManager {
    
    private static final String DATABASE_PATH = "FitWell.accdb";
    private static final String REPORTS_DIR = "";
    
    // Define all available reports
    private static final String[] AVAILABLE_REPORTS = {
        "unregistered_class_report.jrxml",
        "equipment_inventory_report.jrxml", 
        "fitness_recommendation_report.jrxml",
        "report.jrxml"
    };
    
    private static final String[] REPORT_NAMES = {
        "Unregistered Class Report",
        "Equipment Inventory Report",
        "Fitness Recommendation Report", 
        "Equipment Usage Report"
    };
    
    /**
     * Main method to run the comprehensive report manager
     */
    public static void main(String[] args) {
        ComprehensiveReportManager manager = new ComprehensiveReportManager();
        
        try {
            // Check system requirements first
            System.out.println("=== FitWell Comprehensive Report Manager ===\n");
            manager.checkAllRequirements();
            
            // Show available reports
            manager.showAvailableReports();
            
            // Get user choice
            Scanner scanner = new Scanner(System.in);
            System.out.print("\nEnter the number of the report you want to generate (1-" + AVAILABLE_REPORTS.length + "): ");
            
            int choice = scanner.nextInt();
            if (choice >= 1 && choice <= AVAILABLE_REPORTS.length) {
                String selectedReport = AVAILABLE_REPORTS[choice - 1];
                String reportTitle = REPORT_NAMES[choice - 1];
                
                System.out.println("\nGenerating: " + reportTitle);
                manager.generateAndViewReport(selectedReport, reportTitle);
            } else {
                System.out.println("Invalid choice. Please run the program again.");
            }
            
            scanner.close();
            
        } catch (Exception e) {
            System.err.println("\n❌ Error in report manager: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Shows all available reports
     */
    public void showAvailableReports() {
        System.out.println("Available Reports:");
        System.out.println("=================");
        
        for (int i = 0; i < AVAILABLE_REPORTS.length; i++) {
            System.out.println((i + 1) + ". " + REPORT_NAMES[i]);
            System.out.println("   File: " + AVAILABLE_REPORTS[i]);
        }
    }
    
    /**
     * Generates and displays a specific report in JasperViewer
     * 
     * @param jrxmlFileName The JRXML file name
     * @param reportTitle The title to display in the viewer
     * @throws Exception if any error occurs
     */
    public void generateAndViewReport(String jrxmlFileName, String reportTitle) throws Exception {
        System.out.println("\nStarting report generation for: " + jrxmlFileName);
        
        // Step 1: Compile the JRXML file
        String jrxmlPath = REPORTS_DIR + jrxmlFileName;
        String jasperPath = REPORTS_DIR + jrxmlFileName.replace(".jrxml", ".jasper");
        
        JasperReport jasperReport = compileReport(jrxmlPath, jasperPath);
        System.out.println("✓ Report compiled successfully");
        
        // Step 2: Generate the report with appropriate parameters
        JasperPrint jasperPrint = generateReport(jasperReport, jrxmlFileName);
        System.out.println("✓ Report generated successfully");
        
        // Step 3: Display in JasperViewer
        displayReport(jasperPrint, reportTitle);
        System.out.println("✓ Report displayed in JasperViewer");
    }
    
    /**
     * Compiles a JRXML file to a JASPER file
     */
    private JasperReport compileReport(String jrxmlPath, String jasperPath) throws Exception {
        try {
            File jrxmlFile = new File(jrxmlPath);
            if (!jrxmlFile.exists()) {
                throw new Exception("JRXML file not found: " + jrxmlPath);
            }
            
            System.out.println("Compiling JRXML file: " + jrxmlPath);
            
            // Compile the JRXML file
            JasperCompileManager.compileReportToFile(jrxmlPath, jasperPath);
            
            // Load the compiled report
            JasperReport jasperReport = (JasperReport) JRLoader.loadObjectFromFile(jasperPath);
            
            return jasperReport;
            
        } catch (JRException e) {
            throw new Exception("Failed to compile JRXML file: " + e.getMessage(), e);
        }
    }
    
    /**
     * Generates a report using the compiled JasperReport with appropriate parameters
     */
    private JasperPrint generateReport(JasperReport jasperReport, String reportFileName) throws Exception {
        try {
            System.out.println("Generating report...");
            
            // Get database connection
            Connection connection = getDatabaseConnection();
            
            // Set report-specific parameters
            Map<String, Object> parameters = getReportParameters(reportFileName);
            
            // Fill the report
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, connection);
            
            // Close connection
            connection.close();
            
            return jasperPrint;
            
        } catch (Exception e) {
            throw new Exception("Failed to generate report: " + e.getMessage(), e);
        }
    }
    
    /**
     * Gets appropriate parameters for each report type
     */
    private Map<String, Object> getReportParameters(String reportFileName) {
        Map<String, Object> parameters = new HashMap<>();
        
        switch (reportFileName) {
            case "unregistered_class_report.jrxml":
                parameters.put("startDate", "2024-01-01");
                parameters.put("endDate", "2024-12-31");
                break;
                
            case "equipment_inventory_report.jrxml":
                parameters.put("currentYear", "2024");
                parameters.put("generatedDate", new java.util.Date().toString());
                break;
                
            case "fitness_recommendation_report.jrxml":
                parameters.put("classType", "Yoga");
                parameters.put("startDate", "2024-01-22");
                parameters.put("endDate", "2024-01-28");
                break;
                
            case "report.jrxml":
                // This report doesn't have parameters
                break;
                
            default:
                // Default parameters
                parameters.put("startDate", "2024-01-01");
                parameters.put("endDate", "2024-12-31");
                break;
        }
        
        return parameters;
    }
    
    /**
     * Displays the generated report in JasperViewer
     */
    private void displayReport(JasperPrint jasperPrint, String reportTitle) {
        try {
            System.out.println("Opening report in JasperViewer...");
            
            // Create and configure the viewer
            JasperViewer viewer = new JasperViewer(jasperPrint, false);
            viewer.setTitle(reportTitle);
            viewer.setVisible(true);
            
            System.out.println("Report viewer opened successfully");
            
        } catch (Exception e) {
            System.err.println("Error opening report viewer: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Establishes a connection to the Access database
     */
    private Connection getDatabaseConnection() throws Exception {
        try {
            File dbFile = new File(DATABASE_PATH);
            if (!dbFile.exists()) {
                throw new Exception("Database file not found: " + DATABASE_PATH);
            }
            
            String dbUrl = "jdbc:ucanaccess://" + dbFile.getAbsolutePath();
            
            // Load the UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            
            // Establish connection
            Connection connection = DriverManager.getConnection(dbUrl);
            
            System.out.println("✓ Database connection established");
            return connection;
            
        } catch (Exception e) {
            throw new Exception("Failed to connect to database: " + e.getMessage(), e);
        }
    }
    
    /**
     * Checks all system requirements for all reports
     */
    public void checkAllRequirements() {
        System.out.println("Checking system requirements for all reports...");
        System.out.println("===============================================");
        
        // Check database file
        File dbFile = new File(DATABASE_PATH);
        if (dbFile.exists()) {
            System.out.println("✓ Database file found: " + dbFile.getPath());
        } else {
            System.err.println("✗ Database file not found: " + dbFile.getPath());
        }
        
        // Check reports directory
        File reportsDir = new File(REPORTS_DIR);
        if (reportsDir.exists() && reportsDir.isDirectory()) {
            System.out.println("✓ Reports directory found: " + reportsDir.getPath());
        } else {
            System.err.println("✗ Reports directory not found: " + reportsDir.getPath());
        }
        
        // Check each JRXML file
        System.out.println("\nChecking individual report files:");
        for (String reportFile : AVAILABLE_REPORTS) {
            File jrxmlFile = new File(REPORTS_DIR + reportFile);
            if (jrxmlFile.exists()) {
                System.out.println("✓ " + reportFile + " found");
            } else {
                System.err.println("✗ " + reportFile + " not found");
            }
        }
        
        System.out.println("\nRequirements check completed.");
    }
    
    /**
     * Generates all reports in batch (useful for testing)
     */
    public void generateAllReports() throws Exception {
        System.out.println("\n=== Generating All Reports ===");
        
        for (int i = 0; i < AVAILABLE_REPORTS.length; i++) {
            try {
                System.out.println("\n" + (i + 1) + "/" + AVAILABLE_REPORTS.length + 
                                 " Generating: " + REPORT_NAMES[i]);
                
                generateAndViewReport(AVAILABLE_REPORTS[i], REPORT_NAMES[i]);
                
                // Small delay between reports
                Thread.sleep(2000);
                
            } catch (Exception e) {
                System.err.println("Failed to generate " + REPORT_NAMES[i] + ": " + e.getMessage());
            }
        }
        
        System.out.println("\nAll reports generation completed!");
    }
}
