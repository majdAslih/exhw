package main;

import java.sql.*;

public class CheckCustomerPlans {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Check CustomerPlans table
                System.out.println("🔍 Checking CustomerPlans table...");
                checkCustomerPlansTable(conn);

                // Fix if needed
                System.out.println("\n🔧 Fixing CustomerPlans table if needed...");
                fixCustomerPlansTable(conn);

                // Complete the attendance data
                System.out.println("\n📊 Completing attendance data...");
                completeAttendanceData(conn);

                // Test the final query
                System.out.println("\n🧪 Testing final query...");
                testFinalQuery(conn);

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void checkCustomerPlansTable(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as TotalRecords FROM CustomerPlans")) {
            
            if (rs.next()) {
                int totalRecords = rs.getInt("TotalRecords");
                System.out.println("  📊 Total records in CustomerPlans: " + totalRecords);
            }
        }

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT CustomerID, PlanID, RegistrationDate FROM CustomerPlans ORDER BY CustomerID")) {
            
            System.out.println("  📋 CustomerPlans data:");
            while (rs.next()) {
                int customerId = rs.getInt("CustomerID");
                int planId = rs.getInt("PlanID");
                String regDate = rs.getString("RegistrationDate");
                System.out.println("    Customer " + customerId + ": Plan " + planId + ", Reg: " + regDate);
            }
        }
    }

    private static void fixCustomerPlansTable(Connection conn) throws SQLException {
        // Check if table exists and has data
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM CustomerPlans")) {
            
            if (rs.next() && rs.getInt(1) == 0) {
                System.out.println("  ❌ CustomerPlans table is empty! Adding data...");
                
                String insertSQL = "INSERT INTO CustomerPlans (CustomerID, PlanID, RegistrationDate) VALUES " +
                        "(1, 1, '2024-01-01'), " +
                        "(2, 2, '2024-01-01'), " +
                        "(3, 3, '2024-01-01'), " +
                        "(4, 1, '2024-01-01'), " +
                        "(5, 2, '2024-01-01')";

                try (Statement insertStmt = conn.createStatement()) {
                    insertStmt.execute(insertSQL);
                    System.out.println("  ✅ Added CustomerPlans data");
                }
            } else {
                System.out.println("  ✅ CustomerPlans table has data");
            }
        }
    }

    private static void completeAttendanceData(Connection conn) throws SQLException {
        // Add missing attendance records
        String insertSQL = "INSERT INTO [CustomerAttendance Table] (CustomerID, ClassID, AttendanceDate, EndTime) VALUES " +
                // Complete Customer 3: 6 classes (should NOT appear in report)
                "(3, 2, #2024-01-15 10:00:00#, #2024-01-15 11:00:00#), " +
                "(3, 3, #2024-01-15 11:00:00#, #2024-01-15 12:00:00#), " +
                "(3, 4, #2024-01-15 12:00:00#, #2024-01-15 13:00:00#), " +
                "(3, 5, #2024-01-15 13:00:00#, #2024-01-15 14:00:00#), " +
                "(3, 6, #2024-01-15 14:00:00#, #2024-01-15 15:00:00#), " +
                // Complete Customer 4: 2 classes
                "(4, 1, #2024-01-15 09:00:00#, #2024-01-15 10:00:00#), " +
                "(4, 2, #2024-01-15 10:00:00#, #2024-01-15 11:00:00#), " +
                // Complete Customer 5: 1 class
                "(5, 1, #2024-01-15 09:00:00#, #2024-01-15 10:00:00#)";

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(insertSQL);
            System.out.println("  ✅ Completed attendance data for customers 3, 4, 5");
        }

        // Show final attendance data
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT CustomerID, COUNT(*) as ClassesAttended FROM [CustomerAttendance Table] GROUP BY CustomerID ORDER BY CustomerID")) {
            
            System.out.println("  📊 Final attendance data:");
            while (rs.next()) {
                int customerId = rs.getInt("CustomerID");
                int classesAttended = rs.getInt("ClassesAttended");
                System.out.println("    Customer " + customerId + ": " + classesAttended + " classes");
            }
        }
    }

    private static void testFinalQuery(Connection conn) throws SQLException {
        try {
            String query =
                "SELECT c.CustomerID, c.CustomerFirstName, c.CustomerLastName, " +
                "cp.RegistrationDate, COUNT(a.CustomerID) AS ClassesAttended " +
                "FROM CustomerTable c " +
                "INNER JOIN CustomerPlans cp ON c.CustomerID = cp.CustomerID " +
                "LEFT JOIN [CustomerAttendance Table] a ON c.CustomerID = a.CustomerID " +
                "AND a.AttendanceDate BETWEEN '2024-01-01' AND '2024-01-31' " +
                "WHERE cp.RegistrationDate <= '2024-01-31' " +
                "GROUP BY c.CustomerID, c.CustomerFirstName, c.CustomerLastName, cp.RegistrationDate " +
                "HAVING COUNT(a.CustomerID) < 5 " +
                "ORDER BY c.CustomerID";

            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {
                
                int count = 0;
                System.out.println("  📊 Final query results (customers with < 5 classes):");
                while (rs.next()) {
                    count++;
                    int customerId = rs.getInt("CustomerID");
                    String firstName = rs.getString("CustomerFirstName");
                    String lastName = rs.getString("CustomerLastName");
                    String regDate = rs.getString("RegistrationDate");
                    int classesAttended = rs.getInt("ClassesAttended");
                    System.out.println("    " + customerId + " | " + firstName + " " + lastName + " | Classes: " + classesAttended + " | Reg: " + regDate);
                }
                System.out.println("  📈 Total customers with < 5 classes: " + count);
                System.out.println("  🎯 Expected: 4 customers (IDs: 1,2,4,5) should appear in report");
            }
        } catch (SQLException e) {
            System.out.println("  ❌ Query failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
