package main;

import java.sql.*;

public class AddClassDataCorrected {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Add class data for the Fitness Recommendation Report
                System.out.println("📊 Adding class data...");
                addClassData(conn);

                // Test the Fitness Recommendation Report query
                System.out.println("\n🔍 Testing Fitness Recommendation Report query...");
                testFitnessRecommendationQuery(conn);

                System.out.println("✅ Class data added successfully!");

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void addClassData(Connection conn) throws SQLException {
        // First, let's check what's already in the ClassTable
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as TotalClasses FROM ClassTable")) {
            
            if (rs.next()) {
                int totalClasses = rs.getInt("TotalClasses");
                System.out.println("  📊 Current classes in ClassTable: " + totalClasses);
            }
        }

        // Add classes for next week (2024-01-22 to 2024-01-28)
        // Using the actual column names from the table structure
        String insertClassSQL = "INSERT INTO ClassTable (ClassID, className, instructorName, scedualDate, startDate, endDate, maxnumber, pdID) VALUES " +
                // Monday - Yoga classes
                "(101, 'Morning Yoga', 'Sarah Johnson', #2024-01-22 07:00:00#, #2024-01-22 07:00:00#, #2024-01-22 08:00:00#, 20, 1), " +
                "(102, 'Evening Yoga', 'Sarah Johnson', #2024-01-22 18:00:00#, #2024-01-22 18:00:00#, #2024-01-22 19:00:00#, 20, 1), " +
                // Tuesday - Pilates and Cardio
                "(103, 'Pilates Core', 'Mike Davis', #2024-01-23 09:00:00#, #2024-01-23 09:00:00#, #2024-01-23 09:45:00#, 15, 2), " +
                "(104, 'Cardio Blast', 'Alex Thompson', #2024-01-23 17:00:00#, #2024-01-23 17:00:00#, #2024-01-23 17:45:00#, 25, 3), " +
                // Wednesday - More Yoga
                "(105, 'Power Yoga', 'Sarah Johnson', #2024-01-24 08:00:00#, #2024-01-24 08:00:00#, #2024-01-24 09:15:00#, 20, 1), " +
                "(106, 'Gentle Yoga', 'Mike Davis', #2024-01-24 19:00:00#, #2024-01-24 19:00:00#, #2024-01-24 20:00:00#, 15, 2), " +
                // Thursday - Mixed classes
                "(107, 'Yoga Flow', 'Sarah Johnson', #2024-01-25 07:30:00#, #2024-01-25 07:30:00#, #2024-01-25 08:30:00#, 20, 1), " +
                "(108, 'Pilates Mat', 'Mike Davis', #2024-01-25 16:00:00#, #2024-01-25 16:00:00#, #2024-01-25 16:45:00#, 15, 2), " +
                // Friday - Weekend prep
                "(109, 'Friday Yoga', 'Sarah Johnson', #2024-01-26 18:30:00#, #2024-01-26 18:30:00#, #2024-01-26 19:30:00#, 20, 1), " +
                // Saturday - Weekend classes
                "(110, 'Weekend Pilates', 'Mike Davis', #2024-01-27 10:00:00#, #2024-01-27 10:00:00#, #2024-01-27 11:00:00#, 15, 2), " +
                "(111, 'Saturday Cardio', 'Alex Thompson', #2024-01-27 14:00:00#, #2024-01-27 14:00:00#, #2024-01-27 14:45:00#, 25, 3), " +
                // Sunday - Relaxation
                "(112, 'Sunday Yoga', 'Sarah Johnson', #2024-01-28 09:00:00#, #2024-01-28 09:00:00#, #2024-01-28 10:00:00#, 20, 1)";

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(insertClassSQL);
            System.out.println("  ✅ Added 12 classes for next week");
        }

        // Show what we added
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT ClassID, className, scedualDate, instructorName, startDate, endDate, pdID FROM ClassTable WHERE scedualDate BETWEEN #2024-01-22 00:00:00# AND #2024-01-28 23:59:59# ORDER BY scedualDate, startDate")) {
            
            System.out.println("  📊 Classes added for next week:");
            while (rs.next()) {
                int classId = rs.getInt("ClassID");
                String className = rs.getString("className");
                String scheduleDate = rs.getString("scedualDate");
                String instructorName = rs.getString("instructorName");
                String startDate = rs.getString("startDate");
                String endDate = rs.getString("endDate");
                int pdId = rs.getInt("pdID");
                System.out.println("    " + classId + " | " + className + " | " + instructorName + " | " + scheduleDate + " | " + startDate + " - " + endDate + " | PD: " + pdId);
            }
        }
    }

    private static void testFitnessRecommendationQuery(Connection conn) throws SQLException {
        try {
            // Test the query that the Fitness Recommendation Report uses
            // Note: We need to adapt this to work with the actual table structure
            String query = 
                "SELECT c.ClassID, c.className, c.scedualDate, c.startDate, c.endDate, " +
                "c.instructorName, c.maxnumber, c.pdID " +
                "FROM ClassTable c " +
                "WHERE c.className LIKE '%Yoga%' " +
                "AND c.scedualDate BETWEEN #2024-01-22 00:00:00# AND #2024-01-28 23:59:59# " +
                "ORDER BY c.startDate";

            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {
                
                int count = 0;
                System.out.println("  📊 Fitness Recommendation Report results for Yoga classes:");
                while (rs.next()) {
                    count++;
                    int classId = rs.getInt("ClassID");
                    String className = rs.getString("className");
                    String scheduleDate = rs.getString("scedualDate");
                    String startDate = rs.getString("startDate");
                    String endDate = rs.getString("endDate");
                    String instructorName = rs.getString("instructorName");
                    int maxNumber = rs.getInt("maxnumber");
                    int pdId = rs.getInt("pdID");
                    
                    System.out.println("    " + count + ". " + className + " | " + scheduleDate + " | " + startDate + " - " + endDate);
                    System.out.println("       Instructor: " + instructorName + " | Max: " + maxNumber + " | PD: " + pdId);
                    System.out.println();
                }
                System.out.println("  📈 Total Yoga classes found: " + count);
                System.out.println("  🎯 Expected: 6 Yoga classes should appear in report");
            }
        } catch (SQLException e) {
            System.out.println("  ❌ Query failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
