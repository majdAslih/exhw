import java.io.File;

/**
 * Simple test class to verify report generation setup
 */
public class TestReportGeneration {
    
    public static void main(String[] args) {
        System.out.println("=== FitWell JasperReport Generation Test ===\n");
        
        try {
            // Create the generator
            JasperReportGenerator generator = new JasperReportGenerator();
            
            // Check system requirements first
            System.out.println("Step 1: Checking system requirements...");
            generator.checkRequirements();
            System.out.println();
            
            // Test report generation
            System.out.println("Step 2: Testing report generation...");
            generator.generateAndViewReport("unregistered_class_report.jrxml", "Unregistered Class Report");
            
        } catch (Exception e) {
            System.err.println("\n❌ Error during report generation:");
            System.err.println("   " + e.getMessage());
            System.err.println("\nStack trace:");
            e.printStackTrace();
            
            // Provide helpful troubleshooting tips
            System.out.println("\n🔧 Troubleshooting Tips:");
            System.out.println("   1. Make sure all JasperReports JAR files are in the libs folder");
            System.out.println("   2. Verify the database file path is correct");
            System.out.println("   3. Check that the JRXML file has valid UUIDs");
            System.out.println("   4. Ensure you have write permissions in the reports directory");
        }
    }
}
