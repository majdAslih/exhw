import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;

/**
 * PDF Report Generator for FitWell Gym Management System
 * Generates JasperReports and exports them to PDF format
 */
public class PDFReportGenerator {
    
    private static final String DATABASE_PATH = "FitWell.accdb";
    private static final String REPORTS_DIR = "";
    private static final String OUTPUT_DIR = "generated_reports/";
    
    // Define all available reports
    private static final String[] AVAILABLE_REPORTS = {
        "unregistered_class_report.jrxml",
        "equipment_inventory_report.jrxml", 
        "fitness_recommendation_report.jrxml",
        "report.jrxml"
    };
    
    private static final String[] REPORT_NAMES = {
        "Unregistered_Class_Report",
        "Equipment_Inventory_Report",
        "Fitness_Recommendation_Report", 
        "Equipment_Usage_Report"
    };
    
    /**
     * Main method to generate PDF reports
     */
    public static void main(String[] args) {
        PDFReportGenerator generator = new PDFReportGenerator();
        
        try {
            // Create output directory
            File outputDir = new File(OUTPUT_DIR);
            if (!outputDir.exists()) {
                outputDir.mkdirs();
            }
            
            System.out.println("=== FitWell PDF Report Generator ===\n");
            generator.checkRequirements();
            
            // Generate all reports as PDFs
            for (int i = 0; i < AVAILABLE_REPORTS.length; i++) {
                try {
                    System.out.println("\n" + (i + 1) + "/" + AVAILABLE_REPORTS.length + 
                                     " Generating PDF: " + REPORT_NAMES[i]);
                    
                    String pdfPath = generator.generatePDFReport(AVAILABLE_REPORTS[i], REPORT_NAMES[i]);
                    System.out.println("✓ PDF generated: " + pdfPath);
                    
                } catch (Exception e) {
                    System.err.println("❌ Failed to generate " + REPORT_NAMES[i] + ": " + e.getMessage());
                    e.printStackTrace();
                }
            }
            
            System.out.println("\n🎉 All PDF reports generated successfully!");
            System.out.println("Check the 'generated_reports' folder for your PDF files.");
            
        } catch (Exception e) {
            System.err.println("\n❌ Error in PDF generation: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Generates a PDF report from a JRXML file
     * 
     * @param jrxmlFileName The JRXML file name
     * @param reportTitle The title for the PDF file
     * @return The path to the generated PDF file
     * @throws Exception if any error occurs
     */
    public String generatePDFReport(String jrxmlFileName, String reportTitle) throws Exception {
        System.out.println("  Starting PDF generation for: " + jrxmlFileName);
        
        // Step 1: Compile the JRXML file
        String jrxmlPath = REPORTS_DIR + jrxmlFileName;
        String jasperPath = REPORTS_DIR + jrxmlFileName.replace(".jrxml", ".jasper");
        
        JasperReport jasperReport = compileReport(jrxmlPath, jasperPath);
        System.out.println("  ✓ Report compiled successfully");
        
        // Step 2: Generate the report with appropriate parameters
        JasperPrint jasperPrint = generateReport(jasperReport, jrxmlFileName);
        System.out.println("  ✓ Report generated successfully");
        
        // Step 3: Export to PDF
        String pdfFileName = reportTitle + ".pdf";
        String pdfPath = OUTPUT_DIR + pdfFileName;
        
        exportToPDF(jasperPrint, pdfPath);
        System.out.println("  ✓ PDF exported successfully");
        
        return pdfPath;
    }
    
    /**
     * Compiles a JRXML file to a JASPER file
     */
    private JasperReport compileReport(String jrxmlPath, String jasperPath) throws Exception {
        try {
            File jrxmlFile = new File(jrxmlPath);
            if (!jrxmlFile.exists()) {
                throw new Exception("JRXML file not found: " + jrxmlPath);
            }
            
            // Compile the JRXML file
            JasperCompileManager.compileReportToFile(jrxmlPath, jasperPath);
            
            // Load the compiled report
            JasperReport jasperReport = (JasperReport) JRLoader.loadObjectFromFile(jasperPath);
            
            return jasperReport;
            
        } catch (JRException e) {
            throw new Exception("Failed to compile JRXML file: " + e.getMessage(), e);
        }
    }
    
    /**
     * Generates a report using the compiled JasperReport with appropriate parameters
     */
    private JasperPrint generateReport(JasperReport jasperReport, String reportFileName) throws Exception {
        try {
            // Get database connection
            Connection connection = getDatabaseConnection();
            
            // Set report-specific parameters
            Map<String, Object> parameters = getReportParameters(reportFileName);
            
            // Fill the report
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, connection);
            
            // Close connection
            connection.close();
            
            return jasperPrint;
            
        } catch (Exception e) {
            throw new Exception("Failed to generate report: " + e.getMessage(), e);
        }
    }
    
    /**
     * Exports a JasperPrint to PDF format
     */
    private void exportToPDF(JasperPrint jasperPrint, String pdfPath) throws Exception {
        try {
            JasperExportManager.exportReportToPdfFile(jasperPrint, pdfPath);
        } catch (JRException e) {
            throw new Exception("Failed to export to PDF: " + e.getMessage(), e);
        }
    }
    
    /**
     * Gets appropriate parameters for each report type
     */
    private Map<String, Object> getReportParameters(String reportFileName) {
        Map<String, Object> parameters = new HashMap<>();
        
        switch (reportFileName) {
            case "unregistered_class_report.jrxml":
                parameters.put("startDate", "2024-01-01");
                parameters.put("endDate", "2024-12-31");
                break;
                
            case "equipment_inventory_report.jrxml":
                parameters.put("currentYear", "2024");
                parameters.put("generatedDate", new java.util.Date().toString());
                break;
                
            case "fitness_recommendation_report.jrxml":
                parameters.put("classType", "Yoga");
                parameters.put("startDate", "2024-01-22");
                parameters.put("endDate", "2024-01-28");
                break;
                
            case "report.jrxml":
                // This report doesn't have parameters
                break;
                
            default:
                // Default parameters
                parameters.put("startDate", "2024-01-01");
                parameters.put("endDate", "2024-12-31");
                break;
        }
        
        return parameters;
    }
    
    /**
     * Establishes a connection to the Access database
     */
    private Connection getDatabaseConnection() throws Exception {
        try {
            File dbFile = new File(DATABASE_PATH);
            if (!dbFile.exists()) {
                throw new Exception("Database file not found: " + DATABASE_PATH);
            }
            
            String dbUrl = "jdbc:ucanaccess://" + dbFile.getAbsolutePath();
            
            // Load the UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            
            // Establish connection
            Connection connection = DriverManager.getConnection(dbUrl);
            
            return connection;
            
        } catch (Exception e) {
            throw new Exception("Failed to connect to database: " + e.getMessage(), e);
        }
    }
    
    /**
     * Checks system requirements
     */
    public void checkRequirements() {
        System.out.println("Checking system requirements...");
        System.out.println("=================================");
        
        // Check database file
        File dbFile = new File(DATABASE_PATH);
        if (dbFile.exists()) {
            System.out.println("✓ Database file found: " + dbFile.getPath());
        } else {
            System.err.println("✗ Database file not found: " + dbFile.getPath());
        }
        
        // Check reports directory
        File reportsDir = new File(REPORTS_DIR);
        if (reportsDir.exists() && reportsDir.isDirectory()) {
            System.out.println("✓ Reports directory found: " + reportsDir.getPath());
        } else {
            System.err.println("✗ Reports directory not found: " + reportsDir.getPath());
        }
        
        // Check each JRXML file
        System.out.println("\nChecking individual report files:");
        for (String reportFile : AVAILABLE_REPORTS) {
            File jrxmlFile = new File(REPORTS_DIR + reportFile);
            if (jrxmlFile.exists()) {
                System.out.println("✓ " + reportFile + " found");
            } else {
                System.err.println("✗ " + reportFile + " not found");
            }
        }
        
        System.out.println("\nRequirements check completed.");
    }
}

