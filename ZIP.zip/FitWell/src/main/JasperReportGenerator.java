import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 * JasperReport Generator for FitWell Gym Management System
 * This class handles the compilation, generation, and viewing of JasperReports
 */
public class JasperReportGenerator {
    
    private static final String DATABASE_PATH = "FitWell.accdb";
    private static final String REPORTS_DIR = "";
    
    /**
     * Main method to demonstrate report generation
     */
    public static void main(String[] args) {
        try {
            JasperReportGenerator generator = new JasperReportGenerator();
            
            // Generate and view the unregistered class report
            generator.generateAndViewReport("unregistered_class_report.jrxml", "Unregistered Class Report");
            
        } catch (Exception e) {
            System.err.println("Error generating report: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Generates and displays a report in JasperViewer
     * 
     * @param jrxmlFileName The JRXML file name
     * @param reportTitle The title to display in the viewer
     * @throws Exception if any error occurs
     */
    public void generateAndViewReport(String jrxmlFileName, String reportTitle) throws Exception {
        System.out.println("Starting report generation for: " + jrxmlFileName);
        
        // Step 1: Compile the JRXML file
        String jrxmlPath = REPORTS_DIR + jrxmlFileName;
        String jasperPath = REPORTS_DIR + jrxmlFileName.replace(".jrxml", ".jasper");
        
        JasperReport jasperReport = compileReport(jrxmlPath, jasperPath);
        System.out.println("✓ Report compiled successfully");
        
        // Step 2: Generate the report
        JasperPrint jasperPrint = generateReport(jasperReport);
        System.out.println("✓ Report generated successfully");
        
        // Step 3: Display in JasperViewer
        displayReport(jasperPrint, reportTitle);
        System.out.println("✓ Report displayed in JasperViewer");
    }
    
    /**
     * Compiles a JRXML file to a JASPER file
     * 
     * @param jrxmlPath Path to the JRXML file
     * @param jasperPath Path where the compiled JASPER file should be saved
     * @return Compiled JasperReport object
     * @throws Exception if compilation fails
     */
    private JasperReport compileReport(String jrxmlPath, String jasperPath) throws Exception {
        try {
            // Check if JRXML file exists
            File jrxmlFile = new File(jrxmlPath);
            if (!jrxmlFile.exists()) {
                throw new Exception("JRXML file not found: " + jrxmlPath);
            }
            
            System.out.println("Compiling JRXML file: " + jrxmlPath);
            
            // Compile the JRXML file
            JasperCompileManager.compileReportToFile(jrxmlPath, jasperPath);
            
            // Load the compiled report
            JasperReport jasperReport = (JasperReport) JRLoader.loadObjectFromFile(jasperPath);
            
            return jasperReport;
            
        } catch (JRException e) {
            throw new Exception("Failed to compile JRXML file: " + e.getMessage(), e);
        }
    }
    
    /**
     * Generates a report using the compiled JasperReport
     * 
     * @param jasperReport The compiled JasperReport
     * @return Generated JasperPrint object
     * @throws Exception if generation fails
     */
    private JasperPrint generateReport(JasperReport jasperReport) throws Exception {
        try {
            System.out.println("Generating report...");
            
            // Get database connection
            Connection connection = getDatabaseConnection();
            
            // Set report parameters
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("startDate", "2024-01-01");
            parameters.put("endDate", "2024-12-31");
            
            // Fill the report
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, connection);
            
            // Close connection
            connection.close();
            
            return jasperPrint;
            
        } catch (Exception e) {
            throw new Exception("Failed to generate report: " + e.getMessage(), e);
        }
    }
    
    /**
     * Displays the generated report in JasperViewer
     * 
     * @param jasperPrint The generated JasperPrint
     * @param reportTitle The title for the viewer window
     */
    private void displayReport(JasperPrint jasperPrint, String reportTitle) {
        try {
            System.out.println("Opening report in JasperViewer...");
            
            // Create and configure the viewer
            JasperViewer viewer = new JasperViewer(jasperPrint, false);
            viewer.setTitle(reportTitle);
            viewer.setVisible(true);
            
            System.out.println("Report viewer opened successfully");
            
        } catch (Exception e) {
            System.err.println("Error opening report viewer: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Establishes a connection to the Access database
     * 
     * @return Database connection
     * @throws Exception if connection fails
     */
    private Connection getDatabaseConnection() throws Exception {
        try {
            // Get the absolute path to the database file
            File dbFile = new File(DATABASE_PATH);
            if (!dbFile.exists()) {
                throw new Exception("Database file not found: " + DATABASE_PATH);
            }
            
            String dbUrl = "jdbc:ucanaccess://" + dbFile.getAbsolutePath();
            
            // Load the UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            
            // Establish connection
            Connection connection = DriverManager.getConnection(dbUrl);
            
            System.out.println("✓ Database connection established");
            return connection;
            
        } catch (Exception e) {
            throw new Exception("Failed to connect to database: " + e.getMessage(), e);
        }
    }
    
    /**
     * Utility method to check if all required files exist
     */
    public void checkRequirements() {
        System.out.println("Checking system requirements...");
        
        // Check JRXML file
        File jrxmlFile = new File(REPORTS_DIR + "unregistered_class_report.jrxml");
        if (jrxmlFile.exists()) {
            System.out.println("✓ JRXML file found: " + jrxmlFile.getPath());
        } else {
            System.err.println("✗ JRXML file not found: " + jrxmlFile.getPath());
        }
        
        // Check database file
        File dbFile = new File(DATABASE_PATH);
        if (dbFile.exists()) {
            System.out.println("✓ Database file found: " + dbFile.getPath());
        } else {
            System.err.println("✗ Database file not found: " + dbFile.getPath());
        }
        
        // Check reports directory
        File reportsDir = new File(REPORTS_DIR);
        if (reportsDir.exists() && reportsDir.isDirectory()) {
            System.out.println("✓ Reports directory found: " + reportsDir.getPath());
        } else {
            System.err.println("✗ Reports directory not found: " + reportsDir.getPath());
        }
        
        System.out.println("Requirements check completed.");
    }
}
