package main;

import java.sql.*;
import java.util.HashMap;
import net.sf.jasperreports.engine.*;

public class TestAllReports {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Test all three reports
                System.out.println("🧪 Testing all three JasperReports...");
                
                // Test 1: Unregistered Class Report
                System.out.println("\n📊 Testing Unregistered Class Report...");
                testUnregisteredClassReport(conn);
                
                // Test 2: Fitness Recommendation Report
                System.out.println("\n📊 Testing Fitness Recommendation Report...");
                testFitnessRecommendationReport(conn);
                
                // Test 3: Equipment Inventory Report
                System.out.println("\n📊 Testing Equipment Inventory Report...");
                testEquipmentInventoryReport(conn);
                
                System.out.println("\n🎉 All reports tested successfully!");
                System.out.println("💡 You can now use these .jrxml files in JasperViewer or your application");
                
            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void testUnregisteredClassReport(Connection conn) throws Exception {
        try {
            // Create parameters
            HashMap<String, Object> parameters = new HashMap<>();
            parameters.put("startDate", "2024-01-01");
            parameters.put("endDate", "2024-12-31");
            
            // Compile .jrxml to JasperReport
            String templatePath = "unregistered_class_report.jrxml";
            JasperReport report = JasperCompileManager.compileReport(templatePath);
            System.out.println("  ✅ Unregistered Class Report compiled successfully");
            
            // Fill report
            JasperPrint print = JasperFillManager.fillReport(report, parameters, conn);
            System.out.println("  ✅ Report filled with data - " + print.getPages().size() + " pages generated");
            
        } catch (Exception e) {
            System.out.println("  ❌ Unregistered Class Report failed: " + e.getMessage());
            throw e;
        }
    }

    private static void testFitnessRecommendationReport(Connection conn) throws Exception {
        try {
            // Create parameters
            HashMap<String, Object> parameters = new HashMap<>();
            parameters.put("classType", "Yoga");
            parameters.put("startDate", "2024-01-22");
            parameters.put("endDate", "2024-01-28");
            
            // Compile .jrxml to JasperReport
            String templatePath = "fitness_recommendation_report.jrxml";
            JasperReport report = JasperCompileManager.compileReport(templatePath);
            System.out.println("  ✅ Fitness Recommendation Report compiled successfully");
            
            // Fill report
            JasperPrint print = JasperFillManager.fillReport(report, parameters, conn);
            System.out.println("  ✅ Report filled with data - " + print.getPages().size() + " pages generated");
            
        } catch (Exception e) {
            System.out.println("  ❌ Fitness Recommendation Report failed: " + e.getMessage());
            throw e;
        }
    }

    private static void testEquipmentInventoryReport(Connection conn) throws Exception {
        try {
            // Create parameters
            HashMap<String, Object> parameters = new HashMap<>();
            parameters.put("currentYear", "2024");
            parameters.put("generatedDate", new java.util.Date().toString());
            
            // Compile .jrxml to JasperReport
            String templatePath = "equipment_inventory_report.jrxml";
            JasperReport report = JasperCompileManager.compileReport(templatePath);
            System.out.println("  ✅ Equipment Inventory Report compiled successfully");
            
            // Fill report
            JasperPrint print = JasperFillManager.fillReport(report, parameters, conn);
            System.out.println("  ✅ Report filled with data - " + print.getPages().size() + " pages generated");
            
        } catch (Exception e) {
            System.out.println("  ❌ Equipment Inventory Report failed: " + e.getMessage());
            throw e;
        }
    }
}
