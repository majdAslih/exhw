package main;

import java.sql.*;

public class SimpleFix {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Check if CustomerPlans table exists
                System.out.println("🔍 Checking if CustomerPlans table exists...");
                if (!tableExists(conn, "CustomerPlans")) {
                    System.out.println("❌ CustomerPlans table missing! Creating it...");
                    createCustomerPlansTable(conn);
                } else {
                    System.out.println("✅ CustomerPlans table exists");
                }

                // Test the Unregistered Class Report query
                System.out.println("\n🔍 Testing Unregistered Class Report query...");
                testUnregisteredClassQuery(conn);

                System.out.println("✅ Database fixed successfully!");

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static boolean tableExists(Connection conn, String tableName) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM " + tableName)) {
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    private static void createCustomerPlansTable(Connection conn) throws SQLException {
        // Create CustomerPlans table
        String createSQL = "CREATE TABLE CustomerPlans (" +
                "CustomerID INTEGER, " +
                "PlanID INTEGER, " +
                "RegistrationDate VARCHAR(10))";
        
        try (Statement stmt = conn.createStatement()) {
            stmt.execute(createSQL);
            System.out.println("  ✅ Created CustomerPlans table");
        }

        // Insert sample data - all customers registered to plans
        String insertSQL = "INSERT INTO CustomerPlans (CustomerID, PlanID, RegistrationDate) VALUES " +
                "(1, 1, '2024-01-01'), " +
                "(2, 2, '2024-01-01'), " +
                "(3, 3, '2024-01-01'), " +
                "(4, 1, '2024-01-01'), " +
                "(5, 2, '2024-01-01'), " +
                "(6, 3, '2024-01-01'), " +
                "(7, 1, '2024-01-01'), " +
                "(8, 2, '2024-01-01')";

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(insertSQL);
            System.out.println("  ✅ Inserted 8 customer plan registrations");
        }
    }

    private static void testUnregisteredClassQuery(Connection conn) throws SQLException {
        try {
            // Test with the date range that includes our sample data
            String startDate = "2024-01-01";
            String endDate = "2024-01-31";

            String query =
                "SELECT c.CustomerID, c.CustomerFirstName, c.CustomerLastName, c.phone, c.Email, " +
                "cp.RegistrationDate, COUNT(a.CustomerID) AS ClassesAttended " +
                "FROM CustomerTable c " +
                "INNER JOIN CustomerPlans cp ON c.CustomerID = cp.CustomerID " +
                "LEFT JOIN [CustomerAttendance Table] a ON c.CustomerID = a.CustomerID " +
                "AND a.AttendanceDate BETWEEN ? AND ? " +
                "WHERE cp.RegistrationDate <= ? " +
                "GROUP BY c.CustomerID, c.CustomerFirstName, c.CustomerLastName, c.phone, c.Email, cp.RegistrationDate " +
                "HAVING COUNT(a.CustomerID) < 5 " +
                "ORDER BY c.CustomerFirstName, c.CustomerLastName";

            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, startDate);
                stmt.setString(2, endDate);
                stmt.setString(3, endDate);

                try (ResultSet rs = stmt.executeQuery()) {
                    int count = 0;
                    System.out.println("  ✅ Query executed successfully!");
                    System.out.println("  📊 Results for customers with < 5 classes:");
                    while (rs.next()) {
                        count++;
                        String customerId = rs.getString("CustomerID");
                        String firstName = rs.getString("CustomerFirstName");
                        String lastName = rs.getString("CustomerLastName");
                        String phone = rs.getString("phone");
                        String email = rs.getString("Email");
                        String regDate = rs.getString("RegistrationDate");
                        int classesAttended = rs.getInt("ClassesAttended");
                        System.out.println("    " + customerId + " | " + firstName + " " + lastName + " | " + phone + " | " + email + " | Classes: " + classesAttended + " | Reg: " + regDate);
                    }
                    System.out.println("  📈 Total customers with < 5 classes: " + count);
                    System.out.println("  🎯 Expected: 7 customers (IDs: 1,2,4,5,6,7,8) should appear in report");
                }
            }
        } catch (SQLException e) {
            System.out.println("  ❌ Query failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
