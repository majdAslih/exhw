package main;

import java.sql.*;
import java.io.*;
import java.util.*;

public class DatabasePopulator {
    
    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";
    
    public static void main(String[] args) {
        DatabasePopulator populator = new DatabasePopulator();
        populator.populateDatabase();
    }
    
    public void populateDatabase() {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            
            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");
                
                // Create tables if they don't exist
                createTables(conn);
                
                // Populate with sample data
                populateSampleData(conn);
                
                System.out.println("✅ Database populated successfully!");
                
            }
        } catch (Exception e) {
            System.err.println("❌ Error populating database: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void createTables(Connection conn) throws SQLException {
        System.out.println("Creating tables...");
        
        // Customer Table
        executeSQL(conn, "CREATE TABLE IF NOT EXISTS CustomerTable (" +
                "CustomerID INTEGER PRIMARY KEY, " +
                "CustomerFirstName VARCHAR(50), " +
                "CustomerLastName VARCHAR(50), " +
                "phone VARCHAR(20), " +
                "Email VARCHAR(100))");
        
        // Instructor Table
        executeSQL(conn, "CREATE TABLE IF NOT EXISTS [Instructor Table] (" +
                "InstructorID INTEGER PRIMARY KEY, " +
                "FirstName VARCHAR(50), " +
                "LastName VARCHAR(50), " +
                "Phone VARCHAR(20), " +
                "Email VARCHAR(100), " +
                "Specialization VARCHAR(100))");
        
        // PDTable (Participation Details)
        executeSQL(conn, "CREATE TABLE IF NOT EXISTS PDTable (" +
                "pdID INTEGER PRIMARY KEY, " +
                "classtype VARCHAR(50), " +
                "fromage INTEGER, " +
                "toage INTEGER, " +
                "guidence VARCHAR(100))");
        
        // PlanTable
        executeSQL(conn, "CREATE TABLE IF NOT EXISTS PlanTable (" +
                "PlanID INTEGER PRIMARY KEY, " +
                "StartTime TIME, " +
                "duration INTEGER, " +
                "currentStatus VARCHAR(20), " +
                "InstructorID INTEGER)");
        
        // ClassTable
        executeSQL(conn, "CREATE TABLE IF NOT EXISTS ClassTable (" +
                "ClassID INTEGER PRIMARY KEY, " +
                "className VARCHAR(100), " +
                "instructorName VARCHAR(100), " +
                "scedualDate DATE, " +
                "startDate DATE, " +
                "endDate DATE, " +
                "maxnumber INTEGER, " +
                "pdID INTEGER)");
        
        // ClassesInPlan
        executeSQL(conn, "CREATE TABLE IF NOT EXISTS ClassesInPlan (" +
                "ClassID INTEGER, " +
                "PlanID INTEGER)");
        
        // CustomerAttendance Table
        executeSQL(conn, "CREATE TABLE IF NOT EXISTS [CustomerAttendance Table] (" +
                "CustomerID INTEGER, " +
                "ClassID INTEGER, " +
                "AttendanceDate DATE, " +
                "EndTime TIME)");
        
        // Equipment Table
        executeSQL(conn, "CREATE TABLE IF NOT EXISTS [Equipment Table] (" +
                "EquipmentID INTEGER PRIMARY KEY, " +
                "EquipmentName VARCHAR(100), " +
                "Condition VARCHAR(50), " +
                "PurchaseDate DATE)");
        
        // EquipmentUsageReport Table
        executeSQL(conn, "CREATE TABLE IF NOT EXISTS [EquipmentUsageReport Table] (" +
                "EquipmentID INTEGER, " +
                "EquipmentName VARCHAR(100), " +
                "UsageDate DATE, " +
                "HoursUsed DOUBLE)");
        
        // CustomerPlans
        executeSQL(conn, "CREATE TABLE IF NOT EXISTS CustomerPlans (" +
                "CustomerID INTEGER, " +
                "PlanID INTEGER, " +
                "RegistrationDate DATE)");
    }
    
    private void populateSampleData(Connection conn) throws SQLException {
        System.out.println("Populating with sample data...");
        
        // Clear existing data
        clearTables(conn);
        
        // 1. Customer Table
        executeSQL(conn, "INSERT INTO CustomerTable (CustomerID, CustomerFirstName, CustomerLastName, phone, Email) VALUES " +
                "(1, 'John', 'Smith', '555-0101', 'john.smith@email.com'), " +
                "(2, 'Sarah', 'Johnson', '555-0102', 'sarah.johnson@email.com'), " +
                "(3, 'Mike', 'Davis', '555-0103', 'mike.davis@email.com'), " +
                "(4, 'Lisa', 'Wilson', '555-0104', 'lisa.wilson@email.com'), " +
                "(5, 'David', 'Brown', '555-0105', 'david.brown@email.com'), " +
                "(6, 'Emma', 'Taylor', '555-0106', 'emma.taylor@email.com'), " +
                "(7, 'James', 'Anderson', '555-0107', 'james.anderson@email.com'), " +
                "(8, 'Maria', 'Garcia', '555-0108', 'maria.garcia@email.com')");
        
        // 2. Instructor Table
        executeSQL(conn, "INSERT INTO [Instructor Table] (InstructorID, FirstName, LastName, Phone, Email, Specialization) VALUES " +
                "(1, 'Alex', 'Thompson', '555-0201', 'alex.thompson@fitwell.com', 'Yoga'), " +
                "(2, 'Rachel', 'Chen', '555-0202', 'rachel.chen@fitwell.com', 'Cardio'), " +
                "(3, 'Marcus', 'Rodriguez', '555-0203', 'marcus.rodriguez@fitwell.com', 'Strength Training'), " +
                "(4, 'Sophie', 'Williams', '555-0204', 'sophie.williams@fitwell.com', 'Pilates')");
        
        // 3. PDTable
        executeSQL(conn, "INSERT INTO PDTable (pdID, classtype, fromage, toage, guidence) VALUES " +
                "(1, 'Yoga', 18, 65, 'Beginner to Advanced'), " +
                "(2, 'Cardio', 16, 70, 'All fitness levels'), " +
                "(3, 'Strength Training', 18, 75, 'Intermediate to Advanced'), " +
                "(4, 'Pilates', 16, 68, 'Beginner to Intermediate')");
        
        // 4. PlanTable
        executeSQL(conn, "INSERT INTO PlanTable (PlanID, StartTime, duration, currentStatus, InstructorID) VALUES " +
                "(1, '08:00:00', 60, 'Active', 1), " +
                "(2, '09:30:00', 45, 'Active', 2), " +
                "(3, '17:00:00', 90, 'Active', 3), " +
                "(4, '19:00:00', 60, 'Active', 4), " +
                "(5, '10:00:00', 75, 'Active', 1), " +
                "(6, '18:30:00', 60, 'Active', 2)");
        
        // 5. ClassTable
        executeSQL(conn, "INSERT INTO ClassTable (ClassID, className, instructorName, scedualDate, startDate, endDate, maxnumber, pdID) VALUES " +
                "(1, 'Morning Yoga', 'Alex Thompson', '2024-01-15', '2024-01-15', '2024-01-15', 20, 1), " +
                "(2, 'Cardio Blast', 'Rachel Chen', '2024-01-15', '2024-01-15', '2024-01-15', 25, 2), " +
                "(3, 'Strength Training', 'Marcus Rodriguez', '2024-01-15', '2024-01-15', '2024-01-15', 15, 3), " +
                "(4, 'Evening Pilates', 'Sophie Williams', '2024-01-15', '2024-01-15', '2024-01-15', 18, 4), " +
                "(5, 'Advanced Yoga', 'Alex Thompson', '2024-01-16', '2024-01-16', '2024-01-16', 15, 1), " +
                "(6, 'HIIT Cardio', 'Rachel Chen', '2024-01-16', '2024-01-16', '2024-01-16', 20, 2)");
        
        // 6. ClassesInPlan
        executeSQL(conn, "INSERT INTO ClassesInPlan (ClassID, PlanID) VALUES " +
                "(1, 1), (2, 2), (3, 3), (4, 4), (5, 5), (6, 6)");
        
        // 7. CustomerAttendance Table
        executeSQL(conn, "INSERT INTO [CustomerAttendance Table] (CustomerID, ClassID, AttendanceDate, EndTime) VALUES " +
                "(1, 1, '2024-01-15', '09:00:00'), " +
                "(1, 2, '2024-01-15', '10:15:00'), " +
                "(2, 1, '2024-01-15', '09:00:00'), " +
                "(2, 3, '2024-01-15', '18:30:00'), " +
                "(3, 1, '2024-01-15', '09:00:00'), " +
                "(3, 2, '2024-01-15', '10:15:00'), " +
                "(3, 4, '2024-01-15', '20:00:00'), " +
                "(4, 1, '2024-01-15', '09:00:00'), " +
                "(5, 2, '2024-01-15', '10:15:00'), " +
                "(6, 3, '2024-01-15', '18:30:00'), " +
                "(7, 1, '2024-01-15', '09:00:00'), " +
                "(8, 2, '2024-01-15', '10:15:00')");
        
        // 8. Equipment Table
        executeSQL(conn, "INSERT INTO [Equipment Table] (EquipmentID, EquipmentName, Condition, PurchaseDate) VALUES " +
                "(1, 'Treadmill Pro', 'Excellent', '2023-01-15'), " +
                "(2, 'Yoga Mat Premium', 'Good', '2023-03-20'), " +
                "(3, 'Dumbbell Set 20kg', 'Excellent', '2023-02-10'), " +
                "(4, 'Exercise Bike Elite', 'Good', '2023-04-05'), " +
                "(5, 'Resistance Bands Set', 'Excellent', '2023-05-12'), " +
                "(6, 'Weight Bench Standard', 'Good', '2023-06-18'), " +
                "(7, 'Pilates Reformer', 'Excellent', '2023-07-22'), " +
                "(8, 'Kettlebell 16kg', 'Good', '2023-08-30')");
        
        // 9. EquipmentUsageReport Table
        executeSQL(conn, "INSERT INTO [EquipmentUsageReport Table] (EquipmentID, EquipmentName, UsageDate, HoursUsed) VALUES " +
                "(1, 'Treadmill Pro', '2024-01-15', 2.5), " +
                "(1, 'Treadmill Pro', '2024-01-16', 3.0), " +
                "(1, 'Treadmill Pro', '2024-01-17', 2.0), " +
                "(2, 'Yoga Mat Premium', '2024-01-15', 1.0), " +
                "(2, 'Yoga Mat Premium', '2024-01-16', 1.0), " +
                "(2, 'Yoga Mat Premium', '2024-01-17', 1.0), " +
                "(3, 'Dumbbell Set 20kg', '2024-01-15', 1.5), " +
                "(3, 'Dumbbell Set 20kg', '2024-01-16', 1.5), " +
                "(4, 'Exercise Bike Elite', '2024-01-15', 2.0), " +
                "(4, 'Exercise Bike Elite', '2024-01-16', 2.5), " +
                "(5, 'Resistance Bands Set', '2024-01-15', 1.0), " +
                "(6, 'Weight Bench Standard', '2024-01-15', 1.5), " +
                "(7, 'Pilates Reformer', '2024-01-15', 1.0), " +
                "(8, 'Kettlebell 16kg', '2024-01-15', 1.0)");
        
        // 10. Additional classes for next week
        executeSQL(conn, "INSERT INTO ClassTable (ClassID, className, instructorName, scedualDate, startDate, endDate, maxnumber, pdID) VALUES " +
                "(7, 'Sunrise Yoga', 'Alex Thompson', '2024-01-22', '2024-01-22', '2024-01-22', 20, 1), " +
                "(8, 'Power Cardio', 'Rachel Chen', '2024-01-22', '2024-01-22', '2024-01-22', 25, 2), " +
                "(9, 'Core Strength', 'Marcus Rodriguez', '2024-01-22', '2024-01-22', '2024-01-22', 15, 3), " +
                "(10, 'Mindful Pilates', 'Sophie Williams', '2024-01-22', '2024-01-22', '2024-01-22', 18, 4), " +
                "(11, 'Vinyasa Flow', 'Alex Thompson', '2024-01-23', '2024-01-23', '2024-01-23', 20, 1), " +
                "(12, 'Tabata Training', 'Rachel Chen', '2024-01-23', '2024-01-23', '2024-01-23', 20, 2)");
        
        // 11. Link new classes to plans
        executeSQL(conn, "INSERT INTO ClassesInPlan (ClassID, PlanID) VALUES " +
                "(7, 1), (8, 2), (9, 3), (10, 4), (11, 5), (12, 6)");
        
        // 12. Customer plans registration
        executeSQL(conn, "INSERT INTO CustomerPlans (CustomerID, PlanID, RegistrationDate) VALUES " +
                "(1, 1, '2024-01-01'), " +
                "(2, 2, '2024-01-01'), " +
                "(3, 3, '2024-01-01'), " +
                "(4, 1, '2024-01-01'), " +
                "(5, 2, '2024-01-01'), " +
                "(6, 3, '2024-01-01'), " +
                "(7, 1, '2024-01-01'), " +
                "(8, 2, '2024-01-01')");
    }
    
    private void clearTables(Connection conn) throws SQLException {
        String[] tables = {
            "CustomerPlans", "[EquipmentUsageReport Table]", "[Equipment Table]",
            "[CustomerAttendance Table]", "ClassesInPlan", "ClassTable", "PlanTable",
            "PDTable", "[Instructor Table]", "CustomerTable"
        };
        
        for (String table : tables) {
            try {
                executeSQL(conn, "DELETE FROM " + table);
            } catch (SQLException e) {
                // Table might not exist yet, ignore
            }
        }
    }
    
    private void executeSQL(Connection conn, String sql) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        }
    }
}
