package main;

import java.sql.*;

public class CheckClassTable {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Check ClassTable structure
                System.out.println("🔍 Checking ClassTable structure...");
                checkClassTableStructure(conn);

                // Check existing data
                System.out.println("\n📊 Checking existing ClassTable data...");
                checkExistingClassData(conn);

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void checkClassTableStructure(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM ClassTable WHERE 1=0")) {
            
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            
            System.out.println("  📋 ClassTable structure:");
            for (int i = 1; i <= columnCount; i++) {
                String columnName = metaData.getColumnName(i);
                String columnType = metaData.getColumnTypeName(i);
                int columnSize = metaData.getColumnDisplaySize(i);
                System.out.println("    Column " + i + ": " + columnName + " (" + columnType + ", size: " + columnSize + ")");
            }
        }
    }

    private static void checkExistingClassData(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as TotalClasses FROM ClassTable")) {
            
            if (rs.next()) {
                int totalClasses = rs.getInt("TotalClasses");
                System.out.println("  📊 Total classes in ClassTable: " + totalClasses);
            }
        }

        // Check if there are any records and show sample
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT TOP 3 * FROM ClassTable")) {
            
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            
            System.out.println("  📋 Sample ClassTable data (first 3 records):");
            while (rs.next()) {
                System.out.print("    Record: ");
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = metaData.getColumnName(i);
                    String value = rs.getString(i);
                    System.out.print(columnName + "=" + value + " | ");
                }
                System.out.println();
            }
        }
    }
}
