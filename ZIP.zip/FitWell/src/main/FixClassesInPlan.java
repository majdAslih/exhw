package main;

import java.sql.*;

public class FixClassesInPlan {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Check ClassesInPlan table
                System.out.println("🔍 Checking ClassesInPlan table...");
                checkClassesInPlanTable(conn);

                // Fix ClassesInPlan table if needed
                System.out.println("\n🔧 Fixing ClassesInPlan table...");
                fixClassesInPlanTable(conn);

                // Test the actual Fitness Recommendation Report query again
                System.out.println("\n🧪 Testing actual Fitness Recommendation Report query again...");
                testActualQuery(conn);

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void checkClassesInPlanTable(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as TotalRecords FROM ClassesInPlan")) {
            
            if (rs.next()) {
                int totalRecords = rs.getInt("TotalRecords");
                System.out.println("  📊 Total records in ClassesInPlan: " + totalRecords);
            }
        }

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM ClassesInPlan ORDER BY ClassID")) {
            
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            
            System.out.println("  📋 ClassesInPlan structure and data:");
            while (rs.next()) {
                System.out.print("    Record: ");
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = metaData.getColumnName(i);
                    String value = rs.getString(i);
                    System.out.print(columnName + "=" + value + " | ");
                }
                System.out.println();
            }
        }
    }

    private static void fixClassesInPlanTable(Connection conn) throws SQLException {
        // Check if ClassesInPlan table has the right links
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM ClassesInPlan WHERE ClassID IN (101, 102, 105, 106, 107, 109, 112)")) {
            
            if (rs.next() && rs.getInt(1) == 0) {
                System.out.println("  ❌ ClassesInPlan table missing links for Yoga classes! Adding them...");
                
                // Add links between our Yoga classes and plans
                String insertSQL = "INSERT INTO ClassesInPlan (ClassID, PlanID) VALUES " +
                        "(101, 1), " + // Morning Yoga -> Plan 1
                        "(102, 1), " + // Evening Yoga -> Plan 1
                        "(105, 1), " + // Power Yoga -> Plan 1
                        "(106, 2), " + // Gentle Yoga -> Plan 2
                        "(107, 1), " + // Yoga Flow -> Plan 1
                        "(109, 1), " + // Friday Yoga -> Plan 1
                        "(112, 1)";    // Sunday Yoga -> Plan 1

                try (Statement insertStmt = conn.createStatement()) {
                    insertStmt.execute(insertSQL);
                    System.out.println("  ✅ Added ClassesInPlan links for Yoga classes");
                }
            } else {
                System.out.println("  ✅ ClassesInPlan table has links for Yoga classes");
            }
        }
    }

    private static void testActualQuery(Connection conn) throws SQLException {
        try {
            // Test the EXACT query that the Fitness Recommendation Report uses
            String reportSQL = 
                "SELECT C.ClassID, C.className, C.instructorName, C.scedualDate, " +
                "C.startDate, C.endDate, C.maxnumber, " +
                "PD.classtype, PD.fromage, PD.toage, PD.guidence, " +
                "P.StartTime, P.duration, P.currentStatus, P.PlanID, " +
                "I.FirstName, I.LastName, I.Phone, I.Email, I.Specialization " +
                "FROM ClassTable C " +
                "INNER JOIN PDTable PD ON C.pdID = PD.pdID " +
                "INNER JOIN ClassesInPlan CP ON C.ClassID = CP.ClassID " +
                "INNER JOIN PlanTable P ON CP.PlanID = P.PlanID " +
                "INNER JOIN [Instructor Table] I ON P.InstructorID = I.InstructorID " +
                "WHERE PD.classtype = 'Yoga' " +
                "AND C.scedualDate BETWEEN '2024-01-22' AND '2024-01-28' " +
                "ORDER BY P.StartTime, C.scedualDate";

            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(reportSQL)) {
                
                int count = 0;
                System.out.println("  📊 Actual Fitness Recommendation Report query results:");
                while (rs.next()) {
                    count++;
                    int classId = rs.getInt("ClassID");
                    String className = rs.getString("className");
                    String scheduleDate = rs.getString("scedualDate");
                    String classType = rs.getString("classtype");
                    String instructorFirstName = rs.getString("FirstName");
                    String instructorLastName = rs.getString("LastName");
                    String specialization = rs.getString("Specialization");
                    
                    System.out.println("    " + count + ". " + className + " | " + scheduleDate + " | " + classType);
                    System.out.println("       Instructor: " + instructorFirstName + " " + instructorLastName + " (" + specialization + ")");
                    System.out.println();
                }
                System.out.println("  📈 Total Yoga classes found by actual query: " + count);
                System.out.println("  🎯 Expected: Should now find Yoga classes with proper table links");
            }
        } catch (SQLException e) {
            System.out.println("  ❌ Query failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
