import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.io.File;
import java.util.Scanner;

public class FitWellJAR {
    
    private static final String[] AVAILABLE_REPORTS = {
        "unregistered_class_report.jrxml",
        "equipment_inventory_report.jrxml", 
        "fitness_recommendation_report.jrxml"
    };
    
    private static final String[] REPORT_NAMES = {
        "Unregistered Class Report",
        "Equipment Inventory Report",
        "Fitness Recommendation Report"
    };
    
    public static void main(String[] args) {
        System.out.println("=== FitWell Gym Management System ===");
        System.out.println("JAR Version - Automatic Database Detection");
        System.out.println();
        
        // Check if database file exists
        String dbPath = findDatabaseFile();
        if (dbPath == null) {
            System.out.println("ERROR: Could not find FitWell.accdb database file!");
            System.out.println("Please ensure FitWell.accdb is in the same folder as this JAR file.");
            System.out.println("Press Enter to exit...");
            new Scanner(System.in).nextLine();
            return;
        }
        
        System.out.println("✓ Database found: " + dbPath);
        System.out.println();
        
        showMenu(dbPath);
    }
    
    private static String findDatabaseFile() {
        // Get the directory where the JAR file is located
        String jarDir = getJarDirectory();
        System.out.println("Looking for database in: " + jarDir);
        
        // Look for the Access database file
        File dbFile = new File(jarDir, "FitWell.accdb");
        if (dbFile.exists()) {
            return dbFile.getAbsolutePath();
        }
        
        return null;
    }
    
    private static String getJarDirectory() {
        try {
            // Get the directory where the JAR file is located
            String jarPath = FitWellJAR.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath();
            if (jarPath.endsWith(".jar")) {
                File jarFile = new File(jarPath);
                return jarFile.getParent();
            } else {
                // If running from IDE, use current directory
                return System.getProperty("user.dir");
            }
        } catch (Exception e) {
            // Fallback to current directory
            return System.getProperty("user.dir");
        }
    }
    
    private static void showMenu(String dbPath) {
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("Available Reports:");
            for (int i = 0; i < REPORT_NAMES.length; i++) {
                System.out.println((i + 1) + ". " + REPORT_NAMES[i]);
            }
            System.out.println("4. View All Reports");
            System.out.println("5. Exit");
            System.out.print("\nSelect an option (1-5): ");
            
            try {
                int choice = Integer.parseInt(scanner.nextLine().trim());
                
                switch (choice) {
                    case 1:
                    case 2:
                    case 3:
                        generateAndViewReport(AVAILABLE_REPORTS[choice - 1], REPORT_NAMES[choice - 1], dbPath);
                        break;
                    case 4:
                        viewAllReports(dbPath);
                        break;
                    case 5:
                        System.out.println("Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid option. Please select 1-5.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                e.printStackTrace();
            }
            
            System.out.println("\nPress Enter to continue...");
            scanner.nextLine();
        }
    }
    
    private static void generateAndViewReport(String reportFile, String reportName, String dbPath) {
        try {
            System.out.println("Generating " + reportName + "...");
            
            // Compile the report
            JasperDesign design = JRXmlLoader.load(reportFile);
            JasperReport report = JasperCompileManager.compileReport(design);
            
            // Get database connection
            Connection conn = getDatabaseConnection(dbPath);
            
            // Fill the report
            JasperPrint jasperPrint = JasperFillManager.fillReport(report, null, conn);
            
            // Display in JasperViewer
            JasperViewer.viewReport(jasperPrint, false);
            
            System.out.println("✓ " + reportName + " generated and displayed successfully!");
            
        } catch (Exception e) {
            System.err.println("Error generating " + reportName + ": " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static void viewAllReports(String dbPath) {
        System.out.println("Generating all reports...");
        
        for (int i = 0; i < AVAILABLE_REPORTS.length; i++) {
            try {
                System.out.println("Processing " + REPORT_NAMES[i] + "...");
                
                // Compile the report
                JasperDesign design = JRXmlLoader.load(AVAILABLE_REPORTS[i]);
                JasperReport report = JasperCompileManager.compileReport(design);
                
                // Get database connection
                Connection conn = getDatabaseConnection(dbPath);
                
                // Fill the report
                JasperPrint jasperPrint = JasperFillManager.fillReport(report, null, conn);
                
                // Display in JasperViewer
                JasperViewer.viewReport(jasperPrint, false);
                
                System.out.println("✓ " + REPORT_NAMES[i] + " generated successfully!");
                
            } catch (Exception e) {
                System.err.println("Error generating " + REPORT_NAMES[i] + ": " + e.getMessage());
            }
        }
        
        System.out.println("All reports processed!");
    }
    
    private static Connection getDatabaseConnection(String dbPath) throws Exception {
        // Load UCanAccess driver
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        
        // Create connection string
        String connectionString = "jdbc:ucanaccess://" + dbPath;
        
        // Create connection
        return DriverManager.getConnection(connectionString);
    }
}
