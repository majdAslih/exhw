package main;

import javax.swing.*;

import boundary.ClassAttendanceReportGUI;
import boundary.EquipmentUsageReportGUI;
import boundary.FitnessRecommendationReportGUI;

public class Main extends JFrame {

    private static final long serialVersionUID = 1L;

    public Main() {
        setTitle("FitWell Reports");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        // Create the report panels
        ClassAttendanceReportGUI classAttendance = new ClassAttendanceReportGUI();
        EquipmentUsageReportGUI equipmentUsage = new EquipmentUsageReportGUI();
        FitnessRecommendationReportGUI fitnessReport = new FitnessRecommendationReportGUI();

        // Add the tabs
        tabbedPane.addTab("Class Attendance Report", classAttendance);
        tabbedPane.addTab("Equipment Usage Report", equipmentUsage);
        tabbedPane.addTab("Fitness Recommendation Report", fitnessReport);

        add(tabbedPane);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main app = new Main();
            app.setVisible(true);
        });
    }
}
