package main;

import java.sql.*;

public class DebugQuery {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Debug the query step by step
                System.out.println("🔍 Debugging query step by step...");
                debugQueryStepByStep(conn);

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void debugQueryStepByStep(Connection conn) throws SQLException {
        // Step 1: Check what's in CustomerTable
        System.out.println("\n📋 Step 1: Checking CustomerTable...");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT CustomerID, CustomerFirstName, CustomerLastName FROM CustomerTable ORDER BY CustomerID")) {
            while (rs.next()) {
                int customerId = rs.getInt("CustomerID");
                String firstName = rs.getString("CustomerFirstName");
                String lastName = rs.getString("CustomerLastName");
                System.out.println("    Customer " + customerId + ": " + firstName + " " + lastName);
            }
        }

        // Step 2: Check what's in CustomerPlans
        System.out.println("\n📋 Step 2: Checking CustomerPlans...");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT CustomerID, PlanID, RegistrationDate FROM CustomerPlans ORDER BY CustomerID")) {
            while (rs.next()) {
                int customerId = rs.getInt("CustomerID");
                int planId = rs.getInt("PlanID");
                String regDate = rs.getString("RegistrationDate");
                System.out.println("    Customer " + customerId + ": Plan " + planId + ", Reg: " + regDate);
            }
        }

        // Step 3: Check what's in CustomerAttendance Table
        System.out.println("\n📋 Step 3: Checking CustomerAttendance Table...");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT CustomerID, ClassID, AttendanceDate, EndTime FROM [CustomerAttendance Table] ORDER BY CustomerID, ClassID")) {
            while (rs.next()) {
                int customerId = rs.getInt("CustomerID");
                int classId = rs.getInt("ClassID");
                String attendanceDate = rs.getString("AttendanceDate");
                String endTime = rs.getString("EndTime");
                System.out.println("    Customer " + customerId + ": Class " + classId + ", Date: " + attendanceDate + ", End: " + endTime);
            }
        }

        // Step 4: Test the JOIN without date filter
        System.out.println("\n📋 Step 4: Testing JOIN without date filter...");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                "SELECT c.CustomerID, c.CustomerFirstName, c.CustomerLastName, " +
                "cp.RegistrationDate, COUNT(a.CustomerID) AS ClassesAttended " +
                "FROM CustomerTable c " +
                "INNER JOIN CustomerPlans cp ON c.CustomerID = cp.CustomerID " +
                "LEFT JOIN [CustomerAttendance Table] a ON c.CustomerID = a.CustomerID " +
                "GROUP BY c.CustomerID, c.CustomerFirstName, c.CustomerLastName, cp.RegistrationDate " +
                "ORDER BY c.CustomerID")) {
            
            System.out.println("    Results without date filter:");
            while (rs.next()) {
                int customerId = rs.getInt("CustomerID");
                String firstName = rs.getString("CustomerFirstName");
                String lastName = rs.getString("CustomerLastName");
                String regDate = rs.getString("RegistrationDate");
                int classesAttended = rs.getInt("ClassesAttended");
                System.out.println("      " + customerId + " | " + firstName + " " + lastName + " | Classes: " + classesAttended + " | Reg: " + regDate);
            }
        }

        // Step 5: Test with specific date values
        System.out.println("\n📋 Step 5: Testing with specific date values...");
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                "SELECT c.CustomerID, c.CustomerFirstName, c.CustomerLastName, " +
                "cp.RegistrationDate, COUNT(a.CustomerID) AS ClassesAttended " +
                "FROM CustomerTable c " +
                "INNER JOIN CustomerPlans cp ON c.CustomerID = cp.CustomerID " +
                "LEFT JOIN [CustomerAttendance Table] a ON c.CustomerID = a.CustomerID " +
                "AND a.AttendanceDate BETWEEN '2024-01-01' AND '2024-01-31' " +
                "WHERE cp.RegistrationDate <= '2024-01-31' " +
                "GROUP BY c.CustomerID, c.CustomerFirstName, c.CustomerLastName, cp.RegistrationDate " +
                "HAVING COUNT(a.CustomerID) < 5 " +
                "ORDER BY c.CustomerID")) {
            
            System.out.println("    Results with hardcoded dates:");
            int count = 0;
            while (rs.next()) {
                count++;
                int customerId = rs.getInt("CustomerID");
                String firstName = rs.getString("CustomerFirstName");
                String lastName = rs.getString("CustomerLastName");
                String regDate = rs.getString("RegistrationDate");
                int classesAttended = rs.getInt("ClassesAttended");
                System.out.println("      " + customerId + " | " + firstName + " " + lastName + " | Classes: " + classesAttended + " | Reg: " + regDate);
            }
            System.out.println("    Total customers with < 5 classes: " + count);
        }
    }
}
