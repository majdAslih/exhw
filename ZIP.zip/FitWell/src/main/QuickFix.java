package main;

import java.sql.*;

public class QuickFix {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Add simple attendance data
                System.out.println("📊 Adding simple attendance data...");
                addSimpleAttendanceData(conn);

                // Test the Unregistered Class Report query
                System.out.println("\n🔍 Testing Unregistered Class Report query...");
                testUnregisteredClassQuery(conn);

                System.out.println("✅ Quick fix completed!");

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void addSimpleAttendanceData(Connection conn) throws SQLException {
        // Clear existing attendance data
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("DELETE FROM [CustomerAttendance Table]");
            System.out.println("  ✅ Cleared existing attendance data");
        }

        // Add simple attendance records - just customer IDs and class IDs
        // This will give us customers with different numbers of classes
        String insertSQL = "INSERT INTO [CustomerAttendance Table] (CustomerID, ClassID, AttendanceDate, EndTime) VALUES " +
                "(1, 1, '2024-01-15', '09:00'), " +
                "(1, 2, '2024-01-15', '10:00'), " +
                "(1, 3, '2024-01-15', '11:00'), " +
                "(1, 4, '2024-01-15', '12:00'), " +
                "(2, 1, '2024-01-15', '09:00'), " +
                "(2, 2, '2024-01-15', '10:00'), " +
                "(2, 3, '2024-01-15', '11:00'), " +
                "(3, 1, '2024-01-15', '09:00'), " +
                "(3, 2, '2024-01-15', '10:00'), " +
                "(3, 3, '2024-01-15', '11:00'), " +
                "(3, 4, '2024-01-15', '12:00'), " +
                "(3, 5, '2024-01-15', '13:00'), " +
                "(3, 6, '2024-01-15', '14:00'), " +
                "(4, 1, '2024-01-15', '09:00'), " +
                "(4, 2, '2024-01-15', '10:00'), " +
                "(5, 1, '2024-01-15', '09:00')";

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(insertSQL);
            System.out.println("  ✅ Added attendance data for customers 1-5");
        }

        // Show what we added
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT CustomerID, COUNT(*) as ClassesAttended FROM [CustomerAttendance Table] GROUP BY CustomerID ORDER BY CustomerID")) {
            
            System.out.println("  📊 Current attendance data:");
            while (rs.next()) {
                int customerId = rs.getInt("CustomerID");
                int classesAttended = rs.getInt("ClassesAttended");
                System.out.println("    Customer " + customerId + ": " + classesAttended + " classes");
            }
        }
    }

    private static void testUnregisteredClassQuery(Connection conn) throws SQLException {
        try {
            String startDate = "2024-01-01";
            String endDate = "2024-01-31";

            String query =
                "SELECT c.CustomerID, c.CustomerFirstName, c.CustomerLastName, c.phone, c.Email, " +
                "cp.RegistrationDate, COUNT(a.CustomerID) AS ClassesAttended " +
                "FROM CustomerTable c " +
                "INNER JOIN CustomerPlans cp ON c.CustomerID = cp.CustomerID " +
                "LEFT JOIN [CustomerAttendance Table] a ON c.CustomerID = a.CustomerID " +
                "AND a.AttendanceDate BETWEEN ? AND ? " +
                "WHERE cp.RegistrationDate <= ? " +
                "GROUP BY c.CustomerID, c.CustomerFirstName, c.CustomerLastName, c.phone, c.Email, cp.RegistrationDate " +
                "HAVING COUNT(a.CustomerID) < 5 " +
                "ORDER BY c.CustomerFirstName, c.CustomerLastName";

            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, startDate);
                stmt.setString(2, endDate);
                stmt.setString(3, endDate);

                try (ResultSet rs = stmt.executeQuery()) {
                    int count = 0;
                    System.out.println("  ✅ Query executed successfully!");
                    System.out.println("  📊 Results for customers with < 5 classes:");
                    while (rs.next()) {
                        count++;
                        String customerId = rs.getString("CustomerID");
                        String firstName = rs.getString("CustomerFirstName");
                        String lastName = rs.getString("CustomerLastName");
                        String phone = rs.getString("phone");
                        String email = rs.getString("Email");
                        String regDate = rs.getString("RegistrationDate");
                        int classesAttended = rs.getInt("ClassesAttended");
                        System.out.println("    " + customerId + " | " + firstName + " " + lastName + " | " + phone + " | " + email + " | Classes: " + classesAttended + " | Reg: " + regDate);
                    }
                    System.out.println("  📈 Total customers with < 5 classes: " + count);
                    System.out.println("  🎯 Expected: 7 customers (IDs: 1,2,4,5,6,7,8) should appear in report");
                }
            }
        } catch (SQLException e) {
            System.out.println("  ❌ Query failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
