package main;

import java.sql.*;

public class CheckTableStructure {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Check table structure
                System.out.println("🔍 Checking CustomerAttendance Table structure...");
                checkTableStructure(conn);

                // Check existing data
                System.out.println("\n📊 Checking existing data...");
                checkExistingData(conn);

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void checkTableStructure(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM [CustomerAttendance Table] WHERE 1=0")) {
            
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            
            System.out.println("  📋 Table structure:");
            for (int i = 1; i <= columnCount; i++) {
                String columnName = metaData.getColumnName(i);
                String columnType = metaData.getColumnTypeName(i);
                int columnSize = metaData.getColumnDisplaySize(i);
                System.out.println("    Column " + i + ": " + columnName + " (" + columnType + ", size: " + columnSize + ")");
            }
        }
    }

    private static void checkExistingData(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as TotalRecords FROM [CustomerAttendance Table]")) {
            
            if (rs.next()) {
                int totalRecords = rs.getInt("TotalRecords");
                System.out.println("  📊 Total records in CustomerAttendance Table: " + totalRecords);
            }
        }

        // Check if there are any records and show sample
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT TOP 3 * FROM [CustomerAttendance Table]")) {
            
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            
            System.out.println("  📋 Sample data (first 3 records):");
            while (rs.next()) {
                System.out.print("    Record: ");
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = metaData.getColumnName(i);
                    String value = rs.getString(i);
                    System.out.print(columnName + "=" + value + " | ");
                }
                System.out.println();
            }
        }
    }
}
