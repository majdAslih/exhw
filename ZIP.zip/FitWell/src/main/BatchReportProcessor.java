import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 * Batch Report Processor for FitWell Gym Management System
 * Generates all reports in sequence and displays them in JasperViewer
 */
public class BatchReportProcessor {
    
    private static final String DATABASE_PATH = "FitWell.accdb";
    private static final String REPORTS_DIR = "";
    
    // Define all available reports
    private static final String[] AVAILABLE_REPORTS = {
        "unregistered_class_report.jrxml",
        "equipment_inventory_report.jrxml", 
        "fitness_recommendation_report.jrxml",
        "report.jrxml"
    };
    
    private static final String[] REPORT_NAMES = {
        "Unregistered Class Report",
        "Equipment Inventory Report",
        "Fitness Recommendation Report", 
        "Equipment Usage Report"
    };
    
    /**
     * Main method to process all reports in batch
     */
    public static void main(String[] args) {
        BatchReportProcessor processor = new BatchReportProcessor();
        
        try {
            System.out.println("=== FitWell Batch Report Processor ===\n");
            System.out.println("This will generate ALL reports and display them in JasperViewer.\n");
            
            // Check system requirements first
            processor.checkAllRequirements();
            
            // Process all reports
            processor.processAllReports();
            
        } catch (Exception e) {
            System.err.println("\n❌ Error in batch processing: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Processes all reports in sequence
     */
    public void processAllReports() throws Exception {
        System.out.println("\n=== Processing All Reports ===");
        
        for (int i = 0; i < AVAILABLE_REPORTS.length; i++) {
            try {
                System.out.println("\n" + (i + 1) + "/" + AVAILABLE_REPORTS.length + 
                                 " Processing: " + REPORT_NAMES[i]);
                
                processReport(AVAILABLE_REPORTS[i], REPORT_NAMES[i]);
                
                // Small delay between reports to avoid overwhelming the system
                if (i < AVAILABLE_REPORTS.length - 1) {
                    System.out.println("Waiting 3 seconds before next report...");
                    Thread.sleep(3000);
                }
                
            } catch (Exception e) {
                System.err.println("❌ Failed to process " + REPORT_NAMES[i] + ": " + e.getMessage());
                // Continue with next report
            }
        }
        
        System.out.println("\n🎉 All reports processing completed!");
        System.out.println("All reports should now be displayed in separate JasperViewer windows.");
    }
    
    /**
     * Processes a single report
     */
    private void processReport(String jrxmlFileName, String reportTitle) throws Exception {
        System.out.println("  Starting: " + reportTitle);
        
        // Step 1: Compile the JRXML file
        String jrxmlPath = REPORTS_DIR + jrxmlFileName;
        String jasperPath = REPORTS_DIR + jrxmlFileName.replace(".jrxml", ".jasper");
        
        JasperReport jasperReport = compileReport(jrxmlPath, jasperPath);
        System.out.println("  ✓ Compiled successfully");
        
        // Step 2: Generate the report
        JasperPrint jasperPrint = generateReport(jasperReport, jrxmlFileName);
        System.out.println("  ✓ Generated successfully");
        
        // Step 3: Display in JasperViewer
        displayReport(jasperPrint, reportTitle);
        System.out.println("  ✓ Displayed in JasperViewer");
        
        System.out.println("  ✅ " + reportTitle + " completed successfully");
    }
    
    /**
     * Compiles a JRXML file to a JASPER file
     */
    private JasperReport compileReport(String jrxmlPath, String jasperPath) throws Exception {
        try {
            File jrxmlFile = new File(jrxmlPath);
            if (!jrxmlFile.exists()) {
                throw new Exception("JRXML file not found: " + jrxmlPath);
            }
            
            // Compile the JRXML file
            JasperCompileManager.compileReportToFile(jrxmlPath, jasperPath);
            
            // Load the compiled report
            JasperReport jasperReport = (JasperReport) JRLoader.loadObjectFromFile(jasperPath);
            
            return jasperReport;
            
        } catch (JRException e) {
            throw new Exception("Failed to compile JRXML file: " + e.getMessage(), e);
        }
    }
    
    /**
     * Generates a report using the compiled JasperReport with appropriate parameters
     */
    private JasperPrint generateReport(JasperReport jasperReport, String reportFileName) throws Exception {
        try {
            // Get database connection
            Connection connection = getDatabaseConnection();
            
            // Set report-specific parameters
            Map<String, Object> parameters = getReportParameters(reportFileName);
            
            // Fill the report
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, connection);
            
            // Close connection
            connection.close();
            
            return jasperPrint;
            
        } catch (Exception e) {
            throw new Exception("Failed to generate report: " + e.getMessage(), e);
        }
    }
    
    /**
     * Gets appropriate parameters for each report type
     */
    private Map<String, Object> getReportParameters(String reportFileName) {
        Map<String, Object> parameters = new HashMap<>();
        
        switch (reportFileName) {
            case "unregistered_class_report.jrxml":
                parameters.put("startDate", "2024-01-01");
                parameters.put("endDate", "2024-12-31");
                break;
                
            case "equipment_inventory_report.jrxml":
                parameters.put("currentYear", "2024");
                parameters.put("generatedDate", new java.util.Date().toString());
                break;
                
            case "fitness_recommendation_report.jrxml":
                parameters.put("classType", "Yoga");
                parameters.put("startDate", "2024-01-22");
                parameters.put("endDate", "2024-01-28");
                break;
                
            case "report.jrxml":
                // This report doesn't have parameters
                break;
                
            default:
                // Default parameters
                parameters.put("startDate", "2024-01-01");
                parameters.put("endDate", "2024-12-31");
                break;
        }
        
        return parameters;
    }
    
    /**
     * Displays the generated report in JasperViewer
     */
    private void displayReport(JasperPrint jasperPrint, String reportTitle) {
        try {
            // Create and configure the viewer
            JasperViewer viewer = new JasperViewer(jasperPrint, false);
            viewer.setTitle(reportTitle);
            viewer.setVisible(true);
            
        } catch (Exception e) {
            System.err.println("Error opening report viewer: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Establishes a connection to the Access database
     */
    private Connection getDatabaseConnection() throws Exception {
        try {
            File dbFile = new File(DATABASE_PATH);
            if (!dbFile.exists()) {
                throw new Exception("Database file not found: " + DATABASE_PATH);
            }
            
            String dbUrl = "jdbc:ucanaccess://" + dbFile.getAbsolutePath();
            
            // Load the UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            
            // Establish connection
            Connection connection = DriverManager.getConnection(dbUrl);
            
            return connection;
            
        } catch (Exception e) {
            throw new Exception("Failed to connect to database: " + e.getMessage(), e);
        }
    }
    
    /**
     * Checks all system requirements for all reports
     */
    public void checkAllRequirements() {
        System.out.println("Checking system requirements for all reports...");
        System.out.println("===============================================");
        
        // Check database file
        File dbFile = new File(DATABASE_PATH);
        if (dbFile.exists()) {
            System.out.println("✓ Database file found: " + dbFile.getPath());
        } else {
            System.err.println("✗ Database file not found: " + dbFile.getPath());
        }
        
        // Check reports directory
        File reportsDir = new File(REPORTS_DIR);
        if (reportsDir.exists() && reportsDir.isDirectory()) {
            System.out.println("✓ Reports directory found: " + reportsDir.getPath());
        } else {
            System.err.println("✗ Reports directory not found: " + reportsDir.getPath());
        }
        
        // Check each JRXML file
        System.out.println("\nChecking individual report files:");
        for (String reportFile : AVAILABLE_REPORTS) {
            File jrxmlFile = new File(REPORTS_DIR + reportFile);
            if (jrxmlFile.exists()) {
                System.out.println("✓ " + reportFile + " found");
            } else {
                System.err.println("✗ " + reportFile + " not found");
            }
        }
        
        System.out.println("\nRequirements check completed.");
    }
}
