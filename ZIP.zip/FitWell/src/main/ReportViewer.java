import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 * Report Viewer for FitWell Gym Management System
 * Generates JasperReports and displays them in JasperViewer
 */
public class ReportViewer {
    
    private static final String DATABASE_PATH = "FitWell.accdb";
    private static final String REPORTS_DIR = "";
    
    // Define all available reports
    private static final String[] AVAILABLE_REPORTS = {
        "unregistered_class_report.jrxml",
        "equipment_inventory_report.jrxml", 
        "fitness_recommendation_report.jrxml"
    };
    
    private static final String[] REPORT_NAMES = {
        "Unregistered Class Report",
        "Equipment Inventory Report",
        "Fitness Recommendation Report"
    };
    
    /**
     * Main method to view reports
     */
    public static void main(String[] args) {
        ReportViewer viewer = new ReportViewer();
        
        try {
            System.out.println("=== FitWell Report Viewer ===\n");
            viewer.checkRequirements();
            
            // Show menu for user to select which report to view
            viewer.showMenu();
            
        } catch (Exception e) {
            System.err.println("\n❌ Error in report viewing: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Shows a menu for the user to select which report to view
     */
    public void showMenu() {
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        
        while (true) {
            System.out.println("\n=== Available Reports ===");
            for (int i = 0; i < AVAILABLE_REPORTS.length; i++) {
                System.out.println((i + 1) + ". " + REPORT_NAMES[i]);
            }
            System.out.println("0. Exit");
            System.out.println("A. View All Reports");
            System.out.print("\nSelect a report to view (0-" + AVAILABLE_REPORTS.length + ", A): ");
            
            String choice = scanner.nextLine().trim().toUpperCase();
            
            if (choice.equals("0")) {
                System.out.println("Goodbye!");
                break;
            } else if (choice.equals("A")) {
                viewAllReports();
            } else {
                try {
                    int reportIndex = Integer.parseInt(choice) - 1;
                    if (reportIndex >= 0 && reportIndex < AVAILABLE_REPORTS.length) {
                        viewReport(AVAILABLE_REPORTS[reportIndex], REPORT_NAMES[reportIndex]);
                    } else {
                        System.out.println("Invalid selection. Please try again.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a number or 'A'.");
                }
            }
        }
        
        scanner.close();
    }
    
    /**
     * Views a single report in JasperViewer
     */
    public void viewReport(String jrxmlFileName, String reportTitle) {
        try {
            System.out.println("\n🔄 Generating and viewing: " + reportTitle);
            
            // Step 1: Compile the JRXML file
            String jrxmlPath = REPORTS_DIR + jrxmlFileName;
            String jasperPath = REPORTS_DIR + jrxmlFileName.replace(".jrxml", ".jasper");
            
            JasperReport jasperReport = compileReport(jrxmlPath, jasperPath);
            System.out.println("  ✓ Report compiled successfully");
            
            // Step 2: Generate the report with appropriate parameters
            JasperPrint jasperPrint = generateReport(jasperReport, jrxmlFileName);
            System.out.println("  ✓ Report generated successfully");
            
            // Step 3: Display in JasperViewer
            displayReport(jasperPrint, reportTitle);
            System.out.println("  ✓ Report displayed in JasperViewer");
            
        } catch (Exception e) {
            System.err.println("❌ Failed to view " + reportTitle + ": " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Views all reports sequentially
     */
    public void viewAllReports() {
        System.out.println("\n🔄 Generating and viewing all reports...");
        
        for (int i = 0; i < AVAILABLE_REPORTS.length; i++) {
            try {
                System.out.println("\n" + (i + 1) + "/" + AVAILABLE_REPORTS.length + 
                                 " Processing: " + REPORT_NAMES[i]);
                
                viewReport(AVAILABLE_REPORTS[i], REPORT_NAMES[i]);
                
                // Add a small delay between reports
                if (i < AVAILABLE_REPORTS.length - 1) {
                    System.out.println("  Waiting 3 seconds before next report...");
                    Thread.sleep(3000);
                }
                
            } catch (Exception e) {
                System.err.println("❌ Failed to process " + REPORT_NAMES[i] + ": " + e.getMessage());
                e.printStackTrace();
            }
        }
        
        System.out.println("\n🎉 All reports processed!");
    }
    
    /**
     * Compiles a JRXML file to a JASPER file
     */
    private JasperReport compileReport(String jrxmlPath, String jasperPath) throws Exception {
        try {
            File jrxmlFile = new File(jrxmlPath);
            if (!jrxmlFile.exists()) {
                throw new Exception("JRXML file not found: " + jrxmlPath);
            }
            
            // Compile the JRXML file
            JasperCompileManager.compileReportToFile(jrxmlPath, jasperPath);
            
            // Load the compiled report
            JasperReport jasperReport = (JasperReport) JRLoader.loadObjectFromFile(jasperPath);
            
            return jasperReport;
            
        } catch (JRException e) {
            throw new Exception("Failed to compile JRXML file: " + e.getMessage(), e);
        }
    }
    
    /**
     * Generates a report using the compiled JasperReport with appropriate parameters
     */
    private JasperPrint generateReport(JasperReport jasperReport, String reportFileName) throws Exception {
        try {
            // Get database connection
            Connection connection = getDatabaseConnection();
            
            // Set report-specific parameters
            Map<String, Object> parameters = getReportParameters(reportFileName);
            
            // Fill the report
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, connection);
            
            // Close connection
            connection.close();
            
            return jasperPrint;
            
        } catch (Exception e) {
            throw new Exception("Failed to generate report: " + e.getMessage(), e);
        }
    }
    
    /**
     * Displays a report in JasperViewer
     */
    private void displayReport(JasperPrint jasperPrint, String reportTitle) throws Exception {
        try {
            // Create and display the viewer
            JasperViewer viewer = new JasperViewer(jasperPrint, false);
            viewer.setTitle("FitWell - " + reportTitle);
            viewer.setVisible(true);
            
        } catch (Exception e) {
            throw new Exception("Failed to display report: " + e.getMessage(), e);
        }
    }
    
    /**
     * Gets appropriate parameters for each report type
     */
    private Map<String, Object> getReportParameters(String reportFileName) {
        Map<String, Object> parameters = new HashMap<>();
        
        switch (reportFileName) {
            case "unregistered_class_report.jrxml":
                parameters.put("startDate", "2024-01-01");
                parameters.put("endDate", "2024-12-31");
                break;
                
            case "equipment_inventory_report.jrxml":
                parameters.put("currentYear", "2024");
                parameters.put("generatedDate", new java.util.Date().toString());
                break;
                
            case "fitness_recommendation_report.jrxml":
                parameters.put("classType", "Yoga");
                parameters.put("startDate", "2024-01-22");
                parameters.put("endDate", "2024-01-28");
                break;
                
            case "report.jrxml":
                // This report doesn't have parameters
                break;
                
            default:
                // Default parameters
                parameters.put("startDate", "2024-01-01");
                parameters.put("endDate", "2024-12-31");
                break;
        }
        
        return parameters;
    }
    
    /**
     * Establishes a connection to the Access database
     */
    private Connection getDatabaseConnection() throws Exception {
        try {
            File dbFile = new File(DATABASE_PATH);
            if (!dbFile.exists()) {
                throw new Exception("Database file not found: " + DATABASE_PATH);
            }
            
            String dbUrl = "jdbc:ucanaccess://" + dbFile.getAbsolutePath();
            
            // Load the UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            
            // Establish connection
            Connection connection = DriverManager.getConnection(dbUrl);
            
            return connection;
            
        } catch (Exception e) {
            throw new Exception("Failed to connect to database: " + e.getMessage(), e);
        }
    }
    
    /**
     * Checks system requirements
     */
    public void checkRequirements() {
        System.out.println("Checking system requirements...");
        System.out.println("=================================");
        
        // Check database file
        File dbFile = new File(DATABASE_PATH);
        if (dbFile.exists()) {
            System.out.println("✓ Database file found: " + dbFile.getPath());
        } else {
            System.err.println("✗ Database file not found: " + dbFile.getPath());
        }
        
        // Check reports directory
        File reportsDir = new File(REPORTS_DIR);
        if (reportsDir.exists() && reportsDir.isDirectory()) {
            System.out.println("✓ Reports directory found: " + reportsDir.getPath());
        } else {
            System.err.println("✗ Reports directory found: " + reportsDir.getPath());
        }
        
        // Check each JRXML file
        System.out.println("\nChecking individual report files:");
        for (String reportFile : AVAILABLE_REPORTS) {
            File jrxmlFile = new File(REPORTS_DIR + reportFile);
            if (jrxmlFile.exists()) {
                System.out.println("✓ " + reportFile + " found");
            } else {
                System.err.println("✗ " + reportFile + " not found");
            }
        }
        
        System.out.println("\nRequirements check completed.");
    }
}
