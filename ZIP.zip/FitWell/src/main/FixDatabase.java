package main;

import java.nio.file.*;
import java.net.URI;
import java.sql.*;
import java.time.LocalDate;

public class FixDatabase {

    // Will be built at runtime to point to a file next to the JAR
    private static String DB_URL;

    public static void main(String[] args) {
        try {
            // Resolve DB path next to the jar (or current working dir in IDE)
            Path dbPath = resolveDbPath("FitWell.accdb");
            DB_URL = buildUcanaccessUrl(dbPath);

            System.out.println("🔗 Using DB: " + dbPath.toAbsolutePath());
            System.out.println("🔌 JDBC URL: " + DB_URL);

            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Ensure required tables exist
                if (!tableExists(conn, "CustomerPlans")) {
                    System.out.println("❌ CustomerPlans table missing! Creating it...");
                    createCustomerPlansTable(conn);
                } else {
                    System.out.println("✅ CustomerPlans table exists");
                }

                ensureAttendanceTable(conn); // make sure [CustomerAttendance Table] exists

                // Ensure we have proper data for the report demo
                System.out.println("📊 Ensuring proper data for reports...");
                ensureProperData(conn);

                // Test the Unregistered/Low Attendance report query
                System.out.println("\n🔍 Testing Low Attendance (<5) Query...");
                testUnregisteredClassQuery(conn);

                System.out.println("✅ Database fix/verification completed!");
            }

        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /* ===================== Path helpers ===================== */

    /** Resolve the directory of the running JAR; fallback to working dir in IDE. */
    private static Path getExecutableDir() {
        try {
            URI uri = FixDatabase.class.getProtectionDomain().getCodeSource().getLocation().toURI();
            Path codePath = Paths.get(uri);
            // If running from a JAR, codePath is the JAR file; otherwise a folder (e.g., bin/ or target/classes/)
            if (Files.isRegularFile(codePath) && codePath.getFileName().toString().toLowerCase().endsWith(".jar")) {
                return codePath.getParent(); // folder containing the JAR
            }
        } catch (Exception ignore) {}
        // Fallback: current working directory (Eclipse/IDE run)
        return Paths.get(System.getProperty("user.dir"));
    }

    /** Find the DB next to the JAR (or in ./db), with a fallback to working dir. */
    private static Path resolveDbPath(String dbFileName) throws Exception {
        Path base = getExecutableDir();

        Path candidate = base.resolve(dbFileName);
        if (Files.exists(candidate)) return candidate;

        Path inDbSubdir = base.resolve("db").resolve(dbFileName);
        if (Files.exists(inDbSubdir)) return inDbSubdir;

        Path inCwd = Paths.get(System.getProperty("user.dir")).resolve(dbFileName);
        if (Files.exists(inCwd)) return inCwd;

        throw new IllegalStateException(
            "Could not find " + dbFileName + " next to the app. Looked in:\n" +
            " - " + candidate.toAbsolutePath() + "\n" +
            " - " + inDbSubdir.toAbsolutePath() + "\n" +
            " - " + inCwd.toAbsolutePath() + "\n" +
            "Place the .accdb file next to the JAR or in a 'db' subfolder.");
    }

    /** Build a UCanAccess URL from a Path (normalize backslashes for Windows). */
    private static String buildUcanaccessUrl(Path dbPath) {
        String normalized = dbPath.toAbsolutePath().toString().replace('\\', '/');
        // You can append UCanAccess options after a semicolon if needed.
        return "jdbc:ucanaccess://" + normalized;
    }

    /* ===================== Schema utilities ===================== */

    private static boolean tableExists(Connection conn, String table) throws SQLException {
        DatabaseMetaData md = conn.getMetaData();
        // Access stores identifiers in uppercase; search case-insensitively
        try (ResultSet rs = md.getTables(null, null, table, null)) {
            if (rs.next()) return true;
        }
        try (ResultSet rs = md.getTables(null, null, table.toUpperCase(), null)) {
            if (rs.next()) return true;
        }
        try (ResultSet rs = md.getTables(null, null, table.toLowerCase(), null)) {
            return rs.next();
        }
    }

    private static void createCustomerPlansTable(Connection conn) throws SQLException {
        String createSQL =
            "CREATE TABLE CustomerPlans (" +
            "  CustomerID INTEGER, " +
            "  PlanID INTEGER, " +
            "  RegistrationDate DATE" +
            ")";
        try (Statement stmt = conn.createStatement()) {
            stmt.execute(createSQL);
            System.out.println("  ✅ Created CustomerPlans");
        }

        String insertSQL =
            "INSERT INTO CustomerPlans (CustomerID, PlanID, RegistrationDate) VALUES " +
            "(1,1,#2024-01-01#),(2,2,#2024-01-01#),(3,3,#2024-01-01#),(4,1,#2024-01-01#)," +
            "(5,2,#2024-01-01#),(6,3,#2024-01-01#),(7,1,#2024-01-01#),(8,2,#2024-01-01#)";
        try (Statement stmt = conn.createStatement()) {
            stmt.execute(insertSQL);
            System.out.println("  ✅ Seeded CustomerPlans (8 rows)");
        }
    }

    /** Ensure the attendance table exists (name includes a space). */
    private static void ensureAttendanceTable(Connection conn) throws SQLException {
        String tableName = "CustomerAttendance Table";
        if (tableExists(conn, tableName)) {
            System.out.println("✅ [" + tableName + "] exists");
            return;
        }
        String create =
            "CREATE TABLE [CustomerAttendance Table] (" +
            "  ID AUTOINCREMENT PRIMARY KEY, " +
            "  CustomerID INTEGER, " +
            "  ClassID INTEGER, " +
            "  AttendanceDate DATE, " +
            "  EndTime TEXT" +
            ")";
        try (Statement stmt = conn.createStatement()) {
            stmt.execute(create);
            System.out.println("  ✅ Created [" + tableName + "]");
        }
    }

    /* ===================== Demo data & query ===================== */

    private static void ensureProperData(Connection conn) throws SQLException {
        // Clear existing attendance data to start fresh
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("DELETE FROM [CustomerAttendance Table]");
            System.out.println("  ✅ Cleared existing attendance data");
        }

        String insertAttendanceSQL =
            "INSERT INTO [CustomerAttendance Table] (CustomerID, ClassID, AttendanceDate, EndTime) VALUES " +
            // Customer 1: 4 classes
            "(1,1,#2024-01-15#,'09:00:00'),(1,2,#2024-01-15#,'10:15:00'),(1,3,#2024-01-15#,'18:30:00'),(1,4,#2024-01-15#,'20:00:00')," +
            // Customer 2: 3 classes
            "(2,1,#2024-01-15#,'09:00:00'),(2,2,#2024-01-15#,'10:15:00'),(2,3,#2024-01-15#,'18:30:00')," +
            // Customer 3: 6 classes
            "(3,1,#2024-01-15#,'09:00:00'),(3,2,#2024-01-15#,'10:15:00'),(3,3,#2024-01-15#,'18:30:00')," +
            "(3,4,#2024-01-15#,'20:00:00'),(3,5,#2024-01-16#,'11:15:00'),(3,6,#2024-01-16#,'19:30:00')," +
            // Customer 4: 2 classes
            "(4,1,#2024-01-15#,'09:00:00'),(4,2,#2024-01-15#,'10:15:00')," +
            // Customer 5: 1 class
            "(5,2,#2024-01-15#,'10:15:00')";
        try (Statement stmt = conn.createStatement()) {
            stmt.execute(insertAttendanceSQL);
            System.out.println("  ✅ Inserted attendance data");
        }

        // Quick verification
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                 "SELECT CustomerID, COUNT(*) AS ClassesAttended " +
                 "FROM [CustomerAttendance Table] GROUP BY CustomerID ORDER BY CustomerID")) {

            System.out.println("  📊 Current attendance data:");
            while (rs.next()) {
                System.out.printf("    Customer %d: %d classes%n",
                        rs.getInt("CustomerID"), rs.getInt("ClassesAttended"));
            }
        }
    }

    private static void testUnregisteredClassQuery(Connection conn) {
        // Demo range matches inserted sample (Jan 2024)
        LocalDate start = LocalDate.of(2024, 1, 1);
        LocalDate end   = LocalDate.of(2024, 1, 31);

        String query =
            "SELECT c.CustomerID, c.CustomerFirstName, c.CustomerLastName, c.phone, c.Email, " +
            "       cp.RegistrationDate, COUNT(a.CustomerID) AS ClassesAttended " +
            "FROM CustomerTable c " +
            "INNER JOIN CustomerPlans cp ON c.CustomerID = cp.CustomerID " +
            "LEFT JOIN [CustomerAttendance Table] a ON c.CustomerID = a.CustomerID " +
            "     AND a.AttendanceDate BETWEEN ? AND ? " +
            "WHERE cp.RegistrationDate <= ? " +
            "GROUP BY c.CustomerID, c.CustomerFirstName, c.CustomerLastName, c.phone, c.Email, cp.RegistrationDate " +
            "HAVING COUNT(a.CustomerID) < 5 " +
            "ORDER BY c.CustomerFirstName, c.CustomerLastName";

        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setDate(1, java.sql.Date.valueOf(start));
            ps.setDate(2, java.sql.Date.valueOf(end));
            ps.setDate(3, java.sql.Date.valueOf(end));

            try (ResultSet rs = ps.executeQuery()) {
                int count = 0;
                System.out.println("  ✅ Query executed successfully!");
                System.out.println("  📊 Results for customers with < 5 classes:");
                while (rs.next()) {
                    count++;
                    System.out.printf("    %s | %s %s | %s | %s | Classes: %d | Reg: %s%n",
                            rs.getString("CustomerID"),
                            rs.getString("CustomerFirstName"),
                            rs.getString("CustomerLastName"),
                            rs.getString("phone"),
                            rs.getString("Email"),
                            rs.getInt("ClassesAttended"),
                            rs.getString("RegistrationDate"));
                }
                System.out.println("  📈 Total customers with < 5 classes: " + count);
                System.out.println("  🎯 Expected: 7 customers (IDs: 1,2,4,5,6,7,8)");
            }
        } catch (SQLException e) {
            System.out.println("  ❌ Query failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
