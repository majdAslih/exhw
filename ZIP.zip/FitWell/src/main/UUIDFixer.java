import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * UUID Fixer for JRXML files
 * Replaces all invalid UUIDs with valid hexadecimal UUIDs
 */
public class UUIDFixer {
    
    private static final String REPORTS_DIR = "";
    
    public static void main(String[] args) {
        System.out.println("=== UUID Fixer for JRXML Files ===\n");
        
        try {
            File reportsDir = new File(REPORTS_DIR);
            if (!reportsDir.exists()) {
                System.err.println("Reports directory not found: " + REPORTS_DIR);
                return;
            }
            
            File[] jrxmlFiles = reportsDir.listFiles((dir, name) -> name.endsWith(".jrxml"));
            if (jrxmlFiles == null || jrxmlFiles.length == 0) {
                System.err.println("No JRXML files found in " + REPORTS_DIR);
                return;
            }
            
            int totalFixed = 0;
            
            for (File jrxmlFile : jrxmlFiles) {
                System.out.println("Processing: " + jrxmlFile.getName());
                int fixed = fixUUIDsInFile(jrxmlFile);
                totalFixed += fixed;
                System.out.println("  Fixed " + fixed + " UUIDs\n");
            }
            
            System.out.println("🎉 Total UUIDs fixed: " + totalFixed);
            System.out.println("All JRXML files should now have valid UUIDs!");
            System.out.println("\nYou can now run the PDFReportGenerator to generate PDF reports.");
            
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static int fixUUIDsInFile(File file) throws IOException {
        String content = new String(Files.readAllBytes(file.toPath()));
        int fixedCount = 0;
        
        // Pattern to find UUID attributes
        Pattern uuidPattern = Pattern.compile("uuid=\"([^\"]*)\"");
        Matcher matcher = uuidPattern.matcher(content);
        
        while (matcher.find()) {
            String uuid = matcher.group(1);
            
            // Check if UUID is invalid (contains non-hex characters or wrong format)
            if (isInvalidUUID(uuid)) {
                String newUUID = generateValidUUID();
                content = content.replace("uuid=\"" + uuid + "\"", "uuid=\"" + newUUID + "\"");
                System.out.println("    Replaced: " + uuid + " -> " + newUUID);
                fixedCount++;
            }
        }
        
        // Write the fixed content back to the file
        Files.write(file.toPath(), content.getBytes());
        
        return fixedCount;
    }
    
    private static boolean isInvalidUUID(String uuid) {
        // Check if UUID contains invalid characters (g-z)
        if (uuid.toLowerCase().matches(".*[g-z].*")) {
            return true;
        }
        
        // Check if UUID is not in the correct format (like "header-name", "detail-id")
        if (!uuid.matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")) {
            return true;
        }
        
        return false;
    }
    
    private static String generateValidUUID() {
        return UUID.randomUUID().toString();
    }
}

