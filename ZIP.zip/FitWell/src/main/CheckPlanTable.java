package main;

import java.sql.*;

public class CheckPlanTable {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Check PlanTable structure
                System.out.println("🔍 Checking PlanTable structure...");
                checkPlanTableStructure(conn);

                // Check existing data
                System.out.println("\n📊 Checking existing PlanTable data...");
                checkExistingPlanData(conn);

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void checkPlanTableStructure(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM PlanTable WHERE 1=0")) {
            
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            
            System.out.println("  📋 PlanTable structure:");
            for (int i = 1; i <= columnCount; i++) {
                String columnName = metaData.getColumnName(i);
                String columnType = metaData.getColumnTypeName(i);
                int columnSize = metaData.getColumnDisplaySize(i);
                System.out.println("    Column " + i + ": " + columnName + " (" + columnType + ", size: " + columnSize + ")");
            }
        }
    }

    private static void checkExistingPlanData(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as TotalPlans FROM PlanTable")) {
            
            if (rs.next()) {
                int totalPlans = rs.getInt("TotalPlans");
                System.out.println("  📊 Total plans in PlanTable: " + totalPlans);
            }
        }

        // Check if there are any records and show sample
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT TOP 3 * FROM PlanTable")) {
            
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            
            System.out.println("  📋 Sample PlanTable data (first 3 records):");
            while (rs.next()) {
                System.out.print("    Record: ");
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = metaData.getColumnName(i);
                    String value = rs.getString(i);
                    System.out.print(columnName + "=" + value + " | ");
                }
                System.out.println();
            }
        }
    }
}
