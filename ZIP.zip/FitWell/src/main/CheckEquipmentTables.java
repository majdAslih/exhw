package main;

import java.sql.*;

public class CheckEquipmentTables {

    private static final String DB_URL = "jdbc:ucanaccess://FitWell.accdb";

    public static void main(String[] args) {
        try {
            // Load UCanAccess driver
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            System.out.println("✅ Driver loaded successfully");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL)) {
                System.out.println("✅ Connected to FitWell.accdb");

                // Check what tables exist
                System.out.println("🔍 Checking what tables exist in the database...");
                checkAllTables(conn);

                // Check equipment-related tables specifically
                System.out.println("\n🔍 Checking equipment-related tables...");
                checkEquipmentTables(conn);

            }
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void checkAllTables(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='TABLE' ORDER BY TABLE_NAME")) {
            
            System.out.println("  📋 All tables in database:");
            while (rs.next()) {
                String tableName = rs.getString("TABLE_NAME");
                System.out.println("    " + tableName);
            }
        } catch (SQLException e) {
            System.out.println("  ℹ️ Could not get table list from INFORMATION_SCHEMA, trying alternative approach...");
            
            // Try to query some common table names
            String[] commonTables = {
                "EquipmentTable", "Equipment", "EquipmentList", "EquipmentInventory",
                "EquipmentUsage", "EquipmentUsageTable", "EquipmentLog", "EquipmentLogTable",
                "EquipmentMaintenance", "EquipmentMaintenanceTable"
            };
            
            for (String tableName : commonTables) {
                try (Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM " + tableName)) {
                    if (rs.next()) {
                        int count = rs.getInt(1);
                        System.out.println("    " + tableName + " (exists with " + count + " records)");
                    }
                } catch (SQLException ex) {
                    // Table doesn't exist, ignore
                }
            }
        }
    }

    private static void checkEquipmentTables(Connection conn) throws SQLException {
        // Try to find equipment-related tables by checking common names
        String[] equipmentTableNames = {
            "EquipmentTable", "Equipment", "EquipmentList", "EquipmentInventory"
        };
        
        for (String tableName : equipmentTableNames) {
            try {
                System.out.println("\n📋 Checking " + tableName + "...");
                
                // Check if table exists and get structure
                try (Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery("SELECT * FROM " + tableName + " WHERE 1=0")) {
                    
                    ResultSetMetaData metaData = rs.getMetaData();
                    int columnCount = metaData.getColumnCount();
                    
                    System.out.println("  ✅ Table exists with " + columnCount + " columns:");
                    for (int i = 1; i <= columnCount; i++) {
                        String columnName = metaData.getColumnName(i);
                        String columnType = metaData.getColumnTypeName(i);
                        int columnSize = metaData.getColumnDisplaySize(i);
                        System.out.println("    Column " + i + ": " + columnName + " (" + columnType + ", size: " + columnSize + ")");
                    }
                    
                    // Check record count
                    try (Statement countStmt = conn.createStatement();
                         ResultSet countRs = countStmt.executeQuery("SELECT COUNT(*) FROM " + tableName)) {
                        if (countRs.next()) {
                            int totalRecords = countRs.getInt(1);
                            System.out.println("  📊 Total records: " + totalRecords);
                        }
                    }
                    
                    // Show sample data if any exists
                    if (columnCount > 0) {
                        try (Statement sampleStmt = conn.createStatement();
                             ResultSet sampleRs = sampleStmt.executeQuery("SELECT TOP 3 * FROM " + tableName)) {
                            
                            System.out.println("  📋 Sample data (first 3 records):");
                            while (sampleRs.next()) {
                                System.out.print("    Record: ");
                                for (int i = 1; i <= columnCount; i++) {
                                    String columnName = metaData.getColumnName(i);
                                    String value = sampleRs.getString(i);
                                    System.out.print(columnName + "=" + value + " | ");
                                }
                                System.out.println();
                            }
                        }
                    }
                }
                
            } catch (SQLException e) {
                System.out.println("  ❌ Table " + tableName + " does not exist or is not accessible");
            }
        }
        
        // Also check for equipment usage tables
        String[] usageTableNames = {
            "EquipmentUsage", "EquipmentUsageTable", "EquipmentLog", "EquipmentLogTable"
        };
        
        for (String tableName : usageTableNames) {
            try {
                System.out.println("\n📋 Checking " + tableName + "...");
                
                try (Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery("SELECT * FROM " + tableName + " WHERE 1=0")) {
                    
                    ResultSetMetaData metaData = rs.getMetaData();
                    int columnCount = metaData.getColumnCount();
                    
                    System.out.println("  ✅ Table exists with " + columnCount + " columns:");
                    for (int i = 1; i <= columnCount; i++) {
                        String columnName = metaData.getColumnName(i);
                        String columnType = metaData.getColumnTypeName(i);
                        int columnSize = metaData.getColumnDisplaySize(i);
                        System.out.println("    Column " + i + ": " + columnName + " (" + columnType + ", size: " + columnSize + ")");
                    }
                    
                    // Check record count
                    try (Statement countStmt = conn.createStatement();
                         ResultSet countRs = countStmt.executeQuery("SELECT COUNT(*) FROM " + tableName)) {
                        if (countRs.next()) {
                            int totalRecords = countRs.getInt(1);
                            System.out.println("  📊 Total records: " + totalRecords);
                        }
                    }
                }
                
            } catch (SQLException e) {
                System.out.println("  ❌ Table " + tableName + " does not exist or is not accessible");
            }
        }
    }
}
