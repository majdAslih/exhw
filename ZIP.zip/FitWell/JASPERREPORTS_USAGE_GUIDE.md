# JasperReports Usage Guide for FitWell Gym Management System

## Overview
This guide explains how to use the comprehensive JasperReports system to generate and view ALL reports for the FitWell Gym Management System in JasperViewer.

## What Was Fixed
The original JRXML files had several issues that prevented JasperReports from working:
1. **Invalid UUID format**: The UUIDs contained invalid characters (g, h, i, j, etc.) which are not valid hexadecimal characters
2. **Missing closing tags**: There was a missing `</textElement>` tag in the summary section
3. **UUID format**: All UUIDs now follow the proper format: `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`

## Files Created/Modified

### 1. Fixed JRXML Files
- **File**: `src/boundary/unregistered_class_report.jrxml` ✅ Fixed all UUID issues
- **File**: `src/boundary/equipment_inventory_report.jrxml` ✅ Fixed all UUID issues  
- **File**: `src/boundary/fitness_recommendation_report.jrxml` ✅ Fixed all UUID issues
- **File**: `src/boundary/report.jrxml` ✅ Already had valid UUIDs
- **Status**: All reports now have proper UUIDs and can be viewed in JasperViewer

### 2. Comprehensive Report Manager
- **File**: `src/main/ComprehensiveReportManager.java`
- **Purpose**: Interactive manager that lets you choose which report to generate
- **Features**:
  - Lists all available reports
  - Interactive menu system
  - Generates selected report in JasperViewer
  - Comprehensive error handling

### 3. Batch Report Processor
- **File**: `src/main/BatchReportProcessor.java`
- **Purpose**: Generates ALL reports at once and displays them in separate JasperViewer windows
- **Features**:
  - Processes all reports sequentially
  - Opens each report in its own JasperViewer window
  - Automatic parameter configuration for each report type
  - Progress tracking and error handling

### 4. Individual Report Generator
- **File**: `src/main/JasperReportGenerator.java`
- **Purpose**: Original single report generator (still available)
- **Features**:
  - Compiles JRXML files to JASPER format
  - Connects to Access database
  - Generates reports with data
  - Displays reports in JasperViewer

### 5. Test Runner
- **File**: `src/main/TestReportGeneration.java`
- **Purpose**: Simple test class to verify the setup works correctly

## Available Reports

### 1. Unregistered Class Report
- **Purpose**: Shows customers who attended fewer than 5 classes
- **Data Source**: CustomerTable, CustomerPlans, CustomerAttendance
- **Parameters**: Start date and end date for filtering

### 2. Equipment Inventory Report
- **Purpose**: Complete equipment overview with current year usage statistics
- **Data Source**: Equipment Table, EquipmentUsageReport Table
- **Parameters**: Current year, generated date

### 3. Fitness Recommendation Report
- **Purpose**: Classes for specific types with weekly schedule
- **Data Source**: ClassTable, PDTable, ClassesInPlan, PlanTable, Instructor Table
- **Parameters**: Class type, start date, end date

### 4. Equipment Usage Report
- **Purpose**: Equipment usage statistics and hours count
- **Data Source**: Equipment Table, EquipmentUsageReport Table
- **Parameters**: None (uses default data)

## How to Use

### Option 1: Interactive Report Manager (Recommended)
```bash
# Compile the Java files
javac -cp "bin/libs/*" src/main/*.java

# Run the interactive manager
java -cp "bin/libs/*;src/main" ComprehensiveReportManager
```
This will show you a menu of all available reports and let you choose which one to generate.

### Option 2: Generate All Reports at Once
```bash
# Compile the Java files
javac -cp "bin/libs/*" src/main/*.java

# Run the batch processor
java -cp "bin/libs/*;src/main" BatchReportProcessor
```
This will generate ALL reports and open each one in a separate JasperViewer window.

### Option 3: Generate Individual Reports
```bash
# Compile the Java files
javac -cp "bin/libs/*" src/main/*.java

# Run individual report generator
java -cp "bin/libs/*;src/main" JasperReportGenerator
```

### Option 4: Test Setup
```bash
# Compile the Java files
javac -cp "bin/libs/*" src/main/*.java

# Run the test
java -cp "bin/libs/*;src/main" TestReportGeneration
```

## Report Features

### All Reports Include
- **Professional Layout**: Clean, organized design
- **Database Integration**: Real-time data from your Access database
- **Parameter Support**: Configurable filtering and date ranges
- **JasperViewer Display**: Professional report viewing interface
- **Error Handling**: Comprehensive error messages and troubleshooting

### Report Structure (Common to All)
1. **Title Band**: Report header with title and relevant information
2. **Column Header**: Column titles for data fields
3. **Detail Band**: Individual data records
4. **Summary/Footer**: Additional information or totals

## Database Connection
The system automatically connects to your Access database (`FitWell.accdb`) using the UCanAccess JDBC driver.

## Troubleshooting

### Common Issues and Solutions

#### 1. UUID Parsing Errors
- **Symptom**: `java.util.UUID.fromString` errors
- **Solution**: ✅ RESOLVED - All UUIDs now use correct format
- **Format**: `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx` (hexadecimal characters only)

#### 2. Class Not Found Errors
- **Symptom**: `ClassNotFoundException` for JasperReports classes
- **Solution**: Verify all JAR files are in the `bin/libs/` directory
- **Required JARs**: 
  - `jasperreports-7.0.3.jar`
  - `commons-*.jar` files
  - `ucanaccess-5.0.1.jar`

#### 3. Database Connection Issues
- **Symptom**: Cannot connect to database
- **Solution**: 
  - Verify database file path is correct
  - Ensure UCanAccess driver is in classpath
  - Check file permissions

#### 4. Report Compilation Errors
- **Symptom**: JRXML compilation fails
- **Solution**:
  - Check JRXML syntax
  - Verify all required fields are defined
  - Ensure proper XML structure

### Debug Mode
The `checkAllRequirements()` method helps diagnose setup issues:
```java
ComprehensiveReportManager manager = new ComprehensiveReportManager();
manager.checkAllRequirements();
```

## Advanced Usage

### Adding New Reports
1. Create a new JRXML file in `src/boundary/`
2. Use proper UUID format for all elements
3. Define your data source and fields
4. Add the report to the `AVAILABLE_REPORTS` array in the manager classes

### Customizing Report Parameters
Each report type has its own parameter configuration:
```java
// Unregistered Class Report
parameters.put("startDate", "2024-01-01");
parameters.put("endDate", "2024-12-31");

// Equipment Inventory Report
parameters.put("currentYear", "2024");
parameters.put("generatedDate", new java.util.Date().toString());

// Fitness Recommendation Report
parameters.put("classType", "Yoga");
parameters.put("startDate", "2024-01-22");
parameters.put("endDate", "2024-01-28");
```

### Exporting Reports
You can extend the system to export reports to PDF, Excel, or other formats using JasperReports' export capabilities.

## Performance Tips
1. **Compile once, use many**: Compile JRXML files once and reuse the compiled JASPER files
2. **Connection pooling**: For production use, implement connection pooling
3. **Report caching**: Cache frequently used reports
4. **Batch processing**: Use the BatchReportProcessor for generating multiple reports

## Security Considerations
1. **Parameter validation**: Always validate user input parameters
2. **SQL injection**: Use parameterized queries (already implemented)
3. **File access**: Restrict access to report files and database
4. **User permissions**: Implement role-based access control

## Support
If you encounter issues:
1. Check the console output for error messages
2. Verify all dependencies are correctly configured
3. Use the `checkAllRequirements()` method to diagnose setup issues
4. Review the troubleshooting section above

## Next Steps
1. **Test the system**: Run `ComprehensiveReportManager` to see all available reports
2. **Generate all reports**: Use `BatchReportProcessor` to see everything at once
3. **Customize reports**: Modify JRXML files to match your specific needs
4. **Add new reports**: Create additional reports for other business requirements
5. **Integrate with application**: Use the report classes in your main application

---

## 🎉 **What You Now Have**

✅ **ALL 4 reports fixed and ready for JasperViewer**
✅ **Interactive report manager with menu system**
✅ **Batch processor for all reports at once**
✅ **Individual report generator for specific needs**
✅ **Comprehensive error handling and troubleshooting**
✅ **Professional JasperViewer display for all reports**

**Note**: This system is now ready to generate and display ALL JasperReports in JasperViewer. The UUID issues have been completely resolved across all reports, and you have multiple ways to generate and view your reports.
