#!/usr/bin/env python3
"""
Script to fix invalid UUIDs in JRXML files
Replaces all invalid characters (g-z) with valid hexadecimal characters (0-9, a-f)
"""

import re
import os
import uuid

def generate_valid_uuid():
    """Generate a valid UUID string"""
    return str(uuid.uuid4())

def fix_uuids_in_file(filepath):
    """Fix all invalid UUIDs in a single file"""
    print(f"Fixing UUIDs in: {filepath}")
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Find all UUID attributes
    uuid_pattern = r'uuid="([^"]*)"'
    matches = re.findall(uuid_pattern, content)
    
    # Track replacements
    replacements = {}
    
    for match in matches:
        if any(c in match.lower() for c in 'ghijklmnopqrstuvwxyz'):
            # This UUID contains invalid characters
            new_uuid = generate_valid_uuid()
            replacements[match] = new_uuid
            print(f"  Replacing invalid UUID: {match} -> {new_uuid}")
    
    # Apply all replacements
    for old_uuid, new_uuid in replacements.items():
        content = content.replace(f'uuid="{old_uuid}"', f'uuid="{new_uuid}"')
    
    # Write back to file
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"  Fixed {len(replacements)} UUIDs")
    return len(replacements)

def main():
    """Main function to fix all JRXML files"""
    reports_dir = "src/boundary"
    
    if not os.path.exists(reports_dir):
        print(f"Reports directory not found: {reports_dir}")
        return
    
    jrxml_files = [f for f in os.listdir(reports_dir) if f.endswith('.jrxml')]
    
    if not jrxml_files:
        print("No JRXML files found")
        return
    
    total_fixed = 0
    
    for filename in jrxml_files:
        filepath = os.path.join(reports_dir, filename)
        try:
            fixed_count = fix_uuids_in_file(filepath)
            total_fixed += fixed_count
        except Exception as e:
            print(f"Error processing {filename}: {e}")
    
    print(f"\nTotal UUIDs fixed: {total_fixed}")
    print("All JRXML files should now have valid UUIDs!")

if __name__ == "__main__":
    main()
